/**
 * BétonPro SCADA - Layout Principal
 * Navigation latérale + header + contenu
 */
import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useStore } from '../store';
import {
  LayoutDashboard, Activity, Factory, BookOpen, Bell, Clock,
  Users, Settings, Wifi, Wrench, LogOut, ChevronLeft, ChevronRight,
  Moon, Sun, AlertTriangle, Shield, Cpu, Menu
} from 'lucide-react';
import { cn } from '../utils/cn';

interface LayoutProps {
  children: React.ReactNode;
  currentPage: string;
  onNavigate: (page: string) => void;
}

export const Layout: React.FC<LayoutProps> = ({ children, currentPage, onNavigate }) => {
  const { t, i18n } = useTranslation();
  const { auth, logout, theme, toggleTheme, language, setLanguage, alarms, developerPageEnabled } = useStore();
  const [collapsed, setCollapsed] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  const activeAlarms = alarms.filter(a => a.active && !a.acknowledged);
  const criticalAlarms = activeAlarms.filter(a => a.priority === 'critical');

  const isRTL = language === 'ar';
  const canAccessDev = auth.user?.role === 'admin' && developerPageEnabled;

  const navItems = [
    { id: 'dashboard', label: t('nav.dashboard'), icon: LayoutDashboard, color: 'text-blue-400' },
    { id: 'synoptic', label: t('nav.synoptic'), icon: Activity, color: 'text-green-400' },
    { id: 'production', label: t('nav.production'), icon: Factory, color: 'text-orange-400' },
    { id: 'recipes', label: t('nav.recipes'), icon: BookOpen, color: 'text-purple-400' },
    { id: 'alarms', label: t('nav.alarms'), icon: Bell, color: 'text-red-400', badge: activeAlarms.length },
    { id: 'history', label: t('nav.history'), icon: Clock, color: 'text-yellow-400' },
    { id: 'clients', label: t('nav.clients'), icon: Users, color: 'text-cyan-400' },
    { id: 'maintenance', label: t('nav.maintenance'), icon: Wrench, color: 'text-amber-400' },
    { id: 'parameters', label: t('nav.parameters'), icon: Settings, color: 'text-slate-400' },
    { id: 'users', label: t('nav.users'), icon: Shield, color: 'text-indigo-400', adminOnly: true },
    { id: 'communication', label: t('nav.communication'), icon: Wifi, color: 'text-teal-400' },
    ...(canAccessDev ? [{ id: 'developer', label: t('nav.developer'), icon: Cpu, color: 'text-pink-400', devOnly: true }] : []),
  ].filter(item => !item.adminOnly || auth.user?.role === 'admin');

  const isDark = theme === 'dark';

  const handleLangChange = () => {
    const langs: Array<'fr' | 'en' | 'ar'> = ['fr', 'en', 'ar'];
    const next = langs[(langs.indexOf(language) + 1) % 3];
    setLanguage(next);
    i18n.changeLanguage(next);
  };

  const langLabel = { fr: 'FR', en: 'EN', ar: 'AR' }[language];

  const SidebarContent = () => (
    <>
      {/* Logo */}
      <div className={cn(
        'flex items-center gap-3 px-4 py-4 border-b',
        isDark ? 'border-slate-700' : 'border-slate-200'
      )}>
        <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-orange-500 to-red-600 flex items-center justify-center flex-shrink-0">
          <Factory size={20} className="text-white" />
        </div>
        {!collapsed && (
          <div className="overflow-hidden">
            <div className={cn('font-bold text-sm leading-tight', isDark ? 'text-white' : 'text-slate-900')}>
              BétonPro
            </div>
            <div className={cn('text-xs', isDark ? 'text-slate-400' : 'text-slate-500')}>SCADA v2.0</div>
          </div>
        )}
      </div>

      {/* Nav Items */}
      <nav className="flex-1 overflow-y-auto py-2 px-2">
        {navItems.map(item => {
          const Icon = item.icon;
          const isActive = currentPage === item.id;
          return (
            <button
              key={item.id}
              onClick={() => { onNavigate(item.id); setMobileOpen(false); }}
              className={cn(
                'w-full flex items-center gap-3 px-3 py-2.5 rounded-lg mb-0.5 transition-all duration-200 group relative',
                isActive
                  ? isDark ? 'bg-slate-700 text-white' : 'bg-slate-200 text-slate-900'
                  : isDark ? 'text-slate-400 hover:bg-slate-800 hover:text-white' : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900',
                item.devOnly && 'border border-dashed border-pink-500/30',
              )}
              title={collapsed ? item.label : undefined}
            >
              <Icon size={18} className={cn(isActive ? item.color : '', 'flex-shrink-0')} />
              {!collapsed && (
                <>
                  <span className="text-sm font-medium truncate flex-1 text-left">{item.label}</span>
                  {item.badge && item.badge > 0 && (
                    <span className="text-xs font-bold px-1.5 py-0.5 rounded-full bg-red-500 text-white animate-pulse">
                      {item.badge}
                    </span>
                  )}
                  {item.devOnly && (
                    <span className="text-xs text-pink-400 opacity-60">DEV</span>
                  )}
                </>
              )}
              {collapsed && item.badge && item.badge > 0 && (
                <span className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 rounded-full text-white text-xs flex items-center justify-center animate-pulse">
                  {item.badge}
                </span>
              )}
            </button>
          );
        })}
      </nav>

      {/* Bottom actions */}
      <div className={cn('p-2 border-t', isDark ? 'border-slate-700' : 'border-slate-200')}>
        {/* Critical alarm banner */}
        {criticalAlarms.length > 0 && !collapsed && (
          <button
            onClick={() => onNavigate('alarms')}
            className="w-full mb-2 flex items-center gap-2 px-3 py-2 rounded-lg bg-red-500/20 border border-red-500/50 text-red-400 animate-pulse hover:bg-red-500/30 transition-colors"
          >
            <AlertTriangle size={16} />
            <span className="text-xs font-bold">{criticalAlarms.length} ALARME(S) CRITIQUE(S)</span>
          </button>
        )}

        {/* Theme + Lang + Collapse */}
        <div className="flex items-center gap-1">
          <button
            onClick={toggleTheme}
            className={cn('p-2 rounded-lg transition-colors flex-shrink-0', isDark ? 'text-slate-400 hover:text-white hover:bg-slate-700' : 'text-slate-500 hover:text-slate-900 hover:bg-slate-200')}
            title="Thème"
          >
            {isDark ? <Sun size={16} /> : <Moon size={16} />}
          </button>
          <button
            onClick={handleLangChange}
            className={cn('px-2 py-1 rounded-lg transition-colors text-xs font-bold flex-shrink-0', isDark ? 'text-slate-400 hover:text-white hover:bg-slate-700' : 'text-slate-500 hover:text-slate-900 hover:bg-slate-200')}
            title="Langue"
          >
            {langLabel}
          </button>
          {!collapsed && (
            <button
              onClick={logout}
              className={cn('flex items-center gap-2 px-2 py-2 rounded-lg transition-colors flex-1', isDark ? 'text-slate-400 hover:text-red-400 hover:bg-slate-700' : 'text-slate-500 hover:text-red-500 hover:bg-slate-200')}
            >
              <LogOut size={15} />
              <span className="text-xs">{t('nav.logout')}</span>
            </button>
          )}
          <button
            onClick={() => setCollapsed(c => !c)}
            className={cn('p-2 rounded-lg transition-colors flex-shrink-0 hidden lg:flex', isDark ? 'text-slate-400 hover:text-white hover:bg-slate-700' : 'text-slate-500 hover:text-slate-900 hover:bg-slate-200')}
          >
            {collapsed ? <ChevronRight size={16} /> : <ChevronLeft size={16} />}
          </button>
        </div>

        {/* User info */}
        {!collapsed && (
          <div className={cn('mt-2 px-3 py-2 rounded-lg', isDark ? 'bg-slate-800' : 'bg-slate-100')}>
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-full bg-gradient-to-br from-blue-500 to-indigo-600 flex items-center justify-center text-white text-xs font-bold">
                {auth.user?.username[0].toUpperCase()}
              </div>
              <div className="overflow-hidden flex-1">
                <div className={cn('text-xs font-semibold truncate', isDark ? 'text-white' : 'text-slate-900')}>{auth.user?.username}</div>
                <div className={cn('text-xs truncate', isDark ? 'text-slate-400' : 'text-slate-500')}>{t(`users.${auth.user?.role}`)}</div>
              </div>
            </div>
          </div>
        )}
      </div>
    </>
  );

  return (
    <div className={cn('flex h-screen overflow-hidden', isDark ? 'bg-slate-900' : 'bg-slate-50')} dir={isRTL ? 'rtl' : 'ltr'}>
      {/* Desktop Sidebar */}
      <aside className={cn(
        'hidden lg:flex flex-col flex-shrink-0 h-full transition-all duration-300 border-r',
        collapsed ? 'w-16' : 'w-56',
        isDark ? 'bg-slate-900 border-slate-700' : 'bg-white border-slate-200'
      )}>
        <SidebarContent />
      </aside>

      {/* Mobile Overlay */}
      {mobileOpen && (
        <div
          className="lg:hidden fixed inset-0 bg-black/60 z-40"
          onClick={() => setMobileOpen(false)}
        />
      )}

      {/* Mobile Sidebar */}
      <aside className={cn(
        'lg:hidden fixed left-0 top-0 bottom-0 w-64 z-50 flex flex-col transition-transform duration-300',
        mobileOpen ? 'translate-x-0' : '-translate-x-full',
        isDark ? 'bg-slate-900 border-r border-slate-700' : 'bg-white border-r border-slate-200'
      )}>
        <SidebarContent />
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <header className={cn(
          'flex items-center gap-3 px-4 py-3 border-b flex-shrink-0',
          isDark ? 'bg-slate-900 border-slate-700' : 'bg-white border-slate-200'
        )}>
          <button
            className={cn('lg:hidden p-2 rounded-lg', isDark ? 'text-slate-400 hover:text-white' : 'text-slate-500 hover:text-slate-900')}
            onClick={() => setMobileOpen(true)}
          >
            <Menu size={20} />
          </button>
          <div className="flex-1">
            <h1 className={cn('text-base font-bold', isDark ? 'text-white' : 'text-slate-900')}>
              {navItems.find(n => n.id === currentPage)?.label || 'BétonPro SCADA'}
            </h1>
          </div>

          {/* Status indicators */}
          <div className="flex items-center gap-2">
            <StatusPill connected={false} simMode={true} isDark={isDark} />
            {activeAlarms.length > 0 && (
              <button
                onClick={() => onNavigate('alarms')}
                className="flex items-center gap-1 px-2 py-1 rounded-lg bg-red-500/20 border border-red-500/50 text-red-400 text-xs font-bold animate-pulse"
              >
                <AlertTriangle size={12} />
                {activeAlarms.length}
              </button>
            )}
          </div>
        </header>

        {/* Page Content */}
        <div className="flex-1 overflow-auto">
          {children}
        </div>
      </main>
    </div>
  );
};

const StatusPill: React.FC<{ connected: boolean; simMode: boolean; isDark: boolean }> = ({ connected, simMode, isDark }) => {
  return (
    <div className={cn(
      'flex items-center gap-1.5 px-2 py-1 rounded-full text-xs font-medium',
      simMode
        ? 'bg-yellow-500/20 text-yellow-400 border border-yellow-500/40'
        : connected
          ? 'bg-green-500/20 text-green-400 border border-green-500/40'
          : 'bg-red-500/20 text-red-400 border border-red-500/40'
    )}>
      <span className={cn(
        'w-1.5 h-1.5 rounded-full',
        simMode ? 'bg-yellow-400 animate-pulse' : connected ? 'bg-green-400 animate-pulse' : 'bg-red-400'
      )} />
      {simMode ? 'SIM' : connected ? 'PLC OK' : 'NO PLC'}
    </div>
  );
};

export default Layout;
