/**
 * BétonPro SCADA - Application principale
 * Système de supervision industrielle pour centrale à béton
 * Schneider TM200CE24R · Modbus TCP · PostgreSQL 18.3
 *
 * Architecture:
 * - React 19 + TypeScript
 * - Zustand state management
 * - Tailwind CSS v4
 * - i18next (FR/EN/AR)
 * - Recharts (graphiques temps réel)
 * - Simulateur PLC virtuel intégré
 */
import React, { useEffect, useState } from 'react';
import { useStore } from './store';
import { Layout } from './components/Layout';
import { LoginPage } from './pages/LoginPage';
import { DashboardPage } from './pages/DashboardPage';
import { SynopticPage } from './pages/SynopticPage';
import { ProductionPage } from './pages/ProductionPage';
import { RecipesPage } from './pages/RecipesPage';
import { AlarmsPage } from './pages/AlarmsPage';
import { ClientsPage } from './pages/ClientsPage';
import { ParametersPage } from './pages/ParametersPage';
import { CommunicationPage } from './pages/CommunicationPage';
import { UsersPage } from './pages/UsersPage';
import { DeveloperPage } from './pages/DeveloperPage';
import { MaintenancePage } from './pages/MaintenancePage';
import { startSimulator, stopSimulator } from './services/simulator';
import './i18n';

// =============================================
// HISTORY PAGE (simple)
// =============================================
const HistoryPage: React.FC = () => {
  const { theme, productionBatches } = useStore();
  const isDark = theme === 'dark';
  const [search, setSearch] = useState('');

  const filtered = productionBatches.filter(b => {
    if (!search) return true;
    const s = search.toLowerCase();
    return b.recipeName?.toLowerCase().includes(s) || b.clientName?.toLowerCase().includes(s) || b.batchNumber?.toLowerCase().includes(s);
  });

  // Group by day
  const grouped: Record<string, typeof filtered> = {};
  filtered.forEach(b => {
    const day = b.startTime ? new Date(b.startTime).toLocaleDateString('fr-FR') : 'Sans date';
    if (!grouped[day]) grouped[day] = [];
    grouped[day].push(b);
  });

  return (
    <div className={`h-full overflow-auto p-4 ${isDark ? 'bg-slate-900 text-white' : 'bg-slate-50 text-slate-900'}`}>
      <div className="max-w-5xl mx-auto space-y-4">
        {/* Stats summary */}
        <div className="grid grid-cols-3 gap-3">
          {[
            { label: 'Total gâchées', value: productionBatches.length, color: 'text-blue-400' },
            { label: 'Volume total', value: `${productionBatches.reduce((a, b) => a + (b.quantityProduced || 0), 0).toFixed(0)} m³`, color: 'text-orange-400' },
            { label: 'Taux succès', value: `${productionBatches.length > 0 ? ((productionBatches.filter(b => b.status === 'completed').length / productionBatches.length) * 100).toFixed(0) : 100}%`, color: 'text-green-400' },
          ].map((s, i) => (
            <div key={i} className={`rounded-xl border p-4 ${isDark ? 'bg-slate-800 border-slate-700' : 'bg-white border-slate-200'}`}>
              <div className={`text-2xl font-black ${s.color}`}>{s.value}</div>
              <div className={`text-xs ${isDark ? 'text-slate-400' : 'text-slate-500'}`}>{s.label}</div>
            </div>
          ))}
        </div>

        <input
          type="text" value={search} onChange={e => setSearch(e.target.value)}
          placeholder="Rechercher dans l'historique..."
          className={`w-full px-4 py-2.5 rounded-xl border text-sm ${isDark ? 'bg-slate-800 border-slate-700 text-white' : 'bg-white border-slate-200'}`}
        />

        {Object.entries(grouped).map(([day, batches]) => (
          <div key={day}>
            <div className={`text-xs font-bold mb-2 px-1 ${isDark ? 'text-slate-400' : 'text-slate-500'}`}>
              📅 {day} — {batches.length} gâchées · {batches.reduce((a, b) => a + (b.quantityProduced || 0), 0).toFixed(0)} m³
            </div>
            <div className={`rounded-xl border overflow-hidden ${isDark ? 'bg-slate-800 border-slate-700' : 'bg-white border-slate-200'}`}>
              {batches.map((b, i) => (
                <div key={b.id} className={`flex items-center gap-4 px-4 py-3 text-sm ${i > 0 ? (isDark ? 'border-t border-slate-700' : 'border-t border-slate-100') : ''}`}>
                  <span className="font-mono font-bold text-orange-400 text-xs w-20">{b.batchNumber}</span>
                  <span className={`font-medium flex-1 ${isDark ? 'text-white' : 'text-slate-900'}`}>{b.recipeName}</span>
                  <span className={`text-xs ${isDark ? 'text-slate-400' : 'text-slate-500'}`}>{b.clientName || '—'}</span>
                  <span className="text-xs text-blue-400 font-bold">{b.quantityProduced} m³</span>
                  <span className={`text-xs px-2 py-0.5 rounded-full ${b.status === 'completed' ? 'bg-green-500/20 text-green-400' : 'bg-red-500/20 text-red-400'}`}>
                    {b.status === 'completed' ? '✓' : '✗'}
                  </span>
                  <span className={`text-xs ${isDark ? 'text-slate-500' : 'text-slate-400'}`}>
                    {b.startTime ? new Date(b.startTime).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' }) : '—'}
                  </span>
                </div>
              ))}
            </div>
          </div>
        ))}
        {filtered.length === 0 && (
          <div className={`text-center py-16 ${isDark ? 'text-slate-500' : 'text-slate-400'}`}>Aucune entrée dans l'historique</div>
        )}
      </div>
    </div>
  );
};

// =============================================
// APP PRINCIPAL
// =============================================
function App() {
  const { auth, theme, simulatorState } = useStore();
  const [currentPage, setCurrentPage] = useState('dashboard');
  const [initialized, setInitialized] = useState(false);

  // Apply theme to document
  useEffect(() => {
    document.documentElement.classList.toggle('dark', theme === 'dark');
    if (theme === 'dark') {
      document.documentElement.style.colorScheme = 'dark';
    } else {
      document.documentElement.style.colorScheme = 'light';
    }
  }, [theme]);

  // Start/stop simulator
  useEffect(() => {
    if (simulatorState.enabled) {
      startSimulator();
    } else {
      stopSimulator();
    }
    return () => stopSimulator();
  }, [simulatorState.enabled]);

  // Handle login/logout page redirect
  useEffect(() => {
    if (!auth.isAuthenticated && currentPage !== 'login') {
      setCurrentPage('login');
    }
  }, [auth.isAuthenticated]);

  if (!auth.isAuthenticated) {
    return (
      <div className={theme === 'dark' ? 'dark' : ''}>
        <LoginPage onLogin={() => setCurrentPage('dashboard')} />
      </div>
    );
  }

  const renderPage = () => {
    switch (currentPage) {
      case 'dashboard': return <DashboardPage />;
      case 'synoptic': return <SynopticPage />;
      case 'production': return <ProductionPage />;
      case 'recipes': return <RecipesPage />;
      case 'alarms': return <AlarmsPage />;
      case 'history': return <HistoryPage />;
      case 'clients': return <ClientsPage />;
      case 'maintenance': return <MaintenancePage />;
      case 'parameters': return <ParametersPage />;
      case 'users': return <UsersPage />;
      case 'communication': return <CommunicationPage />;
      case 'developer': return <DeveloperPage />;
      default: return <DashboardPage />;
    }
  };

  return (
    <div className={theme === 'dark' ? 'dark' : ''} style={{ height: '100vh', overflow: 'hidden' }}>
      <Layout currentPage={currentPage} onNavigate={setCurrentPage}>
        {renderPage()}
      </Layout>
    </div>
  );
}

export default App;
