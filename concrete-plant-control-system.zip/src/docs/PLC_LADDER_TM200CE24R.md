# Programme API - Schneider TM200CE24R
## Centrale à Béton - Ladder Diagram (LD)
### Standard IEC 61131-3

---

## ARCHITECTURE DU PROJET API

```
Projet: BETPRO_CENTRAL
├── Programme: MAIN
│   ├── Section: INIT (initialisation)
│   ├── Section: SÉCURITÉS (interlocks critique)
│   ├── Section: WATCHDOG
│   ├── Section: MODES (AUTO/MANU)
│   ├── Section: SEQUENCE_AUTO
│   │   ├── SR0: ATTENTE
│   │   ├── SR1: DOSAGE_AGREGATS
│   │   ├── SR2: DOSAGE_CIMENT
│   │   ├── SR3: DOSAGE_EAU
│   │   ├── SR4: DOSAGE_ADJUVANT
│   │   ├── SR5: MALAXAGE
│   │   ├── SR6: VIDANGE
│   │   └── SR7: FIN
│   ├── Section: VERINS (commande et impulsions)
│   ├── Section: MOTEURS (contacteurs et protections)
│   ├── Section: SKIP
│   ├── Section: MALAXEUR
│   ├── Section: BALANCE
│   ├── Section: ALARMES
│   └── Section: COMMUNICATION_MODBUS
├── Programme: DIAGNOSTICS
└── Programme: COMMS
```

---

## VARIABLES / TYPES DE DONNÉES

### Variables Entrées (I - Inputs)
```
%I0.0  : EA_GENERAL         (Arrêt urgence général - NC)
%I0.1  : EA_ZONE_MALAXEUR   (Arrêt urgence zone malaxeur - NC)
%I0.2  : SEL_AUTO_MANU      (Sélecteur AUTO/MANU - NO)
%I0.3  : BP_DEPART          (Bouton départ cycle - NO)
%I0.4  : BP_ARRET           (Bouton arrêt cycle - NC)
%I0.5  : FDC_SKIP_BAS       (Fin de course skip position basse - NO)
%I0.6  : FDC_SKIP_HAUT      (Fin de course skip position haute - NO)
%I0.7  : SEC_SKIP_HAUT      (Sécurité skip position très haute - NC)
%I1.0  : SEC_CABLE_SKIP     (Détecteur rupture câble skip - NC)
%I1.1  : PROT_MOT_MALAXEUR  (Protection thermique malaxeur - NC)
%I1.2  : PROT_MOT_SKIP      (Protection thermique skip - NC)
%I1.3  : NV_BAS_EAU1        (Niveau bas réservoir eau 1 - NO)
%I1.4  : NV_BAS_CIM1        (Niveau bas silo ciment 1 - NO)
%I1.5  : NV_BAS_CIM2        (Niveau bas silo ciment 2 - NO)
```

### Variables Sorties (Q - Outputs)
```
%Q0.0  : VER_T1_OUV         (Vérin trémie 1 ouverture)
%Q0.1  : VER_T1_FER         (Vérin trémie 1 fermeture)
%Q0.2  : VER_T2_OUV         (Vérin trémie 2 ouverture)
%Q0.3  : VER_T2_FER         (Vérin trémie 2 fermeture)
%Q0.4  : VER_T3_OUV         (Vérin trémie 3 ouverture)
%Q0.5  : VER_T3_FER         (Vérin trémie 3 fermeture)
%Q0.6  : VIS_CIM1           (Vis doseuse silo ciment 1)
%Q0.7  : VIS_CIM2           (Vis doseuse silo ciment 2)
%Q0.8  : POMPE_EAU1         (Pompe eau 1)
%Q0.9  : POMPE_ADJ1         (Pompe adjuvant 1)
```

### Registres Holding (MW - Mémoire Word)
```
%MW0   : ETAT_SEQUENCE      (0=Arrêt, 1=Agr, 2=Cim, 3=Eau, 4=Adj, 5=Mix, 6=Vid, 7=Fin)
%MW1   : CONSIGNE_AGR_KG    (Consigne poids agrégats × 10, ex: 16000 = 1600.0 kg)
%MW2   : POIDS_AGR_KG       (Poids balance agrégats × 10)
%MW3   : CONSIGNE_CIM_KG    (Consigne poids ciment × 10)
%MW4   : POIDS_CIM_KG       (Poids balance ciment × 10)
%MW5   : CONSIGNE_EAU_L     (Consigne volume eau × 10)
%MW6   : VOLUME_EAU_L       (Volume eau dosé × 10)
%MW7   : CONSIGNE_ADJ_L     (Consigne volume adjuvant × 10)
%MW8   : VOLUME_ADJ_L       (Volume adjuvant dosé × 10)
%MW9   : TEMPS_MALAXAGE_S   (Durée malaxage en secondes)
%MW10  : CODE_ALARME         (Dernier code alarme: 0=Aucune, 1=EA, 2=Surcharge, ...)
%MW11  : COURANT_MALAXEUR   (Courant moteur malaxeur × 10 en Ampères)
%MW12  : TEMPS_CYCLE_S       (Durée gâchée en cours en secondes)
%MW13  : SEUIL_IMPULSION     (Seuil % poids pour mode impulsionnel × 100)
%MW14  : TEMPO_IMP_ON_MS    (Durée impulsion ON en ms)
%MW15  : TEMPO_IMP_OFF_MS   (Durée impulsion OFF en ms)
%MW100 : WATCHDOG_SCADA      (Compteur watchdog depuis SCADA)
%MW101 : WATCHDOG_PLC        (Compteur watchdog PLC → SCADA)
```

### Variables Internes (M - Mémoires Bits)
```
%M0    : INIT_OK             (Initialisation terminée)
%M1    : MODE_AUTO           (Mode automatique actif)
%M2    : DEFAUT_GENERAL      (Défaut général)
%M3    : DEFAUT_EA           (Arrêt urgence)
%M4    : DEFAUT_MOTEUR_MAL   (Défaut moteur malaxeur)
%M5    : DEFAUT_MOTEUR_SKIP  (Défaut moteur skip)
%M6    : DEFAUT_COMM         (Défaut communication SCADA)
%M7    : CYCLE_EN_COURS      (Gâchée en production)
%M10   : VERROUILLAGE_TOTAL  (Interlock général actif)
%M20   : BALANCE_STABLE      (Balance agrégats stable)
%M21   : BALANCE_TOLERANCE   (Balance en tolérance)
%M30   : MODE_IMPULSION       (Mode dosage impulsionnel actif)
%M31   : IMP_ETAT_ON         (État impulsion ON/OFF)
```

---

## SECTIONS LADDER

### SECTION: SÉCURITÉS (Priorité maximale - exécution 1er)

```ladder
RÉSEAU 1 - Arrêt Urgence Global
╔══════════════════════════════════════════╗
║ EA_GENERAL  EA_ZONE_MALAXEUR             ║
║   [/]            [/]         [DEFAUT_EA] ║
║──┤NC├────────────┤NC├──────────(SET)─────║
╚══════════════════════════════════════════╝

RÉSEAU 2 - Déverrouillage EA (manuelle)
╔════════════════════════════════════════════════╗
║ EA_GENERAL  EA_ZONE_MAL  BP_RESET_EA           ║
║   [/]          [/]          [/]    [DEFAUT_EA] ║
║──┤NO├────────────┤NO├────────┤NO├──────(RST)───║
╚════════════════════════════════════════════════╝

RÉSEAU 3 - Verrouillage total
╔══════════════════════════════════════════════════════╗
║ DEFAUT_EA  DEFAUT_MOT_MAL  DEFAUT_MOT_SKIP          ║
║   [NO]         [NO]            [NO]    [VERROU_TOT] ║
║──┤├──────────┤├───────────────┤├──────────(=)───────║
╚══════════════════════════════════════════════════════╝
```

### SECTION: WATCHDOG COMMUNICATION

```ladder
RÉSEAU 10 - Watchdog SCADA → PLC
╔════════════════════════════════════════════════════════╗
║ %MW100 change toutes 200ms sinon timeout 3s → DEFAUT  ║
║                                                        ║
║ [COMPARE] %MW100 = %MW100_PREV                        ║
║    │NO──────[TON T_WDOG preset:3000ms]                ║
║    │            │Q─────[DEFAUT_COMM](SET)             ║
║    │                                                   ║
║    │NO──[RST T_WDOG][DEFAUT_COMM RST][MW100_PREV←MW100]
╚════════════════════════════════════════════════════════╝
```

### SECTION: MODES AUTO/MANU

```ladder
RÉSEAU 20 - Sélection Mode
╔═══════════════════════════════════╗
║ SEL_AUTO_MANU  !DEFAUT_GENERAL    ║
║     [NO]            [NC]   [AUTO] ║
║──┤├─────────────────┤├──────(=)───║
╚═══════════════════════════════════╝
```

### SECTION: SÉQUENCE AUTOMATIQUE

```
SR0 - ÉTAT ATTENTE (IDLE)
══════════════════════
Conditions de passage SR0 → SR1:
  - MODE_AUTO = 1
  - DEFAUT_GENERAL = 0
  - MW0 (ETAT_SEQUENCE) = 0
  - BP_DEPART = 1 (front montant)
  - Consignes recette chargées (MW1 > 0)

RÉSEAU 30 - Transition IDLE → DOSAGE AGRÉGATS
╔═════════════════════════════════════════════════════════════╗
║ M_AUTO  !DEFAUT  !CYCLE  BP_DEP_FM  MW1>0  SKIP_BAS        ║
║  [NO]    [NC]     [NC]    [↑NO]     [>0]   [NO]  [SR0→SR1] ║
║──┤├──────┤├───────┤├──────┤├─────────┤├─────┤├──────(=)────║
╚═════════════════════════════════════════════════════════════╝

SR1 - DOSAGE AGRÉGATS
══════════════════════
Action: Ouvrir vérins trémies selon recette
        Gérer mode impulsionnel si % atteint
        Surveiller poids balance

RÉSEAU 31 - Commande vérins trémie 1 (mode normal)
╔═════════════════════════════════════════════════════════╗
║ SR1_ACTIF  !MODE_IMP  !TOLERANCE  POIDS<CONSIGNE       ║
║   [NO]       [NC]       [NC]        [<]    [VER_T1_OUV] ║
║──┤├──────────┤├──────────┤├──────────┤├────────(=)──────║
╚═════════════════════════════════════════════════════════╝

RÉSEAU 32 - Basculement mode impulsionnel
╔══════════════════════════════════════════════════════════════╗
║ SR1_ACTIF  POIDS >= (CONSIGNE × SEUIL_IMP / 100)           ║
║   [NO]           [>=]                    [MODE_IMP](SET)    ║
║──┤├──────────────┤├───────────────────────────(SET)─────────║
╚══════════════════════════════════════════════════════════════╝

RÉSEAU 33 - Impulsion ON
╔══════════════════════════════════════════════════════════════╗
║ MODE_IMP  IMP_ON_STATE  !TOLERANCE                          ║
║  [NO]        [NO]          [NC]    [TON T_IMP_ON preset:MW14]
║──┤├──────────┤├──────────────────────────(TON)─────────────║
║                                  T_IMP_ON.Q → IMP_STATE=OFF║
╚══════════════════════════════════════════════════════════════╝

RÉSEAU 34 - Impulsion OFF  
╔══════════════════════════════════════════════════════════════╗
║ MODE_IMP  IMP_OFF_STATE                                     ║
║  [NO]        [NO]      [TON T_IMP_OFF preset:MW15]          ║
║──┤├──────────┤├────────────────────────(TON)────────────────║
║                          T_IMP_OFF.Q → IMP_STATE=ON         ║
╚══════════════════════════════════════════════════════════════╝

RÉSEAU 35 - Sortie vérin en mode impulsion
╔═══════════════════════════════════════════╗
║ MODE_IMP  IMP_ON_STATE  T_REC_AGR       ║
║  [NO]        [NO]          [NO]  [VER_OUV]║
║──┤├──────────┤├────────────┤├──────(=)────║
╚═══════════════════════════════════════════╝

SR2 - DOSAGE CIMENT
══════════════════════
Transition: Poids agrégats en tolérance (±5kg)
Action: Activer vis doseuse silo sélectionné

SR3 - DOSAGE EAU
══════════════════
Transition: Poids ciment en tolérance
Action: Activer pompe eau, débitmètre

SR4 - DOSAGE ADJUVANT
═══════════════════════
Transition: Volume eau atteint
Action: Activer pompe adjuvant si >0

SR5 - MALAXAGE
══════════════════
Transition: Tous dosages OK
Action: Démarrer malaxeur, chrono malaxage

RÉSEAU 50 - Démarrage malaxeur
╔════════════════════════════════════════════════╗
║ SR5_ACTIF  !PROT_MOT_MAL  !DEFAUT_EA          ║
║   [NO]         [NC]           [NC]   [MOT_MAL] ║
║──┤├────────────┤├─────────────┤├───────(=)──────║
╚════════════════════════════════════════════════╝

RÉSEAU 51 - Temporisation malaxage
╔═══════════════════════════════════════════════════╗
║ SR5_ACTIF  MOT_MAL_RETOUR                        ║
║   [NO]         [NO]     [TON T_MALAX preset:MW9] ║
║──┤├────────────┤├─────────────────────(TON)───────║
║                          T_MALAX.Q → SR5→SR6     ║
╚═══════════════════════════════════════════════════╝

SR6 - VIDANGE MALAXEUR
════════════════════════
Transition: Temps malaxage écoulé
Action: Ouvrir trappe malaxeur, démarrer skip

RÉSEAU 60 - Ouverture trappe vidange
╔══════════════════════════════════════════════════╗
║ SR6_ACTIF  !DEFAUT_EA                           ║
║   [NO]         [NC]   [TRAPPE_MAL_OUV]          ║
║──┤├────────────┤├────────────(SET)───────────────║
╚══════════════════════════════════════════════════╝

RÉSEAU 61 - Démarrage skip
╔══════════════════════════════════════════════════════════╗
║ SR6_ACTIF  SKIP_POS_BAS  !SEC_SKIP_HAUT  !SEC_CABLE    ║
║   [NO]        [NO]           [NC]             [NC]      ║
║──┤├────────────┤├─────────────┤├──────────────┤├────(=)─║
║                                                [MOT_SKIP]║
╚══════════════════════════════════════════════════════════╝

SR7 - FIN CYCLE
═════════════════
Transition: Skip en position haute + trappe fermée
Action: Remise à zéro, MW0=0, attente gâchée suivante
```

---

## GESTION ALARMES (Section ALARMES)

```ladder
RÉSEAU 80 - Alarme arrêt urgence
╔═══════════════════════════════════════════════════════╗
║ DEFAUT_EA                          [ALM_EA](SET)     ║
║   [NO]──────────────────────────────(SET)─────────────║
║                  MW10 ← 1 (code alarme EA)           ║
╚═══════════════════════════════════════════════════════╝

RÉSEAU 81 - Alarme surcharge malaxeur
╔════════════════════════════════════════════════════════╗
║ PROT_MOT_MAL_OUV  [TON T_ALM_MAL preset:MW15_TEMPO]  ║
║      [NO]───────────────────────────(TON)─────────────║
║                    T_ALM_MAL.Q → ALM_SURCHARGE(SET)  ║
╚════════════════════════════════════════════════════════╝

RÉSEAU 82 - Alarme timeout skip
╔═════════════════════════════════════════════════════════╗
║ MOT_SKIP_EN_MARCHE  !FDC_SKIP_HAUT  T_TIMEOUT_SKIP    ║
║      [NO]               [NC]       [TON preset:30000]  ║
║──┤├────────────────────────────────────────(TON)────────║
║                           T_TIMEOUT.Q → ALM_SKIP(SET)  ║
╚═════════════════════════════════════════════════════════╝

RÉSEAU 83 - Alarme communication SCADA
╔═══════════════════════════════════════════╗
║ DEFAUT_COMM                   [ALM_COMM]  ║
║   [NO]──────────────────────────(SET)─────║
╚═══════════════════════════════════════════╝
```

---

## COMMUNICATION MODBUS TCP

### Configuration TM200CE24R:
```
Protocole: Modbus TCP Serveur (Esclave)
Port: 502
Unit ID: 1
Adresse IP: 192.168.1.100 (configurée via SoMachine)
```

### Mapping Mémoire Automate → Modbus:
```
Coils (0x): Accès lecture/écriture
  00000 - 00013: Entrées numériques (%I0.0..%I1.5)
  00020 - 00029: Sorties numériques (%Q0.0..%Q0.9)
  
Discrete Inputs (1x): Lecture seule
  10000 - 10015: État interlocks et défauts (%M0..%M15)
  
Holding Registers (4x): Lecture/écriture
  40000 = %MW0  : ETAT_SEQUENCE
  40001 = %MW1  : CONSIGNE_AGREGATS (× 10)
  40002 = %MW2  : POIDS_AGREGATS (× 10)
  40003 = %MW3  : CONSIGNE_CIMENT (× 10)
  40004 = %MW4  : POIDS_CIMENT (× 10)
  40005 = %MW5  : CONSIGNE_EAU
  40006 = %MW6  : VOLUME_EAU
  40007 = %MW7  : CONSIGNE_ADJUVANT
  40008 = %MW8  : VOLUME_ADJUVANT
  40009 = %MW9  : TEMPS_MALAXAGE
  40010 = %MW10 : CODE_ALARME
  40011 = %MW11 : COURANT_MALAXEUR (× 10)
  40012 = %MW12 : TEMPS_CYCLE
  40100 = %MW100: WATCHDOG_SCADA
  40101 = %MW101: WATCHDOG_PLC
```

---

## FICHIER PROJET SCHNEIDER (*.smbp)

Le fichier projet complet SoMachine Basic (*.smbp) doit être:
1. Créé via SoMachine Basic v1.6+ ou EcoStruxure Machine Expert Basic
2. Compilé et téléchargé dans le TM200CE24R
3. Archivé: `BETPRO_CENTRAL_v2.smbp`

### Structure du fichier .smbp (XML):
```xml
<?xml version="1.0" encoding="utf-8"?>
<SoMachineBasicProject Version="1.6.0.0">
  <ProjectHeader>
    <Name>BETPRO_CENTRAL</Name>
    <Description>Centrale à béton - Supervision SCADA</Description>
    <Author>BétonPro Engineering</Author>
    <Version>2.0.0</Version>
    <Date>2024-01-15</Date>
    <Hardware>TM200CE24R</Hardware>
  </ProjectHeader>
  <NetworkConfig>
    <IP>192.168.1.100</IP>
    <Mask>255.255.255.0</Mask>
    <Gateway>192.168.1.1</Gateway>
    <ModbusTCP enabled="true" port="502" unitId="1"/>
  </NetworkConfig>
  <!-- Sections Ladder définies dans le code ci-dessus -->
</SoMachineBasicProject>
```

---

## SÉQUENCE COMPLÈTE (Diagramme d'états)

```
┌──────────────────────────────────────────────────────────────┐
│                    MACHINE D'ÉTAT AUTOMATE                   │
│                                                              │
│  ┌─────────┐  BP_DEP  ┌──────────────┐  OK   ┌──────────┐  │
│  │  SR0    │ ────────→ │     SR1      │ ────→ │   SR2    │  │
│  │ ATTENTE │           │ DOS AGRÉGATS │       │ DOS CIM  │  │
│  └────▲────┘           └──────────────┘       └────┬─────┘  │
│       │                                           OK│        │
│  FIN  │              ┌──────────────┐           ┌──▼──────┐  │
│       │              │     SR7      │           │   SR3   │  │
│       └──────────────│  FIN CYCLE   │           │ DOS EAU │  │
│                      └──────▲───────┘           └────┬────┘  │
│                           OK │                     OK│       │
│                      ┌──────┴───────┐           ┌──▼──────┐  │
│                      │     SR6      │           │   SR4   │  │
│                      │    VIDANGE   │           │ DOS ADJ │  │
│                      └──────▲───────┘           └────┬────┘  │
│                           OK │                     OK│       │
│                      ┌──────┴───────┐  OK  ┌───────▼───────┐ │
│                      │     SR5      │ ←─── │    SYNC        │ │
│                      │   MALAXAGE   │      │ (attente tous) │ │
│                      └──────────────┘      └───────────────┘ │
│                                                              │
│  EA = Arrêt urgence → TOUS états → SR0 + Défaut             │
└──────────────────────────────────────────────────────────────┘
```
