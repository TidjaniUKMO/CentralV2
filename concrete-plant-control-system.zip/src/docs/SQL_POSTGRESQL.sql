-- ============================================================
-- BétonPro SCADA - Script SQL PostgreSQL 18.3
-- Centrale à béton - Base de données industrielle complète
-- Schneider TM200CE24R - Modbus TCP
-- ============================================================

-- ============================================================
-- CRÉATION BASE DE DONNÉES
-- ============================================================

-- Se connecter en tant que superuser postgres
-- psql -U postgres

CREATE DATABASE betonpro
    WITH
    OWNER = postgres
    ENCODING = 'UTF8'
    LC_COLLATE = 'fr_FR.UTF-8'
    LC_CTYPE = 'fr_FR.UTF-8'
    TABLESPACE = pg_default
    CONNECTION LIMIT = -1
    IS_TEMPLATE = False;

COMMENT ON DATABASE betonpro IS 'BétonPro SCADA - Système supervision centrale à béton';

-- Se connecter à la base
\c betonpro;

-- Extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pg_stat_statements";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ============================================================
-- SCHÉMA
-- ============================================================

CREATE SCHEMA IF NOT EXISTS scada;
SET search_path TO scada, public;

-- ============================================================
-- TABLE: UTILISATEURS
-- ============================================================

CREATE TABLE scada.users (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    username        VARCHAR(50) NOT NULL UNIQUE,
    password_hash   VARCHAR(255) NOT NULL,
    role            VARCHAR(20) NOT NULL CHECK (role IN ('admin', 'operator', 'maintenance')),
    email           VARCHAR(100),
    active          BOOLEAN NOT NULL DEFAULT true,
    last_login      TIMESTAMPTZ,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_users_username ON scada.users(username);
CREATE INDEX idx_users_role ON scada.users(role);

COMMENT ON TABLE scada.users IS 'Utilisateurs système SCADA';

-- Utilisateurs par défaut (mot de passe hashé avec bcrypt)
INSERT INTO scada.users (username, password_hash, role, email) VALUES
    ('admin',       crypt('admin123', gen_salt('bf')),    'admin',       'admin@betonpro.local'),
    ('operateur',   crypt('oper123', gen_salt('bf')),     'operator',    'operateur@betonpro.local'),
    ('maintenance', crypt('maint123', gen_salt('bf')),    'maintenance', 'maintenance@betonpro.local');

-- ============================================================
-- TABLE: PERMISSIONS
-- ============================================================

CREATE TABLE scada.permissions (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id     UUID NOT NULL REFERENCES scada.users(id) ON DELETE CASCADE,
    module      VARCHAR(50) NOT NULL,
    can_read    BOOLEAN NOT NULL DEFAULT false,
    can_write   BOOLEAN NOT NULL DEFAULT false,
    can_execute BOOLEAN NOT NULL DEFAULT false,
    UNIQUE(user_id, module)
);

CREATE INDEX idx_permissions_user_id ON scada.permissions(user_id);

-- ============================================================
-- TABLE: CONFIGURATION CENTRALE
-- ============================================================

CREATE TABLE scada.plant_config (
    id                      UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    plant_name              VARCHAR(100) NOT NULL,
    skip_type               VARCHAR(20) NOT NULL DEFAULT 'skip' CHECK (skip_type IN ('skip', 'inclined_conveyor')),
    has_skip_cable_sensor   BOOLEAN NOT NULL DEFAULT true,
    has_skip_bottom_sensor  BOOLEAN NOT NULL DEFAULT true,
    has_skip_top_sensor     BOOLEAN NOT NULL DEFAULT true,
    discharge_confirmation  VARCHAR(10) NOT NULL DEFAULT 'timer' CHECK (discharge_confirmation IN ('timer', 'weight')),
    is_active               BOOLEAN NOT NULL DEFAULT true,
    updated_at              TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_by              UUID REFERENCES scada.users(id)
);

-- ============================================================
-- TABLE: TRÉMIES AGRÉGATS
-- ============================================================

CREATE TABLE scada.hoppers (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    plant_config_id     UUID NOT NULL REFERENCES scada.plant_config(id) ON DELETE CASCADE,
    name                VARCHAR(100) NOT NULL,
    hopper_index        INTEGER NOT NULL,
    discharge_mode      VARCHAR(20) NOT NULL DEFAULT 'piston' CHECK (discharge_mode IN ('piston', 'conveyor')),
    has_vibrator        BOOLEAN NOT NULL DEFAULT false,
    modbus_coil_open    INTEGER NOT NULL DEFAULT 0,
    modbus_coil_close   INTEGER NOT NULL DEFAULT 1,
    modbus_sensor_full  INTEGER NOT NULL DEFAULT 0,
    modbus_sensor_empty INTEGER NOT NULL DEFAULT 1,
    active              BOOLEAN NOT NULL DEFAULT true,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_hoppers_plant_config ON scada.hoppers(plant_config_id);
COMMENT ON TABLE scada.hoppers IS 'Trémies agrégats de la centrale';

-- ============================================================
-- TABLE: SILOS CIMENT
-- ============================================================

CREATE TABLE scada.silos (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    plant_config_id     UUID NOT NULL REFERENCES scada.plant_config(id) ON DELETE CASCADE,
    name                VARCHAR(100) NOT NULL,
    silo_index          INTEGER NOT NULL,
    capacity_kg         DECIMAL(10,2) NOT NULL DEFAULT 60000,
    modbus_level_low    INTEGER NOT NULL DEFAULT 0,
    modbus_level_high   INTEGER NOT NULL DEFAULT 0,
    modbus_discharge    INTEGER NOT NULL DEFAULT 0,
    active              BOOLEAN NOT NULL DEFAULT true,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_silos_plant_config ON scada.silos(plant_config_id);

-- ============================================================
-- TABLE: RÉSERVOIRS EAU
-- ============================================================

CREATE TABLE scada.water_tanks (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    plant_config_id UUID NOT NULL REFERENCES scada.plant_config(id) ON DELETE CASCADE,
    name            VARCHAR(100) NOT NULL,
    tank_index      INTEGER NOT NULL,
    capacity_liters DECIMAL(10,2) NOT NULL DEFAULT 5000,
    modbus_level    INTEGER NOT NULL DEFAULT 0,
    modbus_pump     INTEGER NOT NULL DEFAULT 0,
    active          BOOLEAN NOT NULL DEFAULT true
);

-- ============================================================
-- TABLE: RÉSERVOIRS ADJUVANT
-- ============================================================

CREATE TABLE scada.adjuvant_tanks (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    plant_config_id UUID NOT NULL REFERENCES scada.plant_config(id) ON DELETE CASCADE,
    name            VARCHAR(100) NOT NULL,
    tank_index      INTEGER NOT NULL,
    capacity_liters DECIMAL(10,2) NOT NULL DEFAULT 1000,
    modbus_level    INTEGER NOT NULL DEFAULT 0,
    modbus_pump     INTEGER NOT NULL DEFAULT 0,
    active          BOOLEAN NOT NULL DEFAULT true
);

-- ============================================================
-- TABLE: CONFIGURATION MODBUS
-- ============================================================

CREATE TABLE scada.modbus_config (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    plc_ip          INET NOT NULL DEFAULT '192.168.1.100',
    plc_port        INTEGER NOT NULL DEFAULT 502 CHECK (plc_port > 0 AND plc_port < 65536),
    unit_id         INTEGER NOT NULL DEFAULT 1 CHECK (unit_id >= 1 AND unit_id <= 247),
    timeout_ms      INTEGER NOT NULL DEFAULT 3000,
    refresh_rate_ms INTEGER NOT NULL DEFAULT 200,
    reconnect_ms    INTEGER NOT NULL DEFAULT 5000,
    max_retries     INTEGER NOT NULL DEFAULT 3,
    is_active       BOOLEAN NOT NULL DEFAULT true,
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ============================================================
-- TABLE: TAGS MODBUS (Mapping E/S)
-- ============================================================

CREATE TABLE scada.modbus_tags (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name        VARCHAR(100) NOT NULL,
    address     INTEGER NOT NULL,
    tag_type    VARCHAR(30) NOT NULL CHECK (tag_type IN ('coil', 'discrete_input', 'holding_register', 'input_register')),
    description TEXT,
    unit        VARCHAR(20),
    scale       DECIMAL(10,4) DEFAULT 1.0,
    offset_val  DECIMAL(10,4) DEFAULT 0.0,
    min_val     DECIMAL(15,4),
    max_val     DECIMAL(15,4),
    active      BOOLEAN NOT NULL DEFAULT true,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE UNIQUE INDEX idx_modbus_tags_address_type ON scada.modbus_tags(address, tag_type);

-- ============================================================
-- TABLE: TEMPORISATIONS
-- ============================================================

CREATE TABLE scada.timers (
    id                      UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    valve_open_ms           INTEGER NOT NULL DEFAULT 3000,
    valve_close_ms          INTEGER NOT NULL DEFAULT 2000,
    conveyor_start_ms       INTEGER NOT NULL DEFAULT 5000,
    skip_time_ms            INTEGER NOT NULL DEFAULT 30000,
    mixing_time_ms          INTEGER NOT NULL DEFAULT 60000,
    safety_timeout_ms       INTEGER NOT NULL DEFAULT 10000,
    alarm_timeout_ms        INTEGER NOT NULL DEFAULT 5000,
    discharge_timeout_ms    INTEGER NOT NULL DEFAULT 120000,
    cement_flow_timeout_ms  INTEGER NOT NULL DEFAULT 30000,
    water_flow_timeout_ms   INTEGER NOT NULL DEFAULT 20000,
    updated_at              TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_by              UUID REFERENCES scada.users(id)
);

INSERT INTO scada.timers DEFAULT VALUES;

-- ============================================================
-- TABLE: CONFIGURATION IMPULSIONS
-- ============================================================

CREATE TABLE scada.impulse_config (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    enabled             BOOLEAN NOT NULL DEFAULT true,
    trigger_percent     DECIMAL(5,2) NOT NULL DEFAULT 90.0 CHECK (trigger_percent >= 50 AND trigger_percent <= 99),
    impulse_on_ms       INTEGER NOT NULL DEFAULT 500 CHECK (impulse_on_ms >= 50),
    impulse_off_ms      INTEGER NOT NULL DEFAULT 300 CHECK (impulse_off_ms >= 50),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_by          UUID REFERENCES scada.users(id)
);

INSERT INTO scada.impulse_config DEFAULT VALUES;

-- ============================================================
-- TABLE: CLIENTS
-- ============================================================

CREATE TABLE scada.clients (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name        VARCHAR(150) NOT NULL,
    client_type VARCHAR(20) NOT NULL DEFAULT 'company' CHECK (client_type IN ('company', 'individual')),
    phone       VARCHAR(30),
    email       VARCHAR(100),
    address     TEXT,
    active      BOOLEAN NOT NULL DEFAULT true,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_clients_name ON scada.clients(name);
CREATE INDEX idx_clients_type ON scada.clients(client_type);

-- Clients par défaut
INSERT INTO scada.clients (name, client_type, phone, email, address) VALUES
    ('BTP Construction SARL', 'company',    '+33 1 23 45 67 89', 'contact@btpconstruct.fr', '15 Rue de la Construction, 75001 Paris'),
    ('Maçonnerie Dupont',     'company',    '+33 6 12 34 56 78', 'dupont@maconnerie.fr',    '8 Avenue du Bâtiment, 69002 Lyon'),
    ('Martin Jean-Pierre',    'individual', '+33 6 98 76 54 32', NULL,                      '25 Rue des Lilas, 13001 Marseille');

-- ============================================================
-- TABLE: CAMIONS
-- ============================================================

CREATE TABLE scada.trucks (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    client_id   UUID NOT NULL REFERENCES scada.clients(id) ON DELETE CASCADE,
    plate       VARCHAR(20) NOT NULL,
    model       VARCHAR(100),
    capacity_m3 DECIMAL(5,2) NOT NULL DEFAULT 8.0,
    active      BOOLEAN NOT NULL DEFAULT true,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_trucks_client ON scada.trucks(client_id);
CREATE UNIQUE INDEX idx_trucks_plate ON scada.trucks(plate);

-- ============================================================
-- TABLE: CHAUFFEURS
-- ============================================================

CREATE TABLE scada.drivers (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    client_id   UUID NOT NULL REFERENCES scada.clients(id) ON DELETE CASCADE,
    name        VARCHAR(100) NOT NULL,
    phone       VARCHAR(30),
    license     VARCHAR(20),
    active      BOOLEAN NOT NULL DEFAULT true,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_drivers_client ON scada.drivers(client_id);

-- ============================================================
-- TABLE: RECETTES
-- ============================================================

CREATE TABLE scada.recipes (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    code            VARCHAR(20) NOT NULL UNIQUE,
    name            VARCHAR(150) NOT NULL,
    description     TEXT,
    water_volume_l  DECIMAL(10,2) NOT NULL DEFAULT 0,
    adjuvant_vol_l  DECIMAL(10,2) NOT NULL DEFAULT 0,
    mixing_time_s   INTEGER NOT NULL DEFAULT 90,
    total_weight_kg DECIMAL(10,2) NOT NULL DEFAULT 0,
    volume_m3       DECIMAL(8,4) NOT NULL DEFAULT 1.0,
    usage_count     INTEGER NOT NULL DEFAULT 0,
    active          BOOLEAN NOT NULL DEFAULT true,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_by      UUID REFERENCES scada.users(id)
);

CREATE INDEX idx_recipes_code ON scada.recipes(code);
CREATE INDEX idx_recipes_name ON scada.recipes(name);

-- ============================================================
-- TABLE: COMPOSANTS RECETTE - AGRÉGATS
-- ============================================================

CREATE TABLE scada.recipe_aggregates (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    recipe_id   UUID NOT NULL REFERENCES scada.recipes(id) ON DELETE CASCADE,
    hopper_id   UUID NOT NULL REFERENCES scada.hoppers(id),
    hopper_name VARCHAR(100) NOT NULL,
    weight_kg   DECIMAL(10,2) NOT NULL CHECK (weight_kg >= 0),
    sort_order  INTEGER NOT NULL DEFAULT 0
);

CREATE INDEX idx_recipe_aggregates_recipe ON scada.recipe_aggregates(recipe_id);

-- ============================================================
-- TABLE: COMPOSANTS RECETTE - CIMENT
-- ============================================================

CREATE TABLE scada.recipe_cements (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    recipe_id   UUID NOT NULL REFERENCES scada.recipes(id) ON DELETE CASCADE,
    silo_id     UUID NOT NULL REFERENCES scada.silos(id),
    silo_name   VARCHAR(100) NOT NULL,
    weight_kg   DECIMAL(10,2) NOT NULL CHECK (weight_kg >= 0),
    sort_order  INTEGER NOT NULL DEFAULT 0
);

CREATE INDEX idx_recipe_cements_recipe ON scada.recipe_cements(recipe_id);

-- ============================================================
-- TABLE: PRODUCTION (Gâchées)
-- ============================================================

CREATE TABLE scada.production_batches (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    batch_number        VARCHAR(20) NOT NULL UNIQUE,
    recipe_id           UUID REFERENCES scada.recipes(id),
    recipe_name         VARCHAR(150) NOT NULL,
    client_id           UUID REFERENCES scada.clients(id),
    client_name         VARCHAR(150),
    truck_id            UUID REFERENCES scada.trucks(id),
    truck_plate         VARCHAR(20),
    driver_id           UUID REFERENCES scada.drivers(id),
    driver_name         VARCHAR(100),
    operator_id         UUID NOT NULL REFERENCES scada.users(id),
    operator_name       VARCHAR(50) NOT NULL,
    quantity_ordered_m3 DECIMAL(8,3) NOT NULL,
    quantity_produced   DECIMAL(8,3) NOT NULL DEFAULT 0,
    status              VARCHAR(20) NOT NULL DEFAULT 'idle'
                            CHECK (status IN ('idle','running','paused','completed','aborted','error')),
    current_step        VARCHAR(30) NOT NULL DEFAULT 'idle',
    step_progress       DECIMAL(5,2) NOT NULL DEFAULT 0 CHECK (step_progress >= 0 AND step_progress <= 100),
    -- Poids cibles
    target_aggregates   DECIMAL(10,2) NOT NULL DEFAULT 0,
    target_cement       DECIMAL(10,2) NOT NULL DEFAULT 0,
    target_water        DECIMAL(10,2) NOT NULL DEFAULT 0,
    target_adjuvant     DECIMAL(10,2) NOT NULL DEFAULT 0,
    -- Poids réels dosés
    actual_aggregates   DECIMAL(10,2) NOT NULL DEFAULT 0,
    actual_cement       DECIMAL(10,2) NOT NULL DEFAULT 0,
    actual_water        DECIMAL(10,2) NOT NULL DEFAULT 0,
    actual_adjuvant     DECIMAL(10,2) NOT NULL DEFAULT 0,
    -- Timing
    start_time          TIMESTAMPTZ,
    end_time            TIMESTAMPTZ,
    duration_seconds    INTEGER,
    notes               TEXT,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_production_status ON scada.production_batches(status);
CREATE INDEX idx_production_start_time ON scada.production_batches(start_time DESC);
CREATE INDEX idx_production_client ON scada.production_batches(client_id);
CREATE INDEX idx_production_recipe ON scada.production_batches(recipe_id);
CREATE INDEX idx_production_batch_number ON scada.production_batches(batch_number);

COMMENT ON TABLE scada.production_batches IS 'Historique de toutes les gâchées produites';

-- ============================================================
-- TABLE: ALARMES
-- ============================================================

CREATE TABLE scada.alarms (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    alarm_type          VARCHAR(50) NOT NULL,
    priority            VARCHAR(20) NOT NULL CHECK (priority IN ('critical', 'warning', 'info')),
    message             TEXT NOT NULL,
    detail              TEXT,
    source              VARCHAR(100),
    active              BOOLEAN NOT NULL DEFAULT true,
    acknowledged        BOOLEAN NOT NULL DEFAULT false,
    acknowledged_by     VARCHAR(50),
    acknowledged_at     TIMESTAMPTZ,
    batch_id            UUID REFERENCES scada.production_batches(id),
    timestamp           TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    cleared_at          TIMESTAMPTZ
);

CREATE INDEX idx_alarms_active ON scada.alarms(active, acknowledged);
CREATE INDEX idx_alarms_priority ON scada.alarms(priority);
CREATE INDEX idx_alarms_timestamp ON scada.alarms(timestamp DESC);
CREATE INDEX idx_alarms_type ON scada.alarms(alarm_type);

-- ============================================================
-- TABLE: JOURNAL ÉVÉNEMENTS
-- ============================================================

CREATE TABLE scada.event_log (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    event_type  VARCHAR(50) NOT NULL,
    description TEXT NOT NULL,
    user_id     UUID REFERENCES scada.users(id),
    username    VARCHAR(50),
    batch_id    UUID REFERENCES scada.production_batches(id),
    data        JSONB,
    timestamp   TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_event_log_timestamp ON scada.event_log(timestamp DESC);
CREATE INDEX idx_event_log_type ON scada.event_log(event_type);
CREATE INDEX idx_event_log_user ON scada.event_log(user_id);

-- ============================================================
-- TABLE: MESURES TEMPS RÉEL (ARCHIVE CAPTEURS)
-- ============================================================

CREATE TABLE scada.sensor_data (
    id              BIGSERIAL PRIMARY KEY,
    tag_name        VARCHAR(100) NOT NULL,
    tag_address     INTEGER NOT NULL,
    value           DECIMAL(15,4),
    quality         VARCHAR(20) NOT NULL DEFAULT 'good' CHECK (quality IN ('good', 'bad', 'uncertain')),
    timestamp       TIMESTAMPTZ NOT NULL DEFAULT NOW()
) PARTITION BY RANGE (timestamp);

-- Partition pour le mois en cours
CREATE TABLE scada.sensor_data_current PARTITION OF scada.sensor_data
    FOR VALUES FROM (date_trunc('month', NOW())) TO (date_trunc('month', NOW()) + INTERVAL '1 month');

CREATE INDEX idx_sensor_data_timestamp ON scada.sensor_data(timestamp DESC);
CREATE INDEX idx_sensor_data_tag ON scada.sensor_data(tag_name, timestamp DESC);

-- ============================================================
-- TABLE: JOURNAL ERREURS COMMUNICATION
-- ============================================================

CREATE TABLE scada.comm_errors (
    id          BIGSERIAL PRIMARY KEY,
    error_code  VARCHAR(50) NOT NULL,
    message     TEXT NOT NULL,
    plc_ip      INET,
    address     INTEGER,
    timestamp   TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_comm_errors_timestamp ON scada.comm_errors(timestamp DESC);

-- ============================================================
-- TRIGGERS
-- ============================================================

-- Trigger: MAJ updated_at automatique
CREATE OR REPLACE FUNCTION scada.update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_users_updated_at
    BEFORE UPDATE ON scada.users
    FOR EACH ROW EXECUTE FUNCTION scada.update_updated_at();

CREATE TRIGGER trg_clients_updated_at
    BEFORE UPDATE ON scada.clients
    FOR EACH ROW EXECUTE FUNCTION scada.update_updated_at();

CREATE TRIGGER trg_recipes_updated_at
    BEFORE UPDATE ON scada.recipes
    FOR EACH ROW EXECUTE FUNCTION scada.update_updated_at();

-- Trigger: Incrément usage_count recette
CREATE OR REPLACE FUNCTION scada.increment_recipe_usage()
RETURNS TRIGGER AS $$
BEGIN
    IF NEW.status = 'completed' AND OLD.status != 'completed' THEN
        UPDATE scada.recipes SET usage_count = usage_count + 1 WHERE id = NEW.recipe_id;
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_production_recipe_usage
    AFTER UPDATE ON scada.production_batches
    FOR EACH ROW EXECUTE FUNCTION scada.increment_recipe_usage();

-- Trigger: Calcul durée production
CREATE OR REPLACE FUNCTION scada.calc_production_duration()
RETURNS TRIGGER AS $$
BEGIN
    IF NEW.end_time IS NOT NULL AND NEW.start_time IS NOT NULL THEN
        NEW.duration_seconds = EXTRACT(EPOCH FROM (NEW.end_time - NEW.start_time))::INTEGER;
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_calc_duration
    BEFORE UPDATE ON scada.production_batches
    FOR EACH ROW EXECUTE FUNCTION scada.calc_production_duration();

-- ============================================================
-- VUES
-- ============================================================

-- Vue: Production du jour
CREATE OR REPLACE VIEW scada.v_today_production AS
SELECT
    count(*) as total_batches,
    count(*) FILTER (WHERE status = 'completed') as completed,
    count(*) FILTER (WHERE status = 'aborted') as aborted,
    sum(quantity_produced) FILTER (WHERE status = 'completed') as total_volume_m3,
    avg(duration_seconds) FILTER (WHERE status = 'completed') as avg_duration_s
FROM scada.production_batches
WHERE DATE(start_time) = CURRENT_DATE;

-- Vue: Alarmes actives
CREATE OR REPLACE VIEW scada.v_active_alarms AS
SELECT
    a.*,
    b.batch_number
FROM scada.alarms a
LEFT JOIN scada.production_batches b ON a.batch_id = b.id
WHERE a.active = true AND a.acknowledged = false
ORDER BY
    CASE a.priority WHEN 'critical' THEN 1 WHEN 'warning' THEN 2 ELSE 3 END,
    a.timestamp DESC;

-- Vue: Statistiques production par recette
CREATE OR REPLACE VIEW scada.v_recipe_stats AS
SELECT
    r.id,
    r.code,
    r.name,
    count(pb.id) as total_batches,
    sum(pb.quantity_produced) as total_volume_m3,
    avg(pb.duration_seconds) as avg_duration_s,
    max(pb.start_time) as last_used
FROM scada.recipes r
LEFT JOIN scada.production_batches pb ON r.id = pb.recipe_id AND pb.status = 'completed'
GROUP BY r.id, r.code, r.name;

-- ============================================================
-- DONNÉES D'EXEMPLE - CONFIGURATION CENTRALE
-- ============================================================

-- Config centrale
INSERT INTO scada.plant_config (plant_name, skip_type, has_skip_cable_sensor, has_skip_bottom_sensor, has_skip_top_sensor)
VALUES ('Centrale à Béton N°1', 'skip', true, true, true);

-- Trémies (utiliser l'ID de la config créée)
WITH pc AS (SELECT id FROM scada.plant_config LIMIT 1)
INSERT INTO scada.hoppers (plant_config_id, name, hopper_index, discharge_mode, has_vibrator, modbus_coil_open, modbus_coil_close)
SELECT pc.id, t.name, t.idx, t.mode, t.vib, t.coil_o, t.coil_c
FROM pc, (VALUES
    ('Trémie Sable 0/4',      0, 'piston', true,  0, 1),
    ('Trémie Gravier 4/8',    1, 'piston', false, 2, 3),
    ('Trémie Gravier 8/16',   2, 'piston', false, 4, 5),
    ('Trémie Gravier 16/25',  3, 'conveyor', false, 6, 7)
) AS t(name, idx, mode, vib, coil_o, coil_c);

-- Silos
WITH pc AS (SELECT id FROM scada.plant_config LIMIT 1)
INSERT INTO scada.silos (plant_config_id, name, silo_index, capacity_kg, modbus_level_low, modbus_level_high, modbus_discharge)
SELECT pc.id, t.name, t.idx, t.cap, t.lvl_low, t.lvl_high, t.dis
FROM pc, (VALUES
    ('Silo Ciment CEM I 52.5',  0, 60000, 8,  9,  8),
    ('Silo Ciment CEM II 32.5', 1, 60000, 10, 11, 9)
) AS t(name, idx, cap, lvl_low, lvl_high, dis);

-- Recettes
INSERT INTO scada.recipes (code, name, description, water_volume_l, adjuvant_vol_l, mixing_time_s, total_weight_kg)
VALUES
    ('B25', 'Béton B25', 'Béton de structure standard C25/30', 175, 3.5, 90,  2128.5),
    ('B30', 'Béton B30', 'Béton haute performance C30/37',    160, 4.0, 120, 2214.0),
    ('BC15', 'Béton de Propreté', 'Béton courant C15',       175, 0,   60,  2125.0);

-- ============================================================
-- INDEX SUPPLÉMENTAIRES PERFORMANCE
-- ============================================================

CREATE INDEX idx_production_date ON scada.production_batches(DATE(start_time));
CREATE INDEX idx_production_operator ON scada.production_batches(operator_id);
CREATE INDEX idx_alarms_active_priority ON scada.alarms(active, priority, timestamp DESC);

-- ============================================================
-- GRANT PERMISSIONS
-- ============================================================

-- Créer rôle application
CREATE ROLE betonpro_app LOGIN PASSWORD 'betonpro_secure_2024';
GRANT USAGE ON SCHEMA scada TO betonpro_app;
GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA scada TO betonpro_app;
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA scada TO betonpro_app;

-- Rôle lecture seule pour rapports
CREATE ROLE betonpro_readonly LOGIN PASSWORD 'readonly_2024';
GRANT USAGE ON SCHEMA scada TO betonpro_readonly;
GRANT SELECT ON ALL TABLES IN SCHEMA scada TO betonpro_readonly;

-- ============================================================
-- COMMENTAIRES TABLES
-- ============================================================

COMMENT ON TABLE scada.hoppers IS 'Trémies de stockage des agrégats';
COMMENT ON TABLE scada.silos IS 'Silos de stockage du ciment';
COMMENT ON TABLE scada.recipes IS 'Recettes de béton';
COMMENT ON TABLE scada.production_batches IS 'Historique des gâchées produites';
COMMENT ON TABLE scada.alarms IS 'Historique et état des alarmes industrielles';
COMMENT ON TABLE scada.sensor_data IS 'Archive des données capteurs (partitionné par mois)';
COMMENT ON TABLE scada.modbus_config IS 'Configuration connexion Modbus TCP vers automate';
COMMENT ON TABLE scada.modbus_tags IS 'Mapping des tags Modbus (E/S automate)';

-- FIN SCRIPT SQL
-- ============================================================
-- Pour exécuter: psql -U postgres -f SQL_POSTGRESQL.sql
-- ============================================================
