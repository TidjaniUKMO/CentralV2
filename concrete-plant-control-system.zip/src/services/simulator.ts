/**
 * BétonPro SCADA - Simulateur PLC Virtuel
 * Simule les données temps réel d'une centrale à béton
 * Permet les tests sans automate physique
 */

import { useStore } from '../store';

let simulatorInterval: ReturnType<typeof setInterval> | null = null;
let productionInterval: ReturnType<typeof setInterval> | null = null;

// =============================================
// GÉNÉRATEUR DE BRUIT (simulation capteurs)
// =============================================
const noise = (value: number, amplitude: number = 0.02): number => {
  return value + (Math.random() - 0.5) * amplitude * value;
};

const clamp = (val: number, min: number, max: number): number =>
  Math.max(min, Math.min(max, val));

// =============================================
// SIMULATION TEMPS RÉEL
// =============================================
export const startSimulator = () => {
  if (simulatorInterval) return;

  console.log('[SIMULATEUR] Démarrage simulation PLC virtuel');

  simulatorInterval = setInterval(() => {
    const { realTimeState, simulatorState, currentBatch } = useStore.getState();
    if (!simulatorState.enabled) return;

    const now = Date.now();
    const t = now / 1000;

    // Simulation mixer
    const mixerRunning = currentBatch?.currentStep === 'mixing';
    const mixerCurrent = mixerRunning
      ? noise(45 + Math.sin(t * 0.3) * 5, 0.05)
      : currentBatch ? noise(5, 0.1) : 0;

    // Simulation hoppers - oscillation naturelle
    const updatedHoppers = realTimeState.hoppers.map((h, i) => ({
      ...h,
      level: clamp(noise(h.level, 0.001), 10, 100),
    }));

    // Simulation silos
    const updatedSilos = realTimeState.silos.map(s => ({
      ...s,
      level: clamp(noise(s.level, 0.001), 5, 100),
      levelLow: s.level < 15,
      levelHigh: s.level > 95,
    }));

    // Simulation water
    const updatedWater = realTimeState.waterTanks.map(w => ({
      ...w,
      level: clamp(noise(w.level, 0.002), 10, 100),
    }));

    // Simulation adjuvant
    const updatedAdjuvant = realTimeState.adjuvantTanks.map(a => ({
      ...a,
      level: clamp(noise(a.level, 0.001), 10, 100),
    }));

    // Skip animation
    const skipState = { ...realTimeState.skip };

    // Aggregate scale simulation
    const aggScale = { ...realTimeState.aggregateScale };
    if (currentBatch?.currentStep === 'aggregate_weighing') {
      aggScale.weight = clamp(noise(aggScale.weight + 8 * simulatorState.speed, 0.02), 0, 2000);
    } else if (currentBatch?.currentStep === 'mixing' || currentBatch?.currentStep === 'discharge') {
      // Weight stable during mixing
    } else if (!currentBatch) {
      aggScale.weight = noise(aggScale.weight * 0.99, 0.001);
      if (aggScale.weight < 0.5) aggScale.weight = 0;
    }

    useStore.getState().updateRealTimeState({
      hoppers: updatedHoppers,
      silos: updatedSilos,
      waterTanks: updatedWater,
      adjuvantTanks: updatedAdjuvant,
      mixer: {
        ...realTimeState.mixer,
        running: mixerRunning,
        current: mixerCurrent,
      },
      aggregateScale: aggScale,
      skip: skipState,
      plcConnected: false, // Pas de PLC réel
      simulatorMode: true,
    });
  }, 500);

  // Simulation de production automatique si scénario actif
  productionInterval = setInterval(() => {
    const { simulatorState, currentBatch, updateCurrentBatch, completeProduction, realTimeState } = useStore.getState();
    if (!simulatorState.enabled || !simulatorState.autoScenario || !currentBatch) return;

    const speed = simulatorState.speed;
    const step = currentBatch.currentStep;
    const progress = currentBatch.stepProgress;

    const stepDuration = 100 / speed; // Ticks pour compléter une étape

    if (progress >= 100) {
      // Passer à l'étape suivante
      const steps: Array<typeof step> = [
        'aggregate_weighing', 'cement_weighing', 'water_weighing',
        'adjuvant_weighing', 'mixing', 'discharge', 'done'
      ];
      const currentIndex = steps.indexOf(step);
      if (currentIndex < steps.length - 1) {
        const nextStep = steps[currentIndex + 1];
        updateCurrentBatch({ currentStep: nextStep, stepProgress: 0 });

        // Mise à jour state selon étape
        if (nextStep === 'mixing') {
          useStore.getState().updateRealTimeState({ mixer: { ...realTimeState.mixer, running: true } });
        } else if (nextStep === 'discharge') {
          useStore.getState().updateRealTimeState({ mixer: { ...realTimeState.mixer, running: false, doorOpen: true } });
        } else if (nextStep === 'done') {
          completeProduction();
          useStore.getState().updateRealTimeState({ mixer: { ...realTimeState.mixer, doorOpen: false }, conveyor: { ...realTimeState.conveyor, running: false } });
        }
      }
    } else {
      // Avancer le progress
      const newProgress = Math.min(100, progress + (100 / stepDuration));
      // Update weights based on step
      const target = currentBatch.weightsTarget;
      const actual = { ...currentBatch.weightsActual };
      if (step === 'aggregate_weighing') actual.aggregates = (newProgress / 100) * target.aggregates;
      else if (step === 'cement_weighing') actual.cement = (newProgress / 100) * target.cement;
      else if (step === 'water_weighing') actual.water = (newProgress / 100) * target.water;
      else if (step === 'adjuvant_weighing') actual.adjuvant = (newProgress / 100) * target.adjuvant;

      updateCurrentBatch({ stepProgress: newProgress, weightsActual: actual });
    }
  }, 1000);
};

export const stopSimulator = () => {
  if (simulatorInterval) {
    clearInterval(simulatorInterval);
    simulatorInterval = null;
  }
  if (productionInterval) {
    clearInterval(productionInterval);
    productionInterval = null;
  }
  console.log('[SIMULATEUR] Arrêt simulation');
};

export const restartSimulator = () => {
  stopSimulator();
  startSimulator();
};
