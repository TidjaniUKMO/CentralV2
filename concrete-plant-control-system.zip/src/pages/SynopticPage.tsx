/**
 * BétonPro SCADA - Synoptique animé
 * Vue process complète de la centrale à béton
 */
import React from 'react';
import { useStore } from '../store';
import { useTranslation } from 'react-i18next';
import { cn } from '../utils/cn';
import { AlertTriangle, Zap, Power, Settings } from 'lucide-react';

export const SynopticPage: React.FC = () => {
  const { t } = useTranslation();
  const { theme, realTimeState, plantConfig } = useStore();
  const isDark = theme === 'dark';

  const activeHoppers = plantConfig.hoppers.filter(h => h.active);
  const activeSilos = plantConfig.silos.filter(s => s.active);
  const activeWater = plantConfig.waterTanks.filter(w => w.active);
  const activeAdj = plantConfig.adjuvantTanks.filter(a => a.active);

  return (
    <div className={cn('h-full p-4 overflow-auto', isDark ? 'bg-slate-900' : 'bg-slate-100')}>
      <div className="mb-3 flex items-center gap-3 flex-wrap">
        <h2 className={cn('text-lg font-bold', isDark ? 'text-white' : 'text-slate-900')}>
          {t('synoptic.title')} — {plantConfig.plantName}
        </h2>
        <ModeIndicator modeAuto={realTimeState.modeAuto} emergency={realTimeState.emergencyStop} isDark={isDark} />
      </div>

      {/* Main Synoptic SVG-based layout */}
      <div className={cn('rounded-2xl border overflow-hidden', isDark ? 'bg-slate-800 border-slate-700' : 'bg-white border-slate-200')}>
        {/* ZONE 1: Trémies agrégats */}
        <div className="p-4 border-b border-slate-700/50">
          <div className="text-xs font-bold text-slate-400 mb-3 uppercase tracking-wider">Zone Agrégats</div>
          <div className="flex flex-wrap gap-4">
            {activeHoppers.map((hopper, i) => {
              const state = realTimeState.hoppers.find(h => h.id === hopper.id);
              return (
                <HopperWidget
                  key={hopper.id}
                  name={hopper.name}
                  open={state?.open || false}
                  level={state?.level || 0}
                  vibratorOn={state?.vibratorOn || false}
                  hasVibrator={hopper.hasVibrator}
                  isDark={isDark}
                />
              );
            })}
          </div>
        </div>

        {/* ZONE 2: Balance agrégats */}
        <div className="p-4 border-b border-slate-700/50 flex flex-wrap gap-6 items-center">
          <div>
            <div className="text-xs font-bold text-slate-400 mb-3 uppercase tracking-wider">Balance Agrégats</div>
            <BalanceWidget
              weight={realTimeState.aggregateScale.weight}
              setpoint={realTimeState.aggregateScale.setpoint}
              stable={realTimeState.aggregateScale.stable}
              isDark={isDark}
            />
          </div>

          {/* Arrow to Skip/Conveyor */}
          <div className="flex-1 flex flex-col items-center">
            <div className="text-xs text-slate-400 mb-1">
              {plantConfig.skipType === 'skip' ? '→ SKIP →' : '→ TAPIS →'}
            </div>
            <SkipWidget
              type={plantConfig.skipType}
              motorRunning={realTimeState.skip.motorRunning}
              posBottom={realTimeState.skip.positionBottom}
              posTop={realTimeState.skip.positionTop}
              isDark={isDark}
            />
          </div>

          {/* MALAXEUR */}
          <div>
            <div className="text-xs font-bold text-slate-400 mb-3 uppercase tracking-wider">Malaxeur</div>
            <MixerWidget
              running={realTimeState.mixer.running}
              current={realTimeState.mixer.current}
              doorOpen={realTimeState.mixer.doorOpen}
              fault={realTimeState.mixer.fault}
              isDark={isDark}
            />
          </div>
        </div>

        {/* ZONE 3: Silos Ciment */}
        <div className="p-4 border-b border-slate-700/50">
          <div className="text-xs font-bold text-slate-400 mb-3 uppercase tracking-wider">Zone Ciment</div>
          <div className="flex flex-wrap gap-4">
            {activeSilos.map(silo => {
              const state = realTimeState.silos.find(s => s.id === silo.id);
              return (
                <SiloWidget
                  key={silo.id}
                  name={silo.name}
                  level={state?.level || 0}
                  discharging={state?.discharging || false}
                  levelLow={state?.levelLow || false}
                  isDark={isDark}
                />
              );
            })}
          </div>
        </div>

        {/* ZONE 4: Eau + Adjuvants */}
        <div className="p-4">
          <div className="text-xs font-bold text-slate-400 mb-3 uppercase tracking-wider">Eau & Adjuvants</div>
          <div className="flex flex-wrap gap-4">
            {activeWater.map(tank => {
              const state = realTimeState.waterTanks.find(w => w.id === tank.id);
              return (
                <TankWidget
                  key={tank.id}
                  name={tank.name}
                  level={state?.level || 0}
                  pumpRunning={state?.pumpRunning || false}
                  type="water"
                  isDark={isDark}
                />
              );
            })}
            {activeAdj.map(tank => {
              const state = realTimeState.adjuvantTanks.find(a => a.id === tank.id);
              return (
                <TankWidget
                  key={tank.id}
                  name={tank.name}
                  level={state?.level || 0}
                  pumpRunning={state?.pumpRunning || false}
                  type="adjuvant"
                  isDark={isDark}
                />
              );
            })}
          </div>
        </div>
      </div>

      {/* Legend */}
      <div className={cn('mt-4 flex flex-wrap gap-4 text-xs p-3 rounded-xl', isDark ? 'bg-slate-800 text-slate-400' : 'bg-white text-slate-500')}>
        <div className="flex items-center gap-1.5"><span className="w-3 h-3 rounded-full bg-green-400 animate-pulse" /> En marche</div>
        <div className="flex items-center gap-1.5"><span className="w-3 h-3 rounded-full bg-slate-500" /> Arrêté</div>
        <div className="flex items-center gap-1.5"><span className="w-3 h-3 rounded-full bg-red-400" /> Défaut/Alarme</div>
        <div className="flex items-center gap-1.5"><span className="w-3 h-3 rounded-full bg-yellow-400" /> Avertissement</div>
        <div className="flex items-center gap-1.5"><span className="w-3 h-3 rounded bg-blue-400" /> Niveau</div>
      </div>
    </div>
  );
};

// ---- Mode Indicator ----
const ModeIndicator: React.FC<{ modeAuto: boolean; emergency: boolean; isDark: boolean }> = ({ modeAuto, emergency, isDark }) => (
  <div className="flex items-center gap-2">
    {emergency && (
      <span className="flex items-center gap-1 px-3 py-1 rounded-full bg-red-500/20 border border-red-500 text-red-400 text-xs font-black animate-pulse uppercase">
        <AlertTriangle size={12} /> ARRÊT URGENCE
      </span>
    )}
    <span className={cn(
      'flex items-center gap-1 px-3 py-1 rounded-full text-xs font-bold uppercase',
      modeAuto
        ? 'bg-green-500/20 border border-green-500/50 text-green-400'
        : 'bg-yellow-500/20 border border-yellow-500/50 text-yellow-400'
    )}>
      <Settings size={10} /> {modeAuto ? 'AUTO' : 'MANU'}
    </span>
  </div>
);

// ---- Hopper Widget ----
const HopperWidget: React.FC<{
  name: string; open: boolean; level: number; vibratorOn: boolean; hasVibrator: boolean; isDark: boolean
}> = ({ name, open, level, vibratorOn, hasVibrator, isDark }) => (
  <div className={cn('flex flex-col items-center w-28')}>
    <div className="text-xs text-center mb-1 font-medium truncate w-full text-center" title={name}>
      <span className={isDark ? 'text-slate-300' : 'text-slate-700'}>{name}</span>
    </div>
    {/* Hopper shape */}
    <div className="relative w-20 h-24">
      <svg viewBox="0 0 80 96" className="w-full h-full">
        {/* Hopper body */}
        <polygon points="8,8 72,8 56,64 24,64" fill={isDark ? '#1e40af22' : '#dbeafe'} stroke={isDark ? '#3b82f6' : '#2563eb'} strokeWidth="2" />
        {/* Level fill */}
        <clipPath id={`clip-h-${name}`}>
          <polygon points="8,8 72,8 56,64 24,64" />
        </clipPath>
        <rect
          x="0" y={`${8 + (1 - level / 100) * 56}`} width="80" height={`${(level / 100) * 56}`}
          fill={level < 20 ? '#ef444466' : '#3b82f666'}
          clipPath={`url(#clip-h-${name})`}
        />
        {/* Opening at bottom */}
        <rect x="30" y="64" width="20" height={open ? 8 : 4} fill={open ? '#22c55e' : '#6b7280'} />
        {/* Gate indicator */}
        {open && <rect x="28" y="72" width="24" height="4" fill="#22c55e" rx="2" />}
      </svg>
      {/* Level text */}
      <div className="absolute inset-0 flex items-center justify-center">
        <span className={cn('text-xs font-bold', level < 20 ? 'text-red-400' : isDark ? 'text-blue-300' : 'text-blue-600')}>
          {level.toFixed(0)}%
        </span>
      </div>
    </div>
    {/* Status indicators */}
    <div className="flex items-center gap-1 mt-1">
      <div className={cn('w-2 h-2 rounded-full', open ? 'bg-green-400 animate-pulse' : 'bg-slate-500')} title={open ? 'Ouvert' : 'Fermé'} />
      {hasVibrator && (
        <div className={cn('w-2 h-2 rounded-full', vibratorOn ? 'bg-yellow-400 animate-pulse' : 'bg-slate-600')} title="Vibreur" />
      )}
      <span className={cn('text-xs', open ? 'text-green-400' : isDark ? 'text-slate-500' : 'text-slate-400')}>
        {open ? 'OUVERT' : 'FERMÉ'}
      </span>
    </div>
  </div>
);

// ---- Balance Widget ----
const BalanceWidget: React.FC<{ weight: number; setpoint: number; stable: boolean; isDark: boolean }> = ({ weight, setpoint, stable, isDark }) => (
  <div className={cn('p-4 rounded-xl border w-48', isDark ? 'bg-slate-700 border-slate-600' : 'bg-slate-50 border-slate-200')}>
    <div className="text-center">
      <div className={cn('text-3xl font-black tabular-nums', isDark ? 'text-white' : 'text-slate-900')}>
        {weight.toFixed(1)}
      </div>
      <div className={cn('text-xs', isDark ? 'text-slate-400' : 'text-slate-500')}>kg</div>
      {setpoint > 0 && (
        <>
          <div className="my-2 h-px bg-slate-600" />
          <div className={cn('text-xs', isDark ? 'text-slate-400' : 'text-slate-500')}>Consigne: {setpoint} kg</div>
          <div className={cn('h-2 rounded-full mt-1', isDark ? 'bg-slate-600' : 'bg-slate-200')}>
            <div
              className="h-2 rounded-full bg-gradient-to-r from-orange-500 to-red-500 transition-all duration-300"
              style={{ width: `${Math.min(100, (weight / setpoint) * 100)}%` }}
            />
          </div>
        </>
      )}
      <div className={cn('mt-2 text-xs flex items-center justify-center gap-1', stable ? 'text-green-400' : 'text-yellow-400')}>
        <span className={cn('w-2 h-2 rounded-full', stable ? 'bg-green-400' : 'bg-yellow-400 animate-pulse')} />
        {stable ? 'STABLE' : 'EN MOUVEMENT'}
      </div>
    </div>
  </div>
);

// ---- Skip Widget ----
const SkipWidget: React.FC<{
  type: string; motorRunning: boolean; posBottom: boolean; posTop: boolean; isDark: boolean
}> = ({ type, motorRunning, posBottom, posTop, isDark }) => (
  <div className={cn('p-3 rounded-xl border w-40', isDark ? 'bg-slate-700 border-slate-600' : 'bg-slate-50 border-slate-200')}>
    <div className={cn('text-xs font-bold text-center mb-2', isDark ? 'text-slate-300' : 'text-slate-700')}>
      {type === 'skip' ? '⬆ SKIP' : '→ TAPIS INCLINÉ'}
    </div>
    {/* Skip visualization */}
    <div className="relative h-16 flex items-center justify-center">
      {type === 'skip' ? (
        <svg viewBox="0 0 60 64" className="h-full">
          <line x1="30" y1="0" x2="30" y2="64" stroke={isDark ? '#475569' : '#cbd5e1'} strokeWidth="3" />
          <rect
            x="15" y={posTop ? 4 : posBottom ? 44 : 24}
            width="30" height="16" rx="3"
            fill={motorRunning ? '#22c55e44' : isDark ? '#33415544' : '#f1f5f9'}
            stroke={motorRunning ? '#22c55e' : '#6b7280'}
            strokeWidth="1.5"
            className={motorRunning ? 'animate-bounce' : ''}
          />
          <circle cx="8" cy={posBottom ? 56 : 8} r="4" fill={posBottom ? '#22c55e' : posTop ? '#22c55e' : '#6b7280'} />
        </svg>
      ) : (
        <svg viewBox="0 0 80 40" className="h-full w-full">
          <line x1="5" y1="35" x2="75" y2="5" stroke={motorRunning ? '#22c55e' : isDark ? '#475569' : '#cbd5e1'} strokeWidth="8" strokeLinecap="round" className={motorRunning ? '' : ''} />
          <circle cx="40" cy="20" r="5" fill={motorRunning ? '#22c55e' : '#6b7280'} className={motorRunning ? 'animate-spin' : ''} style={{ transformOrigin: '40px 20px' }} />
        </svg>
      )}
    </div>
    <div className="flex items-center justify-center gap-1">
      <div className={cn('w-2 h-2 rounded-full', motorRunning ? 'bg-green-400 animate-pulse' : 'bg-slate-500')} />
      <span className={cn('text-xs', motorRunning ? 'text-green-400' : isDark ? 'text-slate-400' : 'text-slate-500')}>
        {motorRunning ? 'EN MARCHE' : 'ARRÊTÉ'}
      </span>
    </div>
  </div>
);

// ---- Mixer Widget ----
const MixerWidget: React.FC<{
  running: boolean; current: number; doorOpen: boolean; fault: boolean; isDark: boolean
}> = ({ running, current, doorOpen, fault, isDark }) => (
  <div className={cn('p-4 rounded-xl border w-44', fault ? 'border-red-500/50 bg-red-500/10' : isDark ? 'bg-slate-700 border-slate-600' : 'bg-slate-50 border-slate-200')}>
    <div className="flex flex-col items-center">
      {/* Mixer animation */}
      <div className="relative w-20 h-20 mb-2">
        <svg viewBox="0 0 80 80" className="w-full h-full">
          {/* Drum */}
          <ellipse cx="40" cy="40" rx="32" ry="32"
            fill={running ? '#22c55e11' : isDark ? '#1e293b' : '#f8fafc'}
            stroke={fault ? '#ef4444' : running ? '#22c55e' : isDark ? '#475569' : '#94a3b8'}
            strokeWidth="3"
          />
          {/* Blades */}
          {[0, 60, 120, 180, 240, 300].map((angle, i) => (
            <line
              key={i}
              x1="40" y1="40"
              x2={40 + 24 * Math.cos((angle * Math.PI) / 180)}
              y2={40 + 24 * Math.sin((angle * Math.PI) / 180)}
              stroke={running ? '#22c55e' : isDark ? '#334155' : '#cbd5e1'}
              strokeWidth="3"
              strokeLinecap="round"
              style={{
                transformOrigin: '40px 40px',
                animation: running ? `spin 2s linear infinite` : 'none',
              }}
            />
          ))}
          {/* Center */}
          <circle cx="40" cy="40" r="5" fill={running ? '#22c55e' : isDark ? '#475569' : '#94a3b8'} />
          {/* Door */}
          {doorOpen && (
            <path d="M 40 72 Q 55 85 70 72" stroke="#f97316" strokeWidth="2" fill="none" />
          )}
        </svg>
        {running && (
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="w-8 h-8 rounded-full border-2 border-green-400 border-t-transparent animate-spin opacity-60" />
          </div>
        )}
      </div>
      <div className={cn('text-xs font-bold', fault ? 'text-red-400' : running ? 'text-green-400' : isDark ? 'text-slate-400' : 'text-slate-500')}>
        {fault ? '⚠ DÉFAUT' : running ? '↻ EN MARCHE' : 'ARRÊTÉ'}
      </div>
      {current > 0 && (
        <div className={cn('text-xs mt-1', isDark ? 'text-slate-400' : 'text-slate-500')}>
          I = {current.toFixed(1)} A
        </div>
      )}
      {doorOpen && (
        <div className="text-xs text-orange-400 mt-1">🚪 TRAPPE OUVERTE</div>
      )}
    </div>
  </div>
);

// ---- Silo Widget ----
const SiloWidget: React.FC<{
  name: string; level: number; discharging: boolean; levelLow: boolean; isDark: boolean
}> = ({ name, level, discharging, levelLow, isDark }) => (
  <div className="flex flex-col items-center w-24">
    <div className="text-xs text-center mb-1 font-medium truncate w-full" title={name}>
      <span className={isDark ? 'text-slate-300' : 'text-slate-700'}>{name.split(' ').slice(0, 2).join(' ')}</span>
    </div>
    <div className="relative w-16 h-28">
      <svg viewBox="0 0 64 112" className="w-full h-full">
        {/* Silo body */}
        <rect x="8" y="8" width="48" height="72" rx="4" fill={isDark ? '#1e40af11' : '#dbeafe'} stroke={isDark ? '#3b82f6' : '#2563eb'} strokeWidth="2" />
        {/* Level fill */}
        <clipPath id={`clip-s-${name}`}>
          <rect x="8" y="8" width="48" height="72" rx="4" />
        </clipPath>
        <rect
          x="8" y={`${8 + (1 - level / 100) * 72}`} width="48" height={`${(level / 100) * 72}`}
          fill={levelLow ? '#ef444444' : '#6366f144'}
          clipPath={`url(#clip-s-${name})`}
        />
        {/* Cone bottom */}
        <polygon points="8,80 56,80 40,100 24,100" fill={isDark ? '#1e3a8a' : '#bfdbfe'} stroke={isDark ? '#3b82f6' : '#2563eb'} strokeWidth="2" />
        {/* Discharge pipe */}
        <rect x="28" y="100" width="8" height="8" fill={discharging ? '#22c55e' : isDark ? '#475569' : '#94a3b8'} />
      </svg>
      <div className="absolute inset-0 flex items-center justify-center">
        <span className={cn('text-xs font-bold', levelLow ? 'text-red-400' : isDark ? 'text-purple-300' : 'text-purple-700')}>
          {level.toFixed(0)}%
        </span>
      </div>
    </div>
    <div className="flex items-center gap-1 mt-1">
      {levelLow && <AlertTriangle size={10} className="text-red-400 animate-pulse" />}
      <div className={cn('w-2 h-2 rounded-full', discharging ? 'bg-green-400 animate-pulse' : 'bg-slate-500')} />
      <span className={cn('text-xs', levelLow ? 'text-red-400' : isDark ? 'text-slate-400' : 'text-slate-500')}>
        {levelLow ? 'BAS' : discharging ? 'DOSAGE' : 'OK'}
      </span>
    </div>
  </div>
);

// ---- Tank Widget ----
const TankWidget: React.FC<{
  name: string; level: number; pumpRunning: boolean; type: 'water' | 'adjuvant'; isDark: boolean
}> = ({ name, level, pumpRunning, type, isDark }) => {
  const color = type === 'water' ? { fill: '#0ea5e9', stroke: '#0284c7' } : { fill: '#a855f7', stroke: '#9333ea' };
  return (
    <div className="flex flex-col items-center w-24">
      <div className="text-xs text-center mb-1 font-medium truncate w-full" title={name}>
        <span className={isDark ? 'text-slate-300' : 'text-slate-700'}>{name.split(' ').slice(0, 2).join(' ')}</span>
      </div>
      <div className="relative w-16 h-20">
        <svg viewBox="0 0 64 80" className="w-full h-full">
          <rect x="8" y="8" width="48" height="56" rx="6" fill={isDark ? '#ffffff08' : '#f8fafc'} stroke={isDark ? color.stroke : color.stroke} strokeWidth="2" />
          <clipPath id={`clip-t-${name}`}>
            <rect x="8" y="8" width="48" height="56" rx="6" />
          </clipPath>
          <rect
            x="8" y={`${8 + (1 - level / 100) * 56}`} width="48" height={`${(level / 100) * 56}`}
            fill={`${color.fill}55`}
            clipPath={`url(#clip-t-${name})`}
          />
          {/* Wave animation when pumping */}
          {pumpRunning && (
            <path
              d={`M 8 ${8 + (1 - level / 100) * 56} Q 20 ${4 + (1 - level / 100) * 56} 32 ${8 + (1 - level / 100) * 56} Q 44 ${12 + (1 - level / 100) * 56} 56 ${8 + (1 - level / 100) * 56}`}
              fill="none" stroke={color.fill} strokeWidth="2"
              style={{ animation: 'wavemove 1s linear infinite' }}
            />
          )}
          {/* Pipe bottom */}
          <rect x="28" y="64" width="8" height="12" fill={pumpRunning ? '#22c55e' : isDark ? '#475569' : '#94a3b8'} />
        </svg>
        <div className="absolute inset-0 flex items-center justify-center">
          <span className={cn('text-xs font-bold', type === 'water' ? 'text-sky-400' : 'text-purple-400')}>
            {level.toFixed(0)}%
          </span>
        </div>
      </div>
      <div className="flex items-center gap-1 mt-1">
        <div className={cn('w-2 h-2 rounded-full', pumpRunning ? 'bg-green-400 animate-pulse' : 'bg-slate-500')} />
        <span className={cn('text-xs', pumpRunning ? 'text-green-400' : isDark ? 'text-slate-400' : 'text-slate-500')}>
          {pumpRunning ? 'POMPE ON' : 'ARRÊT'}
        </span>
      </div>
    </div>
  );
};

export default SynopticPage;
