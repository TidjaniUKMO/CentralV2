/**
 * BétonPro SCADA - Page Maintenance
 * Test équipements, commande manuelle, diagnostics
 */
import React, { useState } from 'react';
import { useStore } from '../store';
import { Wrench, Play, Square, AlertTriangle, RotateCcw, Activity } from 'lucide-react';
import { cn } from '../utils/cn';

export const MaintenancePage: React.FC = () => {
  const { theme, realTimeState, plantConfig, updateRealTimeState, updateHopperState, updateSiloState } = useStore();
  const isDark = theme === 'dark';

  const [activeHopper, setActiveHopper] = useState<string | null>(null);
  const [notes, setNotes] = useState('');

  const cardClass = cn('rounded-xl border p-4', isDark ? 'bg-slate-800 border-slate-700' : 'bg-white border-slate-200');

  const toggleHopper = (id: string, open: boolean) => {
    updateHopperState(id, { open });
    setActiveHopper(open ? id : null);
  };

  const toggleMotor = (motor: 'mixer' | 'conveyor') => {
    if (motor === 'mixer') {
      updateRealTimeState({ mixer: { ...realTimeState.mixer, running: !realTimeState.mixer.running } });
    } else {
      updateRealTimeState({ conveyor: { ...realTimeState.conveyor, running: !realTimeState.conveyor.running } });
    }
  };

  return (
    <div className={cn('h-full overflow-auto', isDark ? 'bg-slate-900 text-white' : 'bg-slate-50 text-slate-900')}>
      <div className="max-w-5xl mx-auto p-4 space-y-4">
        {/* Warning */}
        <div className="flex items-center gap-3 px-4 py-3 rounded-xl bg-yellow-500/10 border border-yellow-500/30">
          <AlertTriangle size={18} className="text-yellow-400 flex-shrink-0" />
          <div>
            <div className="text-yellow-400 font-bold text-sm">MODE MAINTENANCE — Commandes manuelles directes</div>
            <div className={cn('text-xs', isDark ? 'text-yellow-300/70' : 'text-yellow-700')}>Les sécurités restent actives. Assurez-vous que la zone est dégagée avant toute commande.</div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {/* Hoppers manual control */}
          <div className={cardClass}>
            <h3 className={cn('font-bold mb-4 flex items-center gap-2', isDark ? 'text-white' : 'text-slate-900')}>
              <Wrench size={16} className="text-orange-400" /> Commande Trémies (Mode MANU)
            </h3>
            <div className="space-y-2">
              {plantConfig.hoppers.filter(h => h.active).map(hopper => {
                const state = realTimeState.hoppers.find(h => h.id === hopper.id);
                const isOpen = state?.open || false;
                return (
                  <div key={hopper.id} className={cn('flex items-center gap-3 p-3 rounded-lg', isDark ? 'bg-slate-700' : 'bg-slate-50')}>
                    <div className={cn('w-3 h-3 rounded-full flex-shrink-0', isOpen ? 'bg-green-400 animate-pulse' : 'bg-slate-500')} />
                    <span className={cn('flex-1 text-sm', isDark ? 'text-slate-300' : 'text-slate-700')}>{hopper.name}</span>
                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => toggleHopper(hopper.id, true)}
                        disabled={isOpen}
                        className={cn('px-2 py-1 rounded text-xs font-bold transition-all', isOpen ? 'bg-green-500 text-white' : isDark ? 'bg-slate-600 text-slate-300 hover:bg-green-500/20 hover:text-green-400' : 'bg-slate-200 text-slate-600 hover:bg-green-100')}
                      >
                        OUV
                      </button>
                      <button
                        onClick={() => toggleHopper(hopper.id, false)}
                        disabled={!isOpen}
                        className={cn('px-2 py-1 rounded text-xs font-bold transition-all', !isOpen ? isDark ? 'bg-slate-600 text-slate-500' : 'bg-slate-100 text-slate-400' : 'bg-red-500 text-white')}
                      >
                        FERM
                      </button>
                      {hopper.hasVibrator && (
                        <button
                          onClick={() => updateHopperState(hopper.id, { vibratorOn: !state?.vibratorOn })}
                          className={cn('px-2 py-1 rounded text-xs font-bold', state?.vibratorOn ? 'bg-yellow-500 text-white animate-pulse' : isDark ? 'bg-slate-600 text-slate-400' : 'bg-slate-200 text-slate-500')}
                        >
                          VIB
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Motors + Mixer */}
          <div className={cardClass}>
            <h3 className={cn('font-bold mb-4 flex items-center gap-2', isDark ? 'text-white' : 'text-slate-900')}>
              <Activity size={16} className="text-green-400" /> Commande Moteurs
            </h3>
            <div className="space-y-3">
              {/* Malaxeur */}
              <div className={cn('p-3 rounded-lg', isDark ? 'bg-slate-700' : 'bg-slate-50')}>
                <div className="flex items-center justify-between">
                  <div>
                    <div className={cn('font-medium text-sm', isDark ? 'text-white' : 'text-slate-900')}>Malaxeur principal</div>
                    <div className={cn('text-xs', isDark ? 'text-slate-400' : 'text-slate-500')}>
                      I = {realTimeState.mixer.current.toFixed(1)} A {realTimeState.mixer.fault && '⚠ DÉFAUT'}
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className={cn('w-2 h-2 rounded-full', realTimeState.mixer.running ? 'bg-green-400 animate-pulse' : 'bg-slate-500')} />
                    <button onClick={() => toggleMotor('mixer')}
                      className={cn('flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold', realTimeState.mixer.running ? 'bg-red-500 hover:bg-red-600 text-white' : 'bg-green-500 hover:bg-green-600 text-white')}>
                      {realTimeState.mixer.running ? <><Square size={11} /> STOP</> : <><Play size={11} /> START</>}
                    </button>
                  </div>
                </div>
              </div>

              {/* Convoyeur/Skip */}
              <div className={cn('p-3 rounded-lg', isDark ? 'bg-slate-700' : 'bg-slate-50')}>
                <div className="flex items-center justify-between">
                  <div>
                    <div className={cn('font-medium text-sm', isDark ? 'text-white' : 'text-slate-900')}>{plantConfig.skipType === 'skip' ? 'Moteur Skip' : 'Tapis incliné'}</div>
                    <div className={cn('text-xs', isDark ? 'text-slate-400' : 'text-slate-500')}>
                      {plantConfig.skipType === 'skip' ? `Bas: ${realTimeState.skip.positionBottom ? 'OUI' : 'NON'} / Haut: ${realTimeState.skip.positionTop ? 'OUI' : 'NON'}` : 'Convoyeur incliné'}
                    </div>
                  </div>
                  <button onClick={() => toggleMotor('conveyor')}
                    className={cn('flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold', realTimeState.conveyor.running ? 'bg-red-500 hover:bg-red-600 text-white' : 'bg-green-500 hover:bg-green-600 text-white')}>
                    {realTimeState.conveyor.running ? <><Square size={11} /> STOP</> : <><Play size={11} /> START</>}
                  </button>
                </div>
              </div>

              {/* Trappe malaxeur */}
              <div className={cn('p-3 rounded-lg', isDark ? 'bg-slate-700' : 'bg-slate-50')}>
                <div className="flex items-center justify-between">
                  <div>
                    <div className={cn('font-medium text-sm', isDark ? 'text-white' : 'text-slate-900')}>Trappe vidange malaxeur</div>
                    <div className={cn('text-xs', isDark ? 'text-slate-400' : 'text-slate-500')}>{realTimeState.mixer.doorOpen ? 'OUVERTE' : 'FERMÉE'}</div>
                  </div>
                  <button onClick={() => updateRealTimeState({ mixer: { ...realTimeState.mixer, doorOpen: !realTimeState.mixer.doorOpen } })}
                    className={cn('px-3 py-1.5 rounded-lg text-xs font-bold transition-all', realTimeState.mixer.doorOpen ? 'bg-orange-500 text-white' : isDark ? 'bg-slate-600 text-slate-300 hover:bg-orange-500/20' : 'bg-slate-200 text-slate-600')}>
                    {realTimeState.mixer.doorOpen ? 'FERMER' : 'OUVRIR'}
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Silos manual */}
        <div className={cardClass}>
          <h3 className={cn('font-bold mb-4 flex items-center gap-2', isDark ? 'text-white' : 'text-slate-900')}>
            <Wrench size={16} className="text-purple-400" /> Silos Ciment — Test décharge
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {plantConfig.silos.filter(s => s.active).map(silo => {
              const state = realTimeState.silos.find(s => s.id === silo.id);
              return (
                <div key={silo.id} className={cn('p-3 rounded-lg flex items-center justify-between', isDark ? 'bg-slate-700' : 'bg-slate-50')}>
                  <div>
                    <div className={cn('font-medium text-sm', isDark ? 'text-white' : 'text-slate-900')}>{silo.name}</div>
                    <div className={cn('text-xs', isDark ? 'text-slate-400' : 'text-slate-500')}>Niveau: {state?.level?.toFixed(0)}%</div>
                  </div>
                  <button
                    onClick={() => updateSiloState(silo.id, { discharging: !state?.discharging })}
                    className={cn('px-3 py-1.5 rounded-lg text-xs font-bold', state?.discharging ? 'bg-purple-500 text-white animate-pulse' : isDark ? 'bg-slate-600 text-slate-300 hover:bg-purple-500/20' : 'bg-slate-200 text-slate-600')}
                  >
                    {state?.discharging ? '■ STOP VIS' : '▶ START VIS'}
                  </button>
                </div>
              );
            })}
          </div>
        </div>

        {/* Notes */}
        <div className={cardClass}>
          <h3 className={cn('font-bold mb-3 flex items-center gap-2', isDark ? 'text-white' : 'text-slate-900')}>
            <RotateCcw size={14} className="text-slate-400" /> Notes de maintenance
          </h3>
          <textarea
            value={notes}
            onChange={e => setNotes(e.target.value)}
            rows={4}
            placeholder="Saisir les opérations de maintenance effectuées..."
            className={cn('w-full px-3 py-2 rounded-lg border text-sm resize-none', isDark ? 'bg-slate-700 border-slate-600 text-white placeholder-slate-500' : 'bg-slate-50 border-slate-200 text-slate-900')}
          />
          <div className="flex justify-end mt-2">
            <button className="px-3 py-1.5 rounded-lg bg-slate-600 hover:bg-slate-500 text-white text-xs font-bold">
              Enregistrer note
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MaintenancePage;
