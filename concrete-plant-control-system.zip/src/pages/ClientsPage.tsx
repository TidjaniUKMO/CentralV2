/**
 * BétonPro SCADA - Module Clients / Camions / Chauffeurs
 * CRUD complet avec recherche dynamique
 */
import React, { useState } from 'react';
import { useStore } from '../store';
import { Plus, Search, Edit, Trash2, Save, X, Truck, User, Building, UserCheck } from 'lucide-react';
import { cn } from '../utils/cn';
import { format } from 'date-fns';
import type { Client, Truck as TruckType, Driver, ClientType } from '../types';

type SubTab = 'clients' | 'trucks' | 'drivers';

export const ClientsPage: React.FC = () => {
  const { theme, clients, trucks, drivers, addClient, updateClient, deleteClient, addTruck, updateTruck, deleteTruck, addDriver, updateDriver, deleteDriver, auth } = useStore();
  const isDark = theme === 'dark';
  const [subTab, setSubTab] = useState<SubTab>('clients');
  const [search, setSearch] = useState('');
  const [showForm, setShowForm] = useState(false);
  const [editId, setEditId] = useState<string | null>(null);
  const [confirmDelete, setConfirmDelete] = useState<string | null>(null);

  // Client form
  const [clientForm, setClientForm] = useState<Partial<Client>>({ name: '', type: 'company', phone: '', email: '', address: '' });
  const [truckForm, setTruckForm] = useState<Partial<TruckType>>({ clientId: '', plate: '', model: '', capacity: 8 });
  const [driverForm, setDriverForm] = useState<Partial<Driver>>({ clientId: '', name: '', phone: '', license: '' });

  const filteredClients = clients.filter(c => {
    if (!search) return true;
    const s = search.toLowerCase();
    return c.name.toLowerCase().includes(s) || c.email?.toLowerCase().includes(s) || c.phone?.includes(s);
  });
  const filteredTrucks = trucks.filter(t => {
    if (!search) return true;
    const s = search.toLowerCase();
    const clientName = clients.find(c => c.id === t.clientId)?.name || '';
    return t.plate.toLowerCase().includes(s) || t.model?.toLowerCase().includes(s) || clientName.toLowerCase().includes(s);
  });
  const filteredDrivers = drivers.filter(d => {
    if (!search) return true;
    const s = search.toLowerCase();
    const clientName = clients.find(c => c.id === d.clientId)?.name || '';
    return d.name.toLowerCase().includes(s) || d.phone?.includes(s) || clientName.toLowerCase().includes(s);
  });

  const handleSaveClient = () => {
    if (!clientForm.name?.trim()) return;
    if (editId) {
      updateClient(editId, clientForm);
    } else {
      addClient({ ...clientForm as Client, id: `c-${Date.now()}`, createdAt: new Date(), active: true });
    }
    setShowForm(false); setEditId(null); setClientForm({ name: '', type: 'company', phone: '', email: '', address: '' });
  };

  const handleSaveTruck = () => {
    if (!truckForm.plate?.trim() || !truckForm.clientId) return;
    if (editId) {
      updateTruck(editId, truckForm);
    } else {
      addTruck({ ...truckForm as TruckType, id: `t-${Date.now()}`, active: true });
    }
    setShowForm(false); setEditId(null); setTruckForm({ clientId: '', plate: '', model: '', capacity: 8 });
  };

  const handleSaveDriver = () => {
    if (!driverForm.name?.trim() || !driverForm.clientId) return;
    if (editId) {
      updateDriver(editId, driverForm);
    } else {
      addDriver({ ...driverForm as Driver, id: `d-${Date.now()}`, active: true });
    }
    setShowForm(false); setEditId(null); setDriverForm({ clientId: '', name: '', phone: '', license: '' });
  };

  const handleDelete = (id: string, type: SubTab) => {
    if (confirmDelete === id) {
      if (type === 'clients') deleteClient(id);
      else if (type === 'trucks') deleteTruck(id);
      else deleteDriver(id);
      setConfirmDelete(null);
    } else {
      setConfirmDelete(id);
      setTimeout(() => setConfirmDelete(null), 3000);
    }
  };

  const canWrite = auth.user?.role === 'admin' || auth.user?.permissions.find(p => p.module === 'clients')?.write;

  const cardClass = cn('rounded-xl border', isDark ? 'bg-slate-800 border-slate-700' : 'bg-white border-slate-200');

  return (
    <div className={cn('h-full flex flex-col', isDark ? 'bg-slate-900 text-white' : 'bg-slate-50 text-slate-900')}>
      {/* Tabs */}
      <div className={cn('flex items-center gap-3 px-4 py-3 border-b flex-wrap', isDark ? 'border-slate-700' : 'border-slate-200')}>
        {([
          ['clients', Building, 'Clients', clients.length],
          ['trucks', Truck, 'Camions', trucks.length],
          ['drivers', UserCheck, 'Chauffeurs', drivers.length],
        ] as const).map(([id, Icon, label, count]) => (
          <button key={id} onClick={() => { setSubTab(id); setShowForm(false); setSearch(''); }}
            className={cn('flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all',
              subTab === id ? 'bg-orange-500 text-white shadow-lg shadow-orange-500/30' : isDark ? 'text-slate-400 hover:text-white hover:bg-slate-800' : 'text-slate-500 hover:text-slate-900 hover:bg-slate-200'
            )}>
            <Icon size={14} /> {label} ({count})
          </button>
        ))}
        <div className="flex-1" />
        <div className="relative">
          <Search size={13} className={cn('absolute left-2.5 top-1/2 -translate-y-1/2', isDark ? 'text-slate-500' : 'text-slate-400')} />
          <input type="text" value={search} onChange={e => setSearch(e.target.value)}
            placeholder="Rechercher..."
            className={cn('pl-8 pr-3 py-2 rounded-lg border text-sm w-48', isDark ? 'bg-slate-800 border-slate-700 text-white placeholder-slate-500' : 'bg-white border-slate-200 text-slate-900')} />
        </div>
        {canWrite && (
          <button onClick={() => { setShowForm(true); setEditId(null); }}
            className="flex items-center gap-2 px-3 py-2 rounded-lg bg-orange-500 hover:bg-orange-600 text-white font-bold text-sm">
            <Plus size={13} /> Ajouter
          </button>
        )}
      </div>

      <div className="flex-1 overflow-auto p-4 space-y-4">
        {/* FORM PANEL */}
        {showForm && (
          <div className={cardClass + ' p-5'}>
            <div className="flex items-center justify-between mb-4">
              <h3 className={cn('font-bold', isDark ? 'text-white' : 'text-slate-900')}>
                {editId ? 'Modifier' : 'Ajouter'} {subTab === 'clients' ? 'un client' : subTab === 'trucks' ? 'un camion' : 'un chauffeur'}
              </h3>
              <button onClick={() => { setShowForm(false); setEditId(null); }} className={cn('p-1 rounded', isDark ? 'text-slate-400 hover:text-white' : 'text-slate-500')}>
                <X size={16} />
              </button>
            </div>

            {subTab === 'clients' && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div>
                  <label className={cn('block text-xs font-semibold mb-1 uppercase', isDark ? 'text-slate-400' : 'text-slate-500')}>Nom *</label>
                  <input value={clientForm.name || ''} onChange={e => setClientForm(f => ({ ...f, name: e.target.value }))}
                    className={cn('w-full px-3 py-2 rounded-lg border text-sm', isDark ? 'bg-slate-700 border-slate-600 text-white' : 'bg-slate-50 border-slate-200')} />
                </div>
                <div>
                  <label className={cn('block text-xs font-semibold mb-1 uppercase', isDark ? 'text-slate-400' : 'text-slate-500')}>Type</label>
                  <select value={clientForm.type || 'company'} onChange={e => setClientForm(f => ({ ...f, type: e.target.value as ClientType }))}
                    className={cn('w-full px-3 py-2 rounded-lg border text-sm', isDark ? 'bg-slate-700 border-slate-600 text-white' : 'bg-slate-50 border-slate-200')}>
                    <option value="company">🏢 Entreprise</option>
                    <option value="individual">👤 Particulier</option>
                  </select>
                </div>
                <div>
                  <label className={cn('block text-xs font-semibold mb-1 uppercase', isDark ? 'text-slate-400' : 'text-slate-500')}>Téléphone</label>
                  <input value={clientForm.phone || ''} onChange={e => setClientForm(f => ({ ...f, phone: e.target.value }))}
                    className={cn('w-full px-3 py-2 rounded-lg border text-sm', isDark ? 'bg-slate-700 border-slate-600 text-white' : 'bg-slate-50 border-slate-200')} />
                </div>
                <div>
                  <label className={cn('block text-xs font-semibold mb-1 uppercase', isDark ? 'text-slate-400' : 'text-slate-500')}>Email</label>
                  <input type="email" value={clientForm.email || ''} onChange={e => setClientForm(f => ({ ...f, email: e.target.value }))}
                    className={cn('w-full px-3 py-2 rounded-lg border text-sm', isDark ? 'bg-slate-700 border-slate-600 text-white' : 'bg-slate-50 border-slate-200')} />
                </div>
                <div className="md:col-span-2">
                  <label className={cn('block text-xs font-semibold mb-1 uppercase', isDark ? 'text-slate-400' : 'text-slate-500')}>Adresse</label>
                  <input value={clientForm.address || ''} onChange={e => setClientForm(f => ({ ...f, address: e.target.value }))}
                    className={cn('w-full px-3 py-2 rounded-lg border text-sm', isDark ? 'bg-slate-700 border-slate-600 text-white' : 'bg-slate-50 border-slate-200')} />
                </div>
                <div className="md:col-span-2 flex gap-3">
                  <button onClick={handleSaveClient} className="flex items-center gap-2 px-4 py-2 rounded-lg bg-green-500 hover:bg-green-600 text-white font-bold text-sm"><Save size={13} /> Enregistrer</button>
                  <button onClick={() => { setShowForm(false); setEditId(null); }} className={cn('px-3 py-2 rounded-lg text-sm', isDark ? 'bg-slate-700 text-slate-300' : 'bg-slate-200 text-slate-600')}>Annuler</button>
                </div>
              </div>
            )}

            {subTab === 'trucks' && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div>
                  <label className={cn('block text-xs font-semibold mb-1 uppercase', isDark ? 'text-slate-400' : 'text-slate-500')}>Client *</label>
                  <select value={truckForm.clientId || ''} onChange={e => setTruckForm(f => ({ ...f, clientId: e.target.value }))}
                    className={cn('w-full px-3 py-2 rounded-lg border text-sm', isDark ? 'bg-slate-700 border-slate-600 text-white' : 'bg-slate-50 border-slate-200')}>
                    <option value="">-- Sélectionner --</option>
                    {clients.filter(c => c.active).map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                  </select>
                </div>
                <div>
                  <label className={cn('block text-xs font-semibold mb-1 uppercase', isDark ? 'text-slate-400' : 'text-slate-500')}>Immatriculation *</label>
                  <input value={truckForm.plate || ''} onChange={e => setTruckForm(f => ({ ...f, plate: e.target.value.toUpperCase() }))}
                    className={cn('w-full px-3 py-2 rounded-lg border text-sm font-mono', isDark ? 'bg-slate-700 border-slate-600 text-white' : 'bg-slate-50 border-slate-200')}
                    placeholder="AB-123-CD" />
                </div>
                <div>
                  <label className={cn('block text-xs font-semibold mb-1 uppercase', isDark ? 'text-slate-400' : 'text-slate-500')}>Modèle</label>
                  <input value={truckForm.model || ''} onChange={e => setTruckForm(f => ({ ...f, model: e.target.value }))}
                    className={cn('w-full px-3 py-2 rounded-lg border text-sm', isDark ? 'bg-slate-700 border-slate-600 text-white' : 'bg-slate-50 border-slate-200')} />
                </div>
                <div>
                  <label className={cn('block text-xs font-semibold mb-1 uppercase', isDark ? 'text-slate-400' : 'text-slate-500')}>Capacité (m³)</label>
                  <input type="number" min="1" max="30" value={truckForm.capacity || 8} onChange={e => setTruckForm(f => ({ ...f, capacity: parseFloat(e.target.value) }))}
                    className={cn('w-full px-3 py-2 rounded-lg border text-sm', isDark ? 'bg-slate-700 border-slate-600 text-white' : 'bg-slate-50 border-slate-200')} />
                </div>
                <div className="md:col-span-2 flex gap-3">
                  <button onClick={handleSaveTruck} className="flex items-center gap-2 px-4 py-2 rounded-lg bg-green-500 hover:bg-green-600 text-white font-bold text-sm"><Save size={13} /> Enregistrer</button>
                  <button onClick={() => { setShowForm(false); setEditId(null); }} className={cn('px-3 py-2 rounded-lg text-sm', isDark ? 'bg-slate-700 text-slate-300' : 'bg-slate-200 text-slate-600')}>Annuler</button>
                </div>
              </div>
            )}

            {subTab === 'drivers' && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div>
                  <label className={cn('block text-xs font-semibold mb-1 uppercase', isDark ? 'text-slate-400' : 'text-slate-500')}>Client *</label>
                  <select value={driverForm.clientId || ''} onChange={e => setDriverForm(f => ({ ...f, clientId: e.target.value }))}
                    className={cn('w-full px-3 py-2 rounded-lg border text-sm', isDark ? 'bg-slate-700 border-slate-600 text-white' : 'bg-slate-50 border-slate-200')}>
                    <option value="">-- Sélectionner --</option>
                    {clients.filter(c => c.active).map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                  </select>
                </div>
                <div>
                  <label className={cn('block text-xs font-semibold mb-1 uppercase', isDark ? 'text-slate-400' : 'text-slate-500')}>Nom *</label>
                  <input value={driverForm.name || ''} onChange={e => setDriverForm(f => ({ ...f, name: e.target.value }))}
                    className={cn('w-full px-3 py-2 rounded-lg border text-sm', isDark ? 'bg-slate-700 border-slate-600 text-white' : 'bg-slate-50 border-slate-200')} />
                </div>
                <div>
                  <label className={cn('block text-xs font-semibold mb-1 uppercase', isDark ? 'text-slate-400' : 'text-slate-500')}>Téléphone</label>
                  <input value={driverForm.phone || ''} onChange={e => setDriverForm(f => ({ ...f, phone: e.target.value }))}
                    className={cn('w-full px-3 py-2 rounded-lg border text-sm', isDark ? 'bg-slate-700 border-slate-600 text-white' : 'bg-slate-50 border-slate-200')} />
                </div>
                <div>
                  <label className={cn('block text-xs font-semibold mb-1 uppercase', isDark ? 'text-slate-400' : 'text-slate-500')}>Permis</label>
                  <input value={driverForm.license || ''} onChange={e => setDriverForm(f => ({ ...f, license: e.target.value }))}
                    className={cn('w-full px-3 py-2 rounded-lg border text-sm', isDark ? 'bg-slate-700 border-slate-600 text-white'  : 'bg-slate-50 border-slate-200')} placeholder="C+CE" />
                </div>
                <div className="md:col-span-2 flex gap-3">
                  <button onClick={handleSaveDriver} className="flex items-center gap-2 px-4 py-2 rounded-lg bg-green-500 hover:bg-green-600 text-white font-bold text-sm"><Save size={13} /> Enregistrer</button>
                  <button onClick={() => { setShowForm(false); setEditId(null); }} className={cn('px-3 py-2 rounded-lg text-sm', isDark ? 'bg-slate-700 text-slate-300' : 'bg-slate-200 text-slate-600')}>Annuler</button>
                </div>
              </div>
            )}
          </div>
        )}

        {/* CLIENTS TABLE */}
        {subTab === 'clients' && (
          <div className={cn(cardClass, 'overflow-hidden')}>
            <table className="w-full text-sm">
              <thead className={cn('text-xs uppercase', isDark ? 'bg-slate-700 text-slate-400' : 'bg-slate-50 text-slate-500')}>
                <tr>
                  <th className="px-4 py-3 text-left">Nom</th>
                  <th className="px-4 py-3 text-left">Type</th>
                  <th className="px-4 py-3 text-left">Téléphone</th>
                  <th className="px-4 py-3 text-left">Email</th>
                  <th className="px-4 py-3 text-left">Adresse</th>
                  <th className="px-4 py-3 text-center">Camions</th>
                  <th className="px-4 py-3 text-left">Créé le</th>
                  {canWrite && <th className="px-4 py-3 text-center">Actions</th>}
                </tr>
              </thead>
              <tbody>
                {filteredClients.map(client => (
                  <tr key={client.id} className={cn('border-t', isDark ? 'border-slate-700 hover:bg-slate-700/40' : 'border-slate-100 hover:bg-slate-50')}>
                    <td className="px-4 py-3 font-medium">{client.name}</td>
                    <td className="px-4 py-3">
                      <span className={cn('px-2 py-0.5 rounded-full text-xs font-medium', client.type === 'company' ? 'bg-blue-500/20 text-blue-400' : 'bg-purple-500/20 text-purple-400')}>
                        {client.type === 'company' ? '🏢 Entreprise' : '👤 Particulier'}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-slate-400">{client.phone || '—'}</td>
                    <td className="px-4 py-3 text-slate-400 text-xs">{client.email || '—'}</td>
                    <td className="px-4 py-3 text-slate-400 text-xs truncate max-w-xs">{client.address || '—'}</td>
                    <td className="px-4 py-3 text-center">
                      <span className={cn('text-sm font-bold', trucks.filter(t => t.clientId === client.id).length > 0 ? 'text-green-400' : isDark ? 'text-slate-500' : 'text-slate-400')}>
                        {trucks.filter(t => t.clientId === client.id).length}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-xs text-slate-400">{format(new Date(client.createdAt), 'dd/MM/yyyy')}</td>
                    {canWrite && (
                      <td className="px-4 py-3">
                        <div className="flex items-center justify-center gap-1">
                          <button onClick={() => { setClientForm(client); setEditId(client.id); setShowForm(true); }}
                            className="p-1.5 rounded text-blue-400 hover:bg-blue-500/20"><Edit size={13} /></button>
                          <button onClick={() => handleDelete(client.id, 'clients')}
                            className={cn('p-1.5 rounded transition-colors', confirmDelete === client.id ? 'bg-red-500 text-white' : 'text-red-400 hover:bg-red-500/20')}>
                            <Trash2 size={13} /></button>
                        </div>
                      </td>
                    )}
                  </tr>
                ))}
              </tbody>
            </table>
            {filteredClients.length === 0 && <EmptyState label="client" isDark={isDark} />}
          </div>
        )}

        {/* TRUCKS TABLE */}
        {subTab === 'trucks' && (
          <div className={cn(cardClass, 'overflow-hidden')}>
            <table className="w-full text-sm">
              <thead className={cn('text-xs uppercase', isDark ? 'bg-slate-700 text-slate-400' : 'bg-slate-50 text-slate-500')}>
                <tr>
                  <th className="px-4 py-3 text-left">Immatriculation</th>
                  <th className="px-4 py-3 text-left">Client</th>
                  <th className="px-4 py-3 text-left">Modèle</th>
                  <th className="px-4 py-3 text-right">Capacité</th>
                  {canWrite && <th className="px-4 py-3 text-center">Actions</th>}
                </tr>
              </thead>
              <tbody>
                {filteredTrucks.map(truck => (
                  <tr key={truck.id} className={cn('border-t', isDark ? 'border-slate-700 hover:bg-slate-700/40' : 'border-slate-100 hover:bg-slate-50')}>
                    <td className="px-4 py-3 font-mono font-bold text-orange-400">{truck.plate}</td>
                    <td className="px-4 py-3">{clients.find(c => c.id === truck.clientId)?.name || '—'}</td>
                    <td className="px-4 py-3 text-slate-400">{truck.model || '—'}</td>
                    <td className="px-4 py-3 text-right font-bold">{truck.capacity} m³</td>
                    {canWrite && (
                      <td className="px-4 py-3">
                        <div className="flex items-center justify-center gap-1">
                          <button onClick={() => { setTruckForm(truck); setEditId(truck.id); setShowForm(true); }}
                            className="p-1.5 rounded text-blue-400 hover:bg-blue-500/20"><Edit size={13} /></button>
                          <button onClick={() => handleDelete(truck.id, 'trucks')}
                            className={cn('p-1.5 rounded transition-colors', confirmDelete === truck.id ? 'bg-red-500 text-white' : 'text-red-400 hover:bg-red-500/20')}>
                            <Trash2 size={13} /></button>
                        </div>
                      </td>
                    )}
                  </tr>
                ))}
              </tbody>
            </table>
            {filteredTrucks.length === 0 && <EmptyState label="camion" isDark={isDark} />}
          </div>
        )}

        {/* DRIVERS TABLE */}
        {subTab === 'drivers' && (
          <div className={cn(cardClass, 'overflow-hidden')}>
            <table className="w-full text-sm">
              <thead className={cn('text-xs uppercase', isDark ? 'bg-slate-700 text-slate-400' : 'bg-slate-50 text-slate-500')}>
                <tr>
                  <th className="px-4 py-3 text-left">Nom</th>
                  <th className="px-4 py-3 text-left">Client</th>
                  <th className="px-4 py-3 text-left">Téléphone</th>
                  <th className="px-4 py-3 text-left">Permis</th>
                  {canWrite && <th className="px-4 py-3 text-center">Actions</th>}
                </tr>
              </thead>
              <tbody>
                {filteredDrivers.map(driver => (
                  <tr key={driver.id} className={cn('border-t', isDark ? 'border-slate-700 hover:bg-slate-700/40' : 'border-slate-100 hover:bg-slate-50')}>
                    <td className="px-4 py-3 font-medium">{driver.name}</td>
                    <td className="px-4 py-3 text-slate-400">{clients.find(c => c.id === driver.clientId)?.name || '—'}</td>
                    <td className="px-4 py-3 text-slate-400">{driver.phone || '—'}</td>
                    <td className="px-4 py-3">
                      <span className={cn('px-2 py-0.5 rounded text-xs font-mono font-bold', isDark ? 'bg-slate-700 text-slate-300' : 'bg-slate-100 text-slate-600')}>{driver.license || '—'}</span>
                    </td>
                    {canWrite && (
                      <td className="px-4 py-3">
                        <div className="flex items-center justify-center gap-1">
                          <button onClick={() => { setDriverForm(driver); setEditId(driver.id); setShowForm(true); }}
                            className="p-1.5 rounded text-blue-400 hover:bg-blue-500/20"><Edit size={13} /></button>
                          <button onClick={() => handleDelete(driver.id, 'drivers')}
                            className={cn('p-1.5 rounded transition-colors', confirmDelete === driver.id ? 'bg-red-500 text-white' : 'text-red-400 hover:bg-red-500/20')}>
                            <Trash2 size={13} /></button>
                        </div>
                      </td>
                    )}
                  </tr>
                ))}
              </tbody>
            </table>
            {filteredDrivers.length === 0 && <EmptyState label="chauffeur" isDark={isDark} />}
          </div>
        )}
      </div>
    </div>
  );
};

const EmptyState: React.FC<{ label: string; isDark: boolean }> = ({ label, isDark }) => (
  <div className={cn('text-center py-10', isDark ? 'text-slate-500' : 'text-slate-400')}>
    Aucun {label} trouvé
  </div>
);

export default ClientsPage;
