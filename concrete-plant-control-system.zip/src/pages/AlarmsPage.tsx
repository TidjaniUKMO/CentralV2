/**
 * BétonPro SCADA - Gestion des alarmes
 * Système alarmes industrielles complet
 */
import React, { useState } from 'react';
import { useStore } from '../store';
import { AlertTriangle, CheckCircle, Bell, BellOff, Clock, Filter, Trash2 } from 'lucide-react';
import { cn } from '../utils/cn';
import { format } from 'date-fns';
import type { AlarmPriority } from '../types';

export const AlarmsPage: React.FC = () => {
  const { theme, alarms, acknowledgeAlarm, acknowledgeAllAlarms, clearInactiveAlarms, auth, addAlarm } = useStore();
  const isDark = theme === 'dark';
  const [tab, setTab] = useState<'active' | 'all'>('active');
  const [filterPriority, setFilterPriority] = useState<AlarmPriority | 'all'>('all');

  const activeAlarms = alarms.filter(a => a.active && !a.acknowledged);
  const allAlarms = alarms.filter(a => {
    if (filterPriority !== 'all' && a.priority !== filterPriority) return false;
    return true;
  });

  const displayed = tab === 'active' ? activeAlarms : allAlarms;

  const priorityConfig = {
    critical: { label: 'CRITIQUE', class: 'bg-red-500/20 text-red-400 border-red-500/50', icon: '🔴', dot: 'bg-red-500' },
    warning: { label: 'AVERTISSEMENT', class: 'bg-yellow-500/20 text-yellow-400 border-yellow-500/50', icon: '🟡', dot: 'bg-yellow-500' },
    info: { label: 'INFO', class: 'bg-blue-500/20 text-blue-400 border-blue-500/50', icon: '🔵', dot: 'bg-blue-500' },
  };

  // Simulation: add test alarm
  const addTestAlarm = (priority: AlarmPriority) => {
    const messages: Record<AlarmPriority, string> = {
      critical: 'ARRÊT URGENCE — Bouton EA actionné en zone malaxeur',
      warning: 'Surcharge moteur malaxeur détectée — Courant: 68A (max: 55A)',
      info: 'Niveau bas trémie Sable 0/4 — Niveau: 18%',
    };
    addAlarm({
      type: priority === 'critical' ? 'emergency_stop' : priority === 'warning' ? 'motor_overload' : 'level_low',
      priority,
      message: messages[priority],
      source: 'Simulateur',
      active: true,
      acknowledged: false,
    });
  };

  return (
    <div className={cn('h-full flex flex-col', isDark ? 'bg-slate-900 text-white' : 'bg-slate-50 text-slate-900')}>
      {/* Header */}
      <div className={cn('px-4 py-3 border-b flex items-center gap-3 flex-wrap', isDark ? 'border-slate-700' : 'border-slate-200')}>
        <div className="flex gap-1">
          {(['active', 'all'] as const).map(t => (
            <button key={t} onClick={() => setTab(t)}
              className={cn('px-3 py-1.5 rounded-lg text-sm font-medium transition-colors',
                tab === t ? 'bg-orange-500 text-white' : isDark ? 'text-slate-400 hover:text-white' : 'text-slate-500 hover:text-slate-900'
              )}>
              {t === 'active' ? `Actives (${activeAlarms.length})` : `Toutes (${alarms.length})`}
            </button>
          ))}
        </div>

        {/* Priority filter */}
        <div className="flex items-center gap-1">
          {(['all', 'critical', 'warning', 'info'] as const).map(p => (
            <button key={p} onClick={() => setFilterPriority(p)}
              className={cn('px-2 py-1 rounded-lg text-xs font-medium transition-colors',
                filterPriority === p ? 'bg-slate-600 text-white' : isDark ? 'text-slate-400 hover:bg-slate-700' : 'text-slate-500 hover:bg-slate-100'
              )}>
              {p === 'all' ? 'Tout' : p === 'critical' ? '🔴 Critique' : p === 'warning' ? '🟡 Avert.' : '🔵 Info'}
            </button>
          ))}
        </div>

        <div className="flex items-center gap-2 ml-auto flex-wrap">
          {/* Test buttons */}
          {process.env.NODE_ENV !== 'production' && (
            <div className="flex items-center gap-1">
              <span className="text-xs text-slate-500 mr-1">TEST:</span>
              <button onClick={() => addTestAlarm('critical')} className="px-2 py-1 text-xs rounded bg-red-500/20 text-red-400 hover:bg-red-500/30 border border-red-500/30">Critique</button>
              <button onClick={() => addTestAlarm('warning')} className="px-2 py-1 text-xs rounded bg-yellow-500/20 text-yellow-400 hover:bg-yellow-500/30 border border-yellow-500/30">Avert.</button>
              <button onClick={() => addTestAlarm('info')} className="px-2 py-1 text-xs rounded bg-blue-500/20 text-blue-400 hover:bg-blue-500/30 border border-blue-500/30">Info</button>
            </div>
          )}
          {activeAlarms.length > 0 && (
            <button
              onClick={() => acknowledgeAllAlarms(auth.user?.id || '')}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-green-500 hover:bg-green-600 text-white text-xs font-bold transition-all"
            >
              <CheckCircle size={13} /> Acquitter tout
            </button>
          )}
          <button
            onClick={clearInactiveAlarms}
            className={cn('flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-colors',
              isDark ? 'bg-slate-700 text-slate-300 hover:bg-slate-600' : 'bg-slate-200 text-slate-600 hover:bg-slate-300'
            )}
          >
            <Trash2 size={13} /> Nettoyer
          </button>
        </div>
      </div>

      {/* Stats */}
      <div className="flex items-center gap-3 px-4 py-2 flex-wrap">
        {[
          { label: 'Critiques', count: alarms.filter(a => a.priority === 'critical' && a.active).length, color: 'text-red-400', bg: 'bg-red-500/10 border-red-500/30' },
          { label: 'Avertissements', count: alarms.filter(a => a.priority === 'warning' && a.active).length, color: 'text-yellow-400', bg: 'bg-yellow-500/10 border-yellow-500/30' },
          { label: 'Non acquittées', count: activeAlarms.length, color: 'text-orange-400', bg: 'bg-orange-500/10 border-orange-500/30' },
          { label: 'Total', count: alarms.length, color: isDark ? 'text-slate-300' : 'text-slate-700', bg: isDark ? 'bg-slate-800 border-slate-700' : 'bg-white border-slate-200' },
        ].map((s, i) => (
          <div key={i} className={cn('flex items-center gap-2 px-3 py-1.5 rounded-lg border text-xs font-medium', s.bg)}>
            <span className={cn('font-black text-base', s.color)}>{s.count}</span>
            <span className={isDark ? 'text-slate-400' : 'text-slate-500'}>{s.label}</span>
          </div>
        ))}
      </div>

      {/* Alarms list */}
      <div className="flex-1 overflow-auto p-4">
        {displayed.length === 0 ? (
          <div className={cn('flex flex-col items-center justify-center h-48 rounded-xl border', isDark ? 'bg-slate-800 border-slate-700 text-slate-500' : 'bg-white border-slate-200 text-slate-400')}>
            <CheckCircle size={40} className="mb-3 text-green-400 opacity-60" />
            <p className="font-medium">Aucune alarme {tab === 'active' ? 'active' : ''}</p>
          </div>
        ) : (
          <div className="space-y-2">
            {displayed.map(alarm => {
              const cfg = priorityConfig[alarm.priority];
              return (
                <div
                  key={alarm.id}
                  className={cn(
                    'rounded-xl border p-4 transition-all',
                    alarm.acknowledged
                      ? isDark ? 'bg-slate-800/50 border-slate-700 opacity-60' : 'bg-white border-slate-200 opacity-60'
                      : cn(cfg.class, alarm.priority === 'critical' && !alarm.acknowledged && 'animate-pulse-border'),
                  )}
                >
                  <div className="flex items-start gap-3">
                    <div className={cn('w-2.5 h-2.5 rounded-full mt-1 flex-shrink-0', cfg.dot, !alarm.acknowledged && 'animate-pulse')} />
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap mb-1">
                        <span className={cn('text-xs font-black uppercase px-2 py-0.5 rounded border', cfg.class)}>
                          {cfg.label}
                        </span>
                        <span className={cn('text-xs font-mono', isDark ? 'text-slate-500' : 'text-slate-400')}>
                          {format(new Date(alarm.timestamp), 'dd/MM/yyyy HH:mm:ss')}
                        </span>
                        <span className={cn('text-xs px-2 py-0.5 rounded-full', isDark ? 'bg-slate-700 text-slate-400' : 'bg-slate-100 text-slate-500')}>
                          {alarm.source}
                        </span>
                        {alarm.acknowledged && (
                          <span className="text-xs text-green-400 flex items-center gap-1">
                            <CheckCircle size={10} /> Acquitté par {alarm.acknowledgedBy}
                          </span>
                        )}
                      </div>
                      <p className={cn('font-medium', isDark ? 'text-white' : 'text-slate-900')}>{alarm.message}</p>
                      {alarm.detail && (
                        <p className={cn('text-xs mt-1', isDark ? 'text-slate-400' : 'text-slate-500')}>{alarm.detail}</p>
                      )}
                    </div>
                    {!alarm.acknowledged && (
                      <button
                        onClick={() => acknowledgeAlarm(alarm.id, auth.user?.username || '')}
                        className="flex-shrink-0 flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-green-500 hover:bg-green-600 text-white text-xs font-bold transition-all"
                      >
                        <CheckCircle size={12} /> Acquitter
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};

export default AlarmsPage;
