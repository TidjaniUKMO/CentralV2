/**
 * BétonPro SCADA - Paramètres système
 * Temporisations + Impulsions vérins (accessible exploitant)
 */
import React, { useState } from 'react';
import { useStore } from '../store';
import { Save, Clock, Zap, Info, RotateCcw } from 'lucide-react';
import { cn } from '../utils/cn';
import type { Timers, ImpulseConfig } from '../types';

export const ParametersPage: React.FC = () => {
  const { theme, timers, setTimers, impulseConfig, setImpulseConfig } = useStore();
  const isDark = theme === 'dark';

  const [localTimers, setLocalTimers] = useState<Timers>({ ...timers });
  const [localImpulse, setLocalImpulse] = useState<ImpulseConfig>({ ...impulseConfig });
  const [saved, setSaved] = useState(false);

  const handleSaveTimers = () => {
    setTimers(localTimers);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  const handleSaveImpulse = () => {
    setImpulseConfig(localImpulse);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  const handleResetTimers = () => {
    const defaults: Timers = {
      valveOpenTime: 3000, valveCloseTime: 2000, conveyorStartTime: 5000,
      skipTime: 30000, mixingTime: 60000, safetyTimeout: 10000,
      alarmTimeout: 5000, dischargeTimeout: 120000, cementFlowTimeout: 30000, waterFlowTimeout: 20000,
    };
    setLocalTimers(defaults);
  };

  const cardClass = cn('rounded-xl border p-5', isDark ? 'bg-slate-800 border-slate-700' : 'bg-white border-slate-200');

  const TimerInput: React.FC<{
    label: string; description?: string; value: number; onChange: (v: number) => void; min?: number; max?: number; unit?: string
  }> = ({ label, description, value, onChange, min = 100, max = 300000, unit = 'ms' }) => (
    <div className={cn('p-3 rounded-lg', isDark ? 'bg-slate-700' : 'bg-slate-50')}>
      <div className="flex items-start justify-between gap-4">
        <div className="flex-1">
          <label className={cn('text-sm font-medium', isDark ? 'text-white' : 'text-slate-900')}>{label}</label>
          {description && <p className={cn('text-xs mt-0.5', isDark ? 'text-slate-500' : 'text-slate-400')}>{description}</p>}
        </div>
        <div className="flex items-center gap-2">
          <input
            type="number" min={min} max={max} step={100}
            value={value}
            onChange={e => onChange(parseInt(e.target.value) || min)}
            className={cn('w-28 px-2 py-1.5 rounded-lg border text-sm text-right font-mono', isDark ? 'bg-slate-800 border-slate-600 text-white' : 'bg-white border-slate-200 text-slate-900')}
          />
          <span className={cn('text-xs w-8', isDark ? 'text-slate-400' : 'text-slate-500')}>{unit}</span>
        </div>
      </div>
      {/* Visual progress bar */}
      <div className={cn('mt-2 h-1 rounded-full', isDark ? 'bg-slate-600' : 'bg-slate-200')}>
        <div
          className="h-1 rounded-full bg-gradient-to-r from-orange-500 to-amber-400 transition-all"
          style={{ width: `${Math.min(100, (value / max) * 100)}%` }}
        />
      </div>
      <div className="flex justify-between text-xs text-slate-500 mt-0.5">
        <span>{min}ms</span><span>{max}ms</span>
      </div>
    </div>
  );

  return (
    <div className={cn('h-full overflow-auto', isDark ? 'bg-slate-900 text-white' : 'bg-slate-50 text-slate-900')}>
      <div className="max-w-4xl mx-auto p-4 space-y-4">

        {/* Saved notification */}
        {saved && (
          <div className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-green-500/20 border border-green-500/40 text-green-400 text-sm font-medium">
            <Save size={14} /> Paramètres enregistrés avec succès
          </div>
        )}

        {/* ======= TEMPORISATIONS ======= */}
        <div className={cardClass}>
          <div className="flex items-center justify-between mb-4">
            <h2 className={cn('text-base font-bold flex items-center gap-2', isDark ? 'text-white' : 'text-slate-900')}>
              <Clock size={18} className="text-orange-400" /> Temporisations
            </h2>
            <button onClick={handleResetTimers} className={cn('flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs', isDark ? 'bg-slate-700 text-slate-300 hover:bg-slate-600' : 'bg-slate-100 text-slate-600 hover:bg-slate-200')}>
              <RotateCcw size={12} /> Défaut
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <TimerInput
              label="Ouverture vérin"
              description="Temps d'ouverture complète d'un vérin pneumatique"
              value={localTimers.valveOpenTime}
              onChange={v => setLocalTimers(t => ({ ...t, valveOpenTime: v }))}
              min={500} max={10000}
            />
            <TimerInput
              label="Fermeture vérin"
              description="Temps de fermeture complète d'un vérin"
              value={localTimers.valveCloseTime}
              onChange={v => setLocalTimers(t => ({ ...t, valveCloseTime: v }))}
              min={500} max={10000}
            />
            <TimerInput
              label="Démarrage convoyeur"
              description="Délai avant autorisation passage matériau"
              value={localTimers.conveyorStartTime}
              onChange={v => setLocalTimers(t => ({ ...t, conveyorStartTime: v }))}
              min={1000} max={30000}
            />
            <TimerInput
              label="Cycle skip"
              description="Temps maximum montée/descente skip complet"
              value={localTimers.skipTime}
              onChange={v => setLocalTimers(t => ({ ...t, skipTime: v }))}
              min={5000} max={120000}
            />
            <TimerInput
              label="Malaxage"
              description="Durée minimale de malaxage par gâchée"
              value={localTimers.mixingTime}
              onChange={v => setLocalTimers(t => ({ ...t, mixingTime: v }))}
              min={10000} max={300000}
            />
            <TimerInput
              label="Timeout sécurité"
              description="Délai avant génération alarme sécurité"
              value={localTimers.safetyTimeout}
              onChange={v => setLocalTimers(t => ({ ...t, safetyTimeout: v }))}
              min={1000} max={60000}
            />
            <TimerInput
              label="Timeout alarme"
              description="Délai avant escalade alarme"
              value={localTimers.alarmTimeout}
              onChange={v => setLocalTimers(t => ({ ...t, alarmTimeout: v }))}
              min={1000} max={30000}
            />
            <TimerInput
              label="Timeout vidange"
              description="Temps maximum pour vidange complète malaxeur"
              value={localTimers.dischargeTimeout}
              onChange={v => setLocalTimers(t => ({ ...t, dischargeTimeout: v }))}
              min={10000} max={600000}
            />
            <TimerInput
              label="Timeout débit ciment"
              description="Alarme si pesée ciment dépasse ce délai"
              value={localTimers.cementFlowTimeout}
              onChange={v => setLocalTimers(t => ({ ...t, cementFlowTimeout: v }))}
              min={5000} max={120000}
            />
            <TimerInput
              label="Timeout débit eau"
              description="Alarme si pesée eau dépasse ce délai"
              value={localTimers.waterFlowTimeout}
              onChange={v => setLocalTimers(t => ({ ...t, waterFlowTimeout: v }))}
              min={2000} max={60000}
            />
          </div>

          <button onClick={handleSaveTimers} className="mt-4 flex items-center gap-2 px-5 py-2.5 rounded-xl bg-orange-500 hover:bg-orange-600 text-white font-bold text-sm transition-all shadow-lg shadow-orange-500/30">
            <Save size={14} /> Enregistrer temporisations
          </button>
        </div>

        {/* ======= GESTION IMPULSIONS VÉRINS ======= */}
        <div className={cardClass}>
          <div className="flex items-center justify-between mb-4">
            <h2 className={cn('text-base font-bold flex items-center gap-2', isDark ? 'text-white' : 'text-slate-900')}>
              <Zap size={18} className="text-yellow-400" /> Gestion Impulsions Vérins
            </h2>
            <div className={cn('flex items-center gap-2 text-xs', isDark ? 'bg-slate-700 text-slate-400' : 'bg-slate-100 text-slate-500', 'px-3 py-1.5 rounded-lg')}>
              <Info size={12} /> Réglage fin de pesée
            </div>
          </div>

          <div className={cn('p-3 rounded-lg mb-4 text-xs', isDark ? 'bg-blue-500/10 border border-blue-500/30 text-blue-300' : 'bg-blue-50 border border-blue-200 text-blue-700')}>
            <strong>Mode impulsions :</strong> Lorsque le poids atteint le pourcentage configuré de la consigne,
            le vérin passe en mode pulsé (ON/OFF alterné) pour un dosage de précision jusqu'à la consigne exacte.
          </div>

          <div className="space-y-3">
            {/* Enable/Disable */}
            <div className={cn('flex items-center justify-between p-3 rounded-lg', isDark ? 'bg-slate-700' : 'bg-slate-50')}>
              <div>
                <div className={cn('text-sm font-medium', isDark ? 'text-white' : 'text-slate-900')}>Activer les impulsions</div>
                <div className={cn('text-xs', isDark ? 'text-slate-400' : 'text-slate-500')}>Active le mode impulsionnel pour le dosage fin</div>
              </div>
              <button
                onClick={() => setLocalImpulse(i => ({ ...i, enabled: !i.enabled }))}
                className={cn(
                  'relative w-12 h-6 rounded-full transition-all duration-300',
                  localImpulse.enabled ? 'bg-green-500' : isDark ? 'bg-slate-600' : 'bg-slate-300'
                )}
              >
                <span className={cn('absolute top-1 w-4 h-4 bg-white rounded-full shadow transition-all duration-300', localImpulse.enabled ? 'left-7' : 'left-1')} />
              </button>
            </div>

            {localImpulse.enabled && (
              <>
                {/* Trigger percent */}
                <div className={cn('p-3 rounded-lg', isDark ? 'bg-slate-700' : 'bg-slate-50')}>
                  <div className="flex items-center justify-between gap-4">
                    <div>
                      <label className={cn('text-sm font-medium', isDark ? 'text-white' : 'text-slate-900')}>Seuil de déclenchement</label>
                      <p className={cn('text-xs', isDark ? 'text-slate-400' : 'text-slate-500')}>% du poids consigne pour passer en mode impulsion</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <input
                        type="number" min={50} max={99} step={1}
                        value={localImpulse.triggerPercent}
                        onChange={e => setLocalImpulse(i => ({ ...i, triggerPercent: parseInt(e.target.value) || 90 }))}
                        className={cn('w-20 px-2 py-1.5 rounded-lg border text-sm text-right font-mono', isDark ? 'bg-slate-800 border-slate-600 text-white' : 'bg-white border-slate-200 text-slate-900')}
                      />
                      <span className={cn('text-xs', isDark ? 'text-slate-400' : 'text-slate-500')}>%</span>
                    </div>
                  </div>
                  <div className="mt-3 relative h-6 bg-slate-600 rounded-full overflow-hidden">
                    <div className="absolute inset-y-0 left-0 bg-orange-500/30" style={{ width: `${localImpulse.triggerPercent}%` }} />
                    <div className="absolute inset-y-0 bg-yellow-400/40" style={{ left: `${localImpulse.triggerPercent}%`, right: 0 }} />
                    <div className="absolute inset-0 flex items-center justify-center text-xs font-bold text-white">
                      Remplissage rapide | {localImpulse.triggerPercent}% → Mode impulsions
                    </div>
                    <div className="absolute top-0 bottom-0 w-0.5 bg-yellow-400" style={{ left: `${localImpulse.triggerPercent}%` }} />
                  </div>
                </div>

                {/* Impulse ON */}
                <div className={cn('p-3 rounded-lg', isDark ? 'bg-slate-700' : 'bg-slate-50')}>
                  <div className="flex items-center justify-between gap-4">
                    <div>
                      <label className={cn('text-sm font-medium text-green-400')}>Durée impulsion ON</label>
                      <p className={cn('text-xs', isDark ? 'text-slate-400' : 'text-slate-500')}>Durée d'ouverture du vérin pendant une impulsion</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <input
                        type="number" min={50} max={5000} step={50}
                        value={localImpulse.impulseOnTime}
                        onChange={e => setLocalImpulse(i => ({ ...i, impulseOnTime: parseInt(e.target.value) || 200 }))}
                        className={cn('w-24 px-2 py-1.5 rounded-lg border text-sm text-right font-mono', isDark ? 'bg-slate-800 border-slate-600 text-white' : 'bg-white border-slate-200 text-slate-900')}
                      />
                      <span className="text-xs text-slate-400">ms</span>
                    </div>
                  </div>
                </div>

                {/* Impulse OFF */}
                <div className={cn('p-3 rounded-lg', isDark ? 'bg-slate-700' : 'bg-slate-50')}>
                  <div className="flex items-center justify-between gap-4">
                    <div>
                      <label className={cn('text-sm font-medium text-red-400')}>Durée impulsion OFF</label>
                      <p className={cn('text-xs', isDark ? 'text-slate-400' : 'text-slate-500')}>Durée de fermeture du vérin entre deux impulsions</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <input
                        type="number" min={50} max={5000} step={50}
                        value={localImpulse.impulseOffTime}
                        onChange={e => setLocalImpulse(i => ({ ...i, impulseOffTime: parseInt(e.target.value) || 200 }))}
                        className={cn('w-24 px-2 py-1.5 rounded-lg border text-sm text-right font-mono', isDark ? 'bg-slate-800 border-slate-600 text-white' : 'bg-white border-slate-200 text-slate-900')}
                      />
                      <span className="text-xs text-slate-400">ms</span>
                    </div>
                  </div>
                </div>

                {/* Visual preview */}
                <div className={cn('p-3 rounded-lg', isDark ? 'bg-slate-700' : 'bg-slate-50')}>
                  <div className={cn('text-xs font-bold mb-2', isDark ? 'text-slate-400' : 'text-slate-500')}>APERÇU SIGNAL IMPULSIONNEL</div>
                  <div className="flex items-end gap-0.5 h-10">
                    {/* ON pulse */}
                    <div className="bg-green-500 rounded-sm" style={{ width: `${(localImpulse.impulseOnTime / (localImpulse.impulseOnTime + localImpulse.impulseOffTime)) * 80}%`, height: '100%' }} />
                    {/* OFF pulse */}
                    <div className="bg-red-500/40 rounded-sm" style={{ width: `${(localImpulse.impulseOffTime / (localImpulse.impulseOnTime + localImpulse.impulseOffTime)) * 80}%`, height: '40%' }} />
                    {/* Repeat */}
                    <div className="bg-green-500 rounded-sm" style={{ width: `${(localImpulse.impulseOnTime / (localImpulse.impulseOnTime + localImpulse.impulseOffTime)) * 80 * 0.5}%`, height: '100%' }} />
                    <div className="bg-red-500/40 rounded-sm" style={{ width: `${(localImpulse.impulseOffTime / (localImpulse.impulseOnTime + localImpulse.impulseOffTime)) * 80 * 0.5}%`, height: '40%' }} />
                    <div className="text-slate-400 text-xs ml-2 self-center">...</div>
                  </div>
                  <div className="flex text-xs text-slate-400 mt-1">
                    <span>ON: {localImpulse.impulseOnTime}ms</span>
                    <span className="mx-2">|</span>
                    <span>OFF: {localImpulse.impulseOffTime}ms</span>
                    <span className="mx-2">|</span>
                    <span>Cycle: {localImpulse.impulseOnTime + localImpulse.impulseOffTime}ms</span>
                  </div>
                </div>
              </>
            )}
          </div>

          <button onClick={handleSaveImpulse} className="mt-4 flex items-center gap-2 px-5 py-2.5 rounded-xl bg-yellow-500 hover:bg-yellow-600 text-white font-bold text-sm transition-all">
            <Save size={14} /> Enregistrer impulsions
          </button>
        </div>
      </div>
    </div>
  );
};

export default ParametersPage;
