/**
 * BétonPro SCADA - Module Production
 * Lancement, suivi de cycle, historique complet
 */
import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useStore } from '../store';
import {
  Play, Square, Pause, RotateCcw, Plus, Search,
  CheckCircle, XCircle, Clock, User, Truck, ChevronRight,
  AlertTriangle, BarChart3, Calendar, Factory
} from 'lucide-react';
import { cn } from '../utils/cn';
import { format } from 'date-fns';
import { fr } from 'date-fns/locale';
import type { Recipe, Client, ProductionBatch } from '../types';

export const ProductionPage: React.FC = () => {
  const { t } = useTranslation();
  const { theme, recipes, clients, trucks, drivers, auth, currentBatch,
    startProduction, stopProduction, updateCurrentBatch, completeProduction,
    productionBatches, plantConfig, simulatorState, setSimulatorState } = useStore();
  const isDark = theme === 'dark';

  const [tab, setTab] = useState<'launch' | 'history'>('launch');
  const [search, setSearch] = useState('');
  const [form, setForm] = useState({
    recipeId: '',
    clientId: '',
    truckId: '',
    driverId: '',
    quantity: '7',
    notes: '',
  });
  const [error, setError] = useState('');
  const [showValidation, setShowValidation] = useState(false);

  const activeRecipes = recipes.filter(r => r.active);
  const activeClients = clients.filter(c => c.active);
  const selectedRecipe = recipes.find(r => r.id === form.recipeId);
  const clientTrucks = trucks.filter(t => t.clientId === form.clientId && t.active);
  const clientDrivers = drivers.filter(d => d.clientId === form.clientId && d.active);

  // Validation recette vs config centrale
  const validateRecipe = (recipe: Recipe): string[] => {
    const errors: string[] = [];
    const activeHoppers = plantConfig.hoppers.filter(h => h.active).map(h => h.id);
    const activeSilos = plantConfig.silos.filter(s => s.active).map(s => s.id);

    recipe.aggregates.forEach(agg => {
      if (!activeHoppers.includes(agg.hopperId)) {
        errors.push(`Trémie "${agg.hopperName}" non disponible ou inactive`);
      }
    });
    recipe.cement.forEach(cem => {
      if (!activeSilos.includes(cem.siloId)) {
        errors.push(`Silo "${cem.siloName}" non disponible ou inactif`);
      }
    });
    if (recipe.waterVolume > 0) {
      const activeWater = plantConfig.waterTanks.filter(w => w.active);
      if (activeWater.length === 0) errors.push('Aucun réservoir eau actif');
    }
    if (recipe.adjuvantVolume > 0) {
      const activeAdj = plantConfig.adjuvantTanks.filter(a => a.active);
      if (activeAdj.length === 0) errors.push('Aucun réservoir adjuvant actif');
    }
    return errors;
  };

  const validationErrors = selectedRecipe ? validateRecipe(selectedRecipe) : [];

  const handleLaunch = () => {
    if (!form.recipeId) { setError('Veuillez sélectionner une recette'); return; }
    if (validationErrors.length > 0) { setShowValidation(true); return; }
    if (!selectedRecipe) return;

    const client = clients.find(c => c.id === form.clientId);
    const truck = trucks.find(t => t.id === form.truckId);
    const driver = drivers.find(d => d.id === form.driverId);

    startProduction({
      recipeId: selectedRecipe.id,
      recipeName: selectedRecipe.name,
      clientId: client?.id,
      clientName: client?.name,
      truckId: truck?.id,
      truckPlate: truck?.plate,
      driverId: driver?.id,
      driverName: driver?.name,
      operatorId: auth.user?.id || 'unknown',
      operatorName: auth.user?.username || 'unknown',
      quantityOrdered: parseFloat(form.quantity) || 7,
      weightsTarget: {
        aggregates: selectedRecipe.aggregates.reduce((acc, a) => acc + a.weight, 0),
        cement: selectedRecipe.cement.reduce((acc, c) => acc + c.weight, 0),
        water: selectedRecipe.waterVolume,
        adjuvant: selectedRecipe.adjuvantVolume,
      },
      notes: form.notes,
      currentStep: 'aggregate_weighing',
    } as any);

    // Activer scénario auto si simulateur
    if (simulatorState.enabled) {
      setSimulatorState({ autoScenario: true });
    }
  };

  const handleStop = () => {
    stopProduction('Arrêt opérateur');
    setSimulatorState({ autoScenario: false });
  };

  // History filter
  const filteredHistory = productionBatches.filter(b => {
    if (!search) return true;
    const s = search.toLowerCase();
    return b.recipeName?.toLowerCase().includes(s) ||
      b.clientName?.toLowerCase().includes(s) ||
      b.truckPlate?.toLowerCase().includes(s) ||
      b.batchNumber?.toLowerCase().includes(s) ||
      b.operatorName?.toLowerCase().includes(s);
  });

  const stepLabels: Record<string, string> = {
    idle: 'En attente',
    aggregate_weighing: '⚖ Pesée agrégats',
    cement_weighing: '⚖ Pesée ciment',
    water_weighing: '💧 Pesée eau',
    adjuvant_weighing: '🧪 Pesée adjuvant',
    mixing: '🔄 Malaxage',
    discharge: '📤 Vidange',
    done: '✅ Terminé',
  };

  return (
    <div className={cn('h-full flex flex-col', isDark ? 'bg-slate-900 text-white' : 'bg-slate-50 text-slate-900')}>
      {/* Tabs */}
      <div className={cn('flex border-b px-4', isDark ? 'border-slate-700' : 'border-slate-200')}>
        {([['launch', '🚀 Lancement'], ['history', '📋 Historique']] as const).map(([id, label]) => (
          <button
            key={id}
            onClick={() => setTab(id)}
            className={cn(
              'px-4 py-3 text-sm font-medium border-b-2 transition-colors',
              tab === id
                ? 'border-orange-500 text-orange-500'
                : `border-transparent ${isDark ? 'text-slate-400 hover:text-white' : 'text-slate-500 hover:text-slate-900'}`
            )}
          >{label}</button>
        ))}
      </div>

      <div className="flex-1 overflow-auto p-4">
        {tab === 'launch' ? (
          <div className="max-w-5xl mx-auto space-y-4">
            {/* Current batch status */}
            {currentBatch && (
              <CurrentBatchPanel batch={currentBatch} onStop={handleStop} isDark={isDark} stepLabels={stepLabels} />
            )}

            {!currentBatch && (
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                {/* Form */}
                <div className={cn('rounded-xl border p-5', isDark ? 'bg-slate-800 border-slate-700' : 'bg-white border-slate-200')}>
                  <h3 className={cn('text-base font-bold mb-4 flex items-center gap-2', isDark ? 'text-white' : 'text-slate-900')}>
                    <Plus size={16} className="text-orange-500" /> Nouvelle gâchée
                  </h3>

                  {/* Recipe */}
                  <div className="mb-3">
                    <label className={cn('block text-xs font-semibold mb-1 uppercase', isDark ? 'text-slate-400' : 'text-slate-500')}>
                      Recette *
                    </label>
                    <select
                      value={form.recipeId}
                      onChange={e => setForm(f => ({ ...f, recipeId: e.target.value }))}
                      className={cn('w-full px-3 py-2.5 rounded-lg border text-sm', isDark ? 'bg-slate-700 border-slate-600 text-white' : 'bg-slate-50 border-slate-200 text-slate-900')}
                    >
                      <option value="">-- Sélectionner une recette --</option>
                      {activeRecipes.map(r => (
                        <option key={r.id} value={r.id}>{r.code} - {r.name}</option>
                      ))}
                    </select>
                  </div>

                  {/* Recipe detail */}
                  {selectedRecipe && (
                    <div className={cn('mb-3 p-3 rounded-lg text-xs space-y-1', isDark ? 'bg-slate-700' : 'bg-slate-50')}>
                      {selectedRecipe.aggregates.map(a => (
                        <div key={a.hopperId} className="flex justify-between">
                          <span className={isDark ? 'text-slate-300' : 'text-slate-600'}>{a.hopperName}</span>
                          <span className="font-bold">{a.weight} kg</span>
                        </div>
                      ))}
                      {selectedRecipe.cement.map(c => (
                        <div key={c.siloId} className="flex justify-between">
                          <span className={isDark ? 'text-slate-300' : 'text-slate-600'}>{c.siloName}</span>
                          <span className="font-bold">{c.weight} kg</span>
                        </div>
                      ))}
                      <div className="flex justify-between">
                        <span className={isDark ? 'text-slate-300' : 'text-slate-600'}>Eau</span>
                        <span className="font-bold">{selectedRecipe.waterVolume} L</span>
                      </div>
                      {selectedRecipe.adjuvantVolume > 0 && (
                        <div className="flex justify-between">
                          <span className={isDark ? 'text-slate-300' : 'text-slate-600'}>Adjuvant</span>
                          <span className="font-bold">{selectedRecipe.adjuvantVolume} L</span>
                        </div>
                      )}
                      <div className="pt-1 border-t border-slate-600 flex justify-between font-bold text-orange-400">
                        <span>Total</span><span>{selectedRecipe.totalWeight} kg</span>
                      </div>
                    </div>
                  )}

                  {/* Validation errors */}
                  {validationErrors.length > 0 && (
                    <div className="mb-3 p-3 rounded-lg bg-red-500/10 border border-red-500/30">
                      <div className="flex items-center gap-1 text-red-400 text-xs font-bold mb-1">
                        <AlertTriangle size={12} /> Problèmes détectés
                      </div>
                      {validationErrors.map((e, i) => (
                        <div key={i} className="text-xs text-red-300">• {e}</div>
                      ))}
                    </div>
                  )}

                  {/* Client */}
                  <div className="mb-3">
                    <label className={cn('block text-xs font-semibold mb-1 uppercase', isDark ? 'text-slate-400' : 'text-slate-500')}>Client</label>
                    <select
                      value={form.clientId}
                      onChange={e => setForm(f => ({ ...f, clientId: e.target.value, truckId: '', driverId: '' }))}
                      className={cn('w-full px-3 py-2.5 rounded-lg border text-sm', isDark ? 'bg-slate-700 border-slate-600 text-white' : 'bg-slate-50 border-slate-200 text-slate-900')}
                    >
                      <option value="">-- Sélectionner un client --</option>
                      {activeClients.map(c => (
                        <option key={c.id} value={c.id}>{c.name}</option>
                      ))}
                    </select>
                  </div>

                  {form.clientId && (
                    <div className="grid grid-cols-2 gap-3 mb-3">
                      <div>
                        <label className={cn('block text-xs font-semibold mb-1 uppercase', isDark ? 'text-slate-400' : 'text-slate-500')}>Camion</label>
                        <select
                          value={form.truckId}
                          onChange={e => setForm(f => ({ ...f, truckId: e.target.value }))}
                          className={cn('w-full px-3 py-2.5 rounded-lg border text-sm', isDark ? 'bg-slate-700 border-slate-600 text-white' : 'bg-slate-50 border-slate-200 text-slate-900')}
                        >
                          <option value="">-- Camion --</option>
                          {clientTrucks.map(t => <option key={t.id} value={t.id}>{t.plate}</option>)}
                        </select>
                      </div>
                      <div>
                        <label className={cn('block text-xs font-semibold mb-1 uppercase', isDark ? 'text-slate-400' : 'text-slate-500')}>Chauffeur</label>
                        <select
                          value={form.driverId}
                          onChange={e => setForm(f => ({ ...f, driverId: e.target.value }))}
                          className={cn('w-full px-3 py-2.5 rounded-lg border text-sm', isDark ? 'bg-slate-700 border-slate-600 text-white' : 'bg-slate-50 border-slate-200 text-slate-900')}
                        >
                          <option value="">-- Chauffeur --</option>
                          {clientDrivers.map(d => <option key={d.id} value={d.id}>{d.name}</option>)}
                        </select>
                      </div>
                    </div>
                  )}

                  {/* Quantity */}
                  <div className="mb-4">
                    <label className={cn('block text-xs font-semibold mb-1 uppercase', isDark ? 'text-slate-400' : 'text-slate-500')}>Quantité (m³)</label>
                    <input
                      type="number" min="0.5" max="20" step="0.5"
                      value={form.quantity}
                      onChange={e => setForm(f => ({ ...f, quantity: e.target.value }))}
                      className={cn('w-full px-3 py-2.5 rounded-lg border text-sm', isDark ? 'bg-slate-700 border-slate-600 text-white' : 'bg-slate-50 border-slate-200 text-slate-900')}
                    />
                  </div>

                  {error && <div className="mb-3 text-xs text-red-400 bg-red-500/10 border border-red-500/30 rounded-lg px-3 py-2">{error}</div>}

                  <button
                    onClick={handleLaunch}
                    disabled={validationErrors.length > 0 && !form.recipeId}
                    className={cn(
                      'w-full py-3 rounded-xl font-bold text-sm transition-all flex items-center justify-center gap-2',
                      'bg-gradient-to-r from-green-500 to-emerald-600 text-white hover:from-green-600 hover:to-emerald-700 shadow-lg shadow-green-500/30 hover:-translate-y-0.5',
                      (!form.recipeId) && 'opacity-50 cursor-not-allowed'
                    )}
                  >
                    <Play size={16} /> Lancer la production
                  </button>
                </div>

                {/* Stats panel */}
                <div className="space-y-3">
                  <div className={cn('rounded-xl border p-4', isDark ? 'bg-slate-800 border-slate-700' : 'bg-white border-slate-200')}>
                    <h3 className={cn('text-sm font-bold mb-3 flex items-center gap-2', isDark ? 'text-white' : 'text-slate-900')}>
                      <BarChart3 size={14} className="text-blue-400" /> Stats du jour
                    </h3>
                    <div className="grid grid-cols-2 gap-3">
                      {[
                        { label: 'Gâchées', value: productionBatches.filter(b => b.status === 'completed').length, color: 'text-green-400' },
                        { label: 'Volume total', value: `${productionBatches.filter(b => b.status === 'completed').reduce((a, b) => a + b.quantityProduced, 0).toFixed(0)} m³`, color: 'text-blue-400' },
                        { label: 'En cours', value: currentBatch ? 1 : 0, color: 'text-orange-400' },
                        { label: 'Abandonnées', value: productionBatches.filter(b => b.status === 'aborted').length, color: 'text-red-400' },
                      ].map((s, i) => (
                        <div key={i} className={cn('p-3 rounded-lg', isDark ? 'bg-slate-700' : 'bg-slate-50')}>
                          <div className={cn('text-2xl font-black', s.color)}>{s.value}</div>
                          <div className={cn('text-xs', isDark ? 'text-slate-400' : 'text-slate-500')}>{s.label}</div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Simulator toggle */}
                  {simulatorState.enabled && (
                    <div className={cn('rounded-xl border p-4 border-yellow-500/30 bg-yellow-500/10')}>
                      <div className="flex items-center gap-2 mb-3">
                        <div className="w-2 h-2 rounded-full bg-yellow-400 animate-pulse" />
                        <span className="text-xs font-bold text-yellow-400">MODE SIMULATEUR ACTIF</span>
                      </div>
                      <div className="space-y-2">
                        <div className="flex items-center justify-between">
                          <span className={cn('text-xs', isDark ? 'text-slate-300' : 'text-slate-700')}>Scénario auto</span>
                          <button
                            onClick={() => setSimulatorState({ autoScenario: !simulatorState.autoScenario })}
                            className={cn('px-3 py-1 rounded-lg text-xs font-bold transition-all',
                              simulatorState.autoScenario ? 'bg-green-500 text-white' : isDark ? 'bg-slate-700 text-slate-400' : 'bg-slate-200 text-slate-600'
                            )}
                          >
                            {simulatorState.autoScenario ? 'ON' : 'OFF'}
                          </button>
                        </div>
                        <div className="flex items-center justify-between">
                          <span className={cn('text-xs', isDark ? 'text-slate-300' : 'text-slate-700')}>Vitesse: x{simulatorState.speed}</span>
                          <input type="range" min="1" max="10" value={simulatorState.speed}
                            onChange={e => setSimulatorState({ speed: parseInt(e.target.value) })}
                            className="w-24"
                          />
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        ) : (
          /* HISTORY TAB */
          <div className="max-w-6xl mx-auto">
            <div className="flex items-center gap-3 mb-4">
              <div className="relative flex-1 max-w-md">
                <Search size={14} className={cn('absolute left-3 top-1/2 -translate-y-1/2', isDark ? 'text-slate-500' : 'text-slate-400')} />
                <input
                  type="text" value={search} onChange={e => setSearch(e.target.value)}
                  placeholder="Rechercher par recette, client, camion..."
                  className={cn('w-full pl-9 pr-4 py-2.5 rounded-lg border text-sm', isDark ? 'bg-slate-800 border-slate-700 text-white placeholder-slate-500' : 'bg-white border-slate-200 text-slate-900')}
                />
              </div>
              <span className={cn('text-xs', isDark ? 'text-slate-400' : 'text-slate-500')}>
                {filteredHistory.length} gâchées
              </span>
            </div>

            <div className={cn('rounded-xl border overflow-hidden', isDark ? 'bg-slate-800 border-slate-700' : 'bg-white border-slate-200')}>
              <table className="w-full text-sm">
                <thead className={cn('text-xs uppercase', isDark ? 'bg-slate-700 text-slate-400' : 'bg-slate-50 text-slate-500')}>
                  <tr>
                    <th className="px-4 py-3 text-left">N°</th>
                    <th className="px-4 py-3 text-left">Recette</th>
                    <th className="px-4 py-3 text-left">Client</th>
                    <th className="px-4 py-3 text-left">Camion</th>
                    <th className="px-4 py-3 text-left">Opérateur</th>
                    <th className="px-4 py-3 text-left">Date</th>
                    <th className="px-4 py-3 text-left">Durée</th>
                    <th className="px-4 py-3 text-left">Qté</th>
                    <th className="px-4 py-3 text-left">État</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredHistory.slice(0, 50).map((batch, i) => (
                    <tr key={batch.id} className={cn(
                      'border-t',
                      isDark ? 'border-slate-700 hover:bg-slate-700/50' : 'border-slate-100 hover:bg-slate-50'
                    )}>
                      <td className="px-4 py-3">
                        <span className="font-mono text-xs font-bold text-orange-400">{batch.batchNumber}</span>
                      </td>
                      <td className="px-4 py-3">
                        <span className={cn('font-medium', isDark ? 'text-white' : 'text-slate-900')}>{batch.recipeName}</span>
                      </td>
                      <td className="px-4 py-3">
                        <span className={isDark ? 'text-slate-300' : 'text-slate-600'}>{batch.clientName || '—'}</span>
                      </td>
                      <td className="px-4 py-3">
                        <span className="font-mono text-xs">{batch.truckPlate || '—'}</span>
                      </td>
                      <td className="px-4 py-3">
                        <span className={isDark ? 'text-slate-400' : 'text-slate-500'}>{batch.operatorName}</span>
                      </td>
                      <td className="px-4 py-3">
                        <span className={cn('text-xs', isDark ? 'text-slate-400' : 'text-slate-500')}>
                          {batch.startTime ? format(new Date(batch.startTime), 'dd/MM HH:mm') : '—'}
                        </span>
                      </td>
                      <td className="px-4 py-3">
                        <span className={cn('text-xs', isDark ? 'text-slate-400' : 'text-slate-500')}>
                          {batch.duration ? `${Math.floor(batch.duration / 60)}m${batch.duration % 60}s` : '—'}
                        </span>
                      </td>
                      <td className="px-4 py-3">
                        <span className="font-bold text-blue-400">{batch.quantityProduced || 0} m³</span>
                      </td>
                      <td className="px-4 py-3">
                        <StatusBadge status={batch.status} />
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
              {filteredHistory.length === 0 && (
                <div className={cn('text-center py-12', isDark ? 'text-slate-500' : 'text-slate-400')}>
                  <Factory size={32} className="mx-auto mb-2 opacity-30" />
                  Aucune gâchée trouvée
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

// ---- Current Batch Panel ----
const CurrentBatchPanel: React.FC<{
  batch: ProductionBatch; onStop: () => void; isDark: boolean; stepLabels: Record<string, string>
}> = ({ batch, onStop, isDark, stepLabels }) => {
  const steps = ['aggregate_weighing', 'cement_weighing', 'water_weighing', 'adjuvant_weighing', 'mixing', 'discharge', 'done'];
  const currentIndex = steps.indexOf(batch.currentStep);

  return (
    <div className={cn('rounded-xl border p-5 border-orange-500/40 bg-orange-500/5')}>
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-3">
          <div className="w-3 h-3 rounded-full bg-orange-400 animate-pulse" />
          <div>
            <div className="font-bold text-orange-400">{batch.batchNumber}</div>
            <div className={cn('text-xs', isDark ? 'text-slate-400' : 'text-slate-500')}>
              {batch.recipeName} · {batch.clientName || 'Client non défini'}
            </div>
          </div>
        </div>
        <button
          onClick={onStop}
          className="flex items-center gap-2 px-4 py-2 rounded-xl bg-red-500 hover:bg-red-600 text-white font-bold text-sm transition-all"
        >
          <Square size={14} /> Arrêter
        </button>
      </div>

      {/* Steps */}
      <div className="flex items-center gap-1 mb-4 overflow-x-auto pb-2">
        {steps.map((step, i) => (
          <React.Fragment key={step}>
            <div className={cn(
              'flex-shrink-0 px-2 py-1 rounded-lg text-xs font-medium whitespace-nowrap',
              i < currentIndex ? 'bg-green-500/20 text-green-400' :
              i === currentIndex ? 'bg-orange-500/20 text-orange-400 border border-orange-500/50' :
              isDark ? 'bg-slate-700 text-slate-500' : 'bg-slate-100 text-slate-400'
            )}>
              {i < currentIndex && '✓ '}
              {stepLabels[step] || step}
            </div>
            {i < steps.length - 1 && <ChevronRight size={12} className="flex-shrink-0 text-slate-500" />}
          </React.Fragment>
        ))}
      </div>

      {/* Progress */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {[
          { label: 'Agrégats', actual: batch.weightsActual.aggregates, target: batch.weightsTarget.aggregates, unit: 'kg' },
          { label: 'Ciment', actual: batch.weightsActual.cement, target: batch.weightsTarget.cement, unit: 'kg' },
          { label: 'Eau', actual: batch.weightsActual.water, target: batch.weightsTarget.water, unit: 'L' },
          { label: 'Adjuvant', actual: batch.weightsActual.adjuvant, target: batch.weightsTarget.adjuvant, unit: 'L' },
        ].map((w, i) => (
          <div key={i} className={cn('p-3 rounded-lg', isDark ? 'bg-slate-800' : 'bg-white')}>
            <div className={cn('text-xs mb-1', isDark ? 'text-slate-400' : 'text-slate-500')}>{w.label}</div>
            <div className="flex items-baseline gap-1">
              <span className="text-lg font-black text-orange-400">{w.actual.toFixed(1)}</span>
              <span className={cn('text-xs', isDark ? 'text-slate-400' : 'text-slate-500')}>/ {w.target} {w.unit}</span>
            </div>
            {w.target > 0 && (
              <div className={cn('h-1.5 rounded-full mt-1.5', isDark ? 'bg-slate-700' : 'bg-slate-200')}>
                <div
                  className="h-1.5 rounded-full bg-gradient-to-r from-orange-500 to-red-500 transition-all duration-500"
                  style={{ width: `${Math.min(100, (w.actual / w.target) * 100)}%` }}
                />
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

// ---- Status Badge ----
const StatusBadge: React.FC<{ status: string }> = ({ status }) => {
  const configs: Record<string, { label: string; class: string }> = {
    completed: { label: 'Terminé', class: 'bg-green-500/20 text-green-400' },
    running: { label: 'En cours', class: 'bg-orange-500/20 text-orange-400 animate-pulse' },
    aborted: { label: 'Abandonné', class: 'bg-red-500/20 text-red-400' },
    paused: { label: 'Pause', class: 'bg-yellow-500/20 text-yellow-400' },
    error: { label: 'Erreur', class: 'bg-red-500/20 text-red-400' },
    idle: { label: 'Attente', class: 'bg-slate-500/20 text-slate-400' },
  };
  const cfg = configs[status] || { label: status, class: 'bg-slate-500/20 text-slate-400' };
  return (
    <span className={cn('px-2 py-0.5 rounded-full text-xs font-medium', cfg.class)}>{cfg.label}</span>
  );
};

export default ProductionPage;
