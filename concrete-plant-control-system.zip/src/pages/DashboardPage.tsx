/**
 * BétonPro SCADA - Dashboard principal
 * Vue d'ensemble temps réel de la centrale
 */
import React, { useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useStore } from '../store';
import {
  Activity, AlertTriangle, CheckCircle, XCircle, Wifi, WifiOff,
  Factory, Gauge, Clock, TrendingUp, Zap, Thermometer, BarChart3,
  PlayCircle, StopCircle, Settings, RefreshCw, Shield
} from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar } from 'recharts';
import { cn } from '../utils/cn';
import { format } from 'date-fns';
import { fr } from 'date-fns/locale';

export const DashboardPage: React.FC = () => {
  const { t } = useTranslation();
  const { theme, realTimeState, alarms, productionBatches, currentBatch, plantConfig } = useStore();
  const isDark = theme === 'dark';

  const [time, setTime] = useState(new Date());
  const [productionChartData, setProductionChartData] = useState<any[]>([]);

  useEffect(() => {
    const timer = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  // Génération données graphique production
  useEffect(() => {
    const hours = Array.from({ length: 12 }, (_, i) => {
      const h = new Date();
      h.setHours(h.getHours() - (11 - i), 0, 0, 0);
      return {
        time: `${h.getHours()}h`,
        gachees: Math.floor(Math.random() * 5 + 1),
        volume: Math.floor(Math.random() * 40 + 10),
      };
    });
    setProductionChartData(hours);
  }, []);

  const activeAlarms = alarms.filter(a => a.active && !a.acknowledged);
  const criticalAlarms = activeAlarms.filter(a => a.priority === 'critical');
  const todayBatches = productionBatches.filter(b => {
    const today = new Date();
    const batchDate = b.startTime ? new Date(b.startTime) : null;
    return batchDate && batchDate.toDateString() === today.toDateString();
  });
  const todayVolume = todayBatches.reduce((acc, b) => acc + (b.quantityProduced || 0), 0);

  // Stats cards
  const stats = [
    {
      label: t('dashboard.todayProd'),
      value: `${todayBatches.length}`,
      unit: t('dashboard.batches'),
      icon: Factory,
      color: 'from-orange-500 to-red-500',
      iconColor: 'text-orange-400',
      bg: isDark ? 'bg-orange-500/10' : 'bg-orange-50',
      border: isDark ? 'border-orange-500/20' : 'border-orange-200',
    },
    {
      label: t('dashboard.totalVolume'),
      value: todayVolume.toFixed(1),
      unit: 'm³',
      icon: Gauge,
      color: 'from-blue-500 to-cyan-500',
      iconColor: 'text-blue-400',
      bg: isDark ? 'bg-blue-500/10' : 'bg-blue-50',
      border: isDark ? 'border-blue-500/20' : 'border-blue-200',
    },
    {
      label: t('dashboard.activeAlarms'),
      value: activeAlarms.length,
      unit: criticalAlarms.length > 0 ? `${criticalAlarms.length} critiques` : '',
      icon: AlertTriangle,
      color: criticalAlarms.length > 0 ? 'from-red-500 to-rose-500' : 'from-yellow-500 to-orange-500',
      iconColor: criticalAlarms.length > 0 ? 'text-red-400' : 'text-yellow-400',
      bg: isDark ? (criticalAlarms.length > 0 ? 'bg-red-500/10' : 'bg-yellow-500/10') : (criticalAlarms.length > 0 ? 'bg-red-50' : 'bg-yellow-50'),
      border: isDark ? (criticalAlarms.length > 0 ? 'border-red-500/20' : 'border-yellow-500/20') : (criticalAlarms.length > 0 ? 'border-red-200' : 'border-yellow-200'),
      pulse: criticalAlarms.length > 0,
    },
    {
      label: t('dashboard.cycleTime'),
      value: '8:24',
      unit: 'min/gâchée',
      icon: Clock,
      color: 'from-purple-500 to-violet-500',
      iconColor: 'text-purple-400',
      bg: isDark ? 'bg-purple-500/10' : 'bg-purple-50',
      border: isDark ? 'border-purple-500/20' : 'border-purple-200',
    },
  ];

  return (
    <div className={cn('p-4 space-y-4', isDark ? 'text-white' : 'text-slate-900')}>
      {/* Header row */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h2 className={cn('text-lg font-bold', isDark ? 'text-white' : 'text-slate-900')}>
            {plantConfig.plantName}
          </h2>
          <p className={cn('text-sm', isDark ? 'text-slate-400' : 'text-slate-500')}>
            {format(time, "EEEE dd MMMM yyyy · HH:mm:ss", { locale: fr })}
          </p>
        </div>
        <div className="flex items-center gap-2">
          <StatusBadge
            icon={realTimeState.simulatorMode ? Zap : Wifi}
            label={realTimeState.simulatorMode ? 'MODE SIMULATEUR' : realTimeState.plcConnected ? 'PLC CONNECTÉ' : 'PLC HORS LIGNE'}
            status={realTimeState.simulatorMode ? 'sim' : realTimeState.plcConnected ? 'ok' : 'error'}
            isDark={isDark}
          />
          <StatusBadge
            icon={realTimeState.modeAuto ? PlayCircle : Settings}
            label={realTimeState.modeAuto ? t('dashboard.modeAuto') : t('dashboard.modeManu')}
            status={realTimeState.modeAuto ? 'ok' : 'warning'}
            isDark={isDark}
          />
          {realTimeState.emergencyStop && (
            <StatusBadge icon={StopCircle} label="ARRÊT URGENCE" status="critical" isDark={isDark} pulse />
          )}
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {stats.map((stat, i) => {
          const Icon = stat.icon;
          return (
            <div
              key={i}
              className={cn(
                'rounded-xl p-4 border',
                stat.bg, stat.border,
                stat.pulse && 'animate-pulse',
              )}
            >
              <div className="flex items-start justify-between mb-3">
                <div>
                  <p className={cn('text-xs font-medium', isDark ? 'text-slate-400' : 'text-slate-500')}>{stat.label}</p>
                  <div className="flex items-baseline gap-1 mt-1">
                    <span className={cn('text-2xl font-black', isDark ? 'text-white' : 'text-slate-900')}>{stat.value}</span>
                    <span className={cn('text-xs', isDark ? 'text-slate-400' : 'text-slate-500')}>{stat.unit}</span>
                  </div>
                </div>
                <div className={cn('p-2 rounded-lg bg-gradient-to-br', stat.color)}>
                  <Icon size={18} className="text-white" />
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Main Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Production Chart */}
        <div className={cn('lg:col-span-2 rounded-xl p-4 border', isDark ? 'bg-slate-800 border-slate-700' : 'bg-white border-slate-200')}>
          <h3 className={cn('text-sm font-bold mb-4 flex items-center gap-2', isDark ? 'text-white' : 'text-slate-900')}>
            <TrendingUp size={16} className="text-orange-400" />
            Production des 12 dernières heures
          </h3>
          <ResponsiveContainer width="100%" height={180}>
            <AreaChart data={productionChartData} margin={{ top: 0, right: 0, left: -20, bottom: 0 }}>
              <defs>
                <linearGradient id="colorVolume" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#f97316" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#f97316" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke={isDark ? '#334155' : '#e2e8f0'} />
              <XAxis dataKey="time" tick={{ fill: isDark ? '#94a3b8' : '#64748b', fontSize: 11 }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fill: isDark ? '#94a3b8' : '#64748b', fontSize: 11 }} axisLine={false} tickLine={false} />
              <Tooltip contentStyle={{ backgroundColor: isDark ? '#1e293b' : '#fff', border: `1px solid ${isDark ? '#334155' : '#e2e8f0'}`, borderRadius: 8, color: isDark ? '#fff' : '#0f172a' }} />
              <Area type="monotone" dataKey="volume" stroke="#f97316" strokeWidth={2} fill="url(#colorVolume)" name="Volume m³" />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Equipment Status */}
        <div className={cn('rounded-xl p-4 border', isDark ? 'bg-slate-800 border-slate-700' : 'bg-white border-slate-200')}>
          <h3 className={cn('text-sm font-bold mb-4 flex items-center gap-2', isDark ? 'text-white' : 'text-slate-900')}>
            <Activity size={16} className="text-green-400" />
            État des équipements
          </h3>
          <div className="space-y-2">
            <EquipmentRow label="Malaxeur" status={realTimeState.mixer.running} current={realTimeState.mixer.current} isDark={isDark} />
            <EquipmentRow label="Convoyeur / Skip" status={realTimeState.conveyor.running || realTimeState.skip.motorRunning} isDark={isDark} />
            {realTimeState.waterTanks.map(w => (
              <EquipmentRow key={w.id} label={w.name} status={w.pumpRunning} level={w.level} isDark={isDark} />
            ))}
            {realTimeState.adjuvantTanks.map(a => (
              <EquipmentRow key={a.id} label={a.name} status={a.pumpRunning} level={a.level} isDark={isDark} />
            ))}
          </div>
        </div>
      </div>

      {/* Second row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Hoppers / Levels */}
        <div className={cn('rounded-xl p-4 border', isDark ? 'bg-slate-800 border-slate-700' : 'bg-white border-slate-200')}>
          <h3 className={cn('text-sm font-bold mb-4 flex items-center gap-2', isDark ? 'text-white' : 'text-slate-900')}>
            <Thermometer size={16} className="text-blue-400" />
            Niveaux trémies
          </h3>
          <div className="space-y-3">
            {realTimeState.hoppers.map(h => (
              <LevelBar key={h.id} label={h.name} level={h.level} isDark={isDark} />
            ))}
          </div>
        </div>

        {/* Silos */}
        <div className={cn('rounded-xl p-4 border', isDark ? 'bg-slate-800 border-slate-700' : 'bg-white border-slate-200')}>
          <h3 className={cn('text-sm font-bold mb-4 flex items-center gap-2', isDark ? 'text-white' : 'text-slate-900')}>
            <Factory size={16} className="text-purple-400" />
            Niveaux silos ciment
          </h3>
          <div className="space-y-3">
            {realTimeState.silos.map(s => (
              <LevelBar
                key={s.id} label={s.name} level={s.level} isDark={isDark}
                warning={s.levelLow} critical={s.level < 10}
              />
            ))}
          </div>
        </div>

        {/* Current Production / Alarms */}
        <div className="space-y-3">
          {/* Current Batch */}
          {currentBatch ? (
            <div className={cn('rounded-xl p-4 border border-orange-500/30 bg-orange-500/10')}>
              <h3 className="text-sm font-bold mb-3 flex items-center gap-2 text-orange-400">
                <RefreshCw size={14} className="animate-spin" />
                Production en cours
              </h3>
              <div className="space-y-2">
                <div className={cn('text-xs', isDark ? 'text-slate-300' : 'text-slate-700')}>
                  <span className="font-bold">{currentBatch.recipeName}</span>
                </div>
                <div className={cn('text-xs', isDark ? 'text-slate-400' : 'text-slate-500')}>
                  {currentBatch.clientName} · {currentBatch.truckPlate}
                </div>
                <div className={cn('text-xs font-medium', isDark ? 'text-slate-300' : 'text-slate-600')}>
                  Étape: <span className="text-orange-400">{currentBatch.currentStep.replace(/_/g, ' ')}</span>
                </div>
                <div className="w-full bg-slate-700 rounded-full h-2 mt-2">
                  <div
                    className="h-2 rounded-full bg-gradient-to-r from-orange-500 to-red-500 transition-all duration-500"
                    style={{ width: `${currentBatch.stepProgress}%` }}
                  />
                </div>
                <div className={cn('text-xs text-right', isDark ? 'text-slate-400' : 'text-slate-500')}>
                  {currentBatch.stepProgress.toFixed(0)}%
                </div>
              </div>
            </div>
          ) : (
            <div className={cn('rounded-xl p-4 border', isDark ? 'bg-slate-800 border-slate-700' : 'bg-white border-slate-200')}>
              <div className={cn('text-center py-4', isDark ? 'text-slate-500' : 'text-slate-400')}>
                <Factory size={32} className="mx-auto mb-2 opacity-30" />
                <p className="text-xs">Aucune production en cours</p>
              </div>
            </div>
          )}

          {/* Active Alarms */}
          <div className={cn('rounded-xl p-4 border', isDark ? 'bg-slate-800 border-slate-700' : 'bg-white border-slate-200')}>
            <h3 className={cn('text-sm font-bold mb-3 flex items-center gap-2', isDark ? 'text-white' : 'text-slate-900')}>
              <AlertTriangle size={14} className="text-red-400" />
              Alarmes récentes
            </h3>
            {activeAlarms.length === 0 ? (
              <div className="flex items-center gap-2 text-green-400 text-xs">
                <CheckCircle size={14} />
                Aucune alarme active
              </div>
            ) : (
              <div className="space-y-1.5">
                {activeAlarms.slice(0, 3).map(alarm => (
                  <div
                    key={alarm.id}
                    className={cn(
                      'flex items-start gap-2 text-xs p-2 rounded-lg',
                      alarm.priority === 'critical'
                        ? 'bg-red-500/10 border border-red-500/30 text-red-400'
                        : 'bg-yellow-500/10 border border-yellow-500/30 text-yellow-400'
                    )}
                  >
                    <AlertTriangle size={12} className="flex-shrink-0 mt-0.5" />
                    <span className="leading-tight">{alarm.message}</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Scales */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
        <ScaleCard
          label="Balance Agrégats"
          weight={realTimeState.aggregateScale.weight}
          setpoint={realTimeState.aggregateScale.setpoint}
          isDark={isDark}
        />
        <ScaleCard label="Balance Ciment" weight={0} setpoint={0} isDark={isDark} />
        <ScaleCard label="Compteur Eau / Adjuvant" weight={0} setpoint={0} isDark={isDark} />
      </div>
    </div>
  );
};

// ---- Sous-composants ----

const StatusBadge: React.FC<{
  icon: any; label: string; status: 'ok' | 'error' | 'warning' | 'sim' | 'critical'; isDark: boolean; pulse?: boolean
}> = ({ icon: Icon, label, status, isDark, pulse }) => {
  const colors = {
    ok: 'bg-green-500/20 text-green-400 border-green-500/30',
    error: 'bg-red-500/20 text-red-400 border-red-500/30',
    warning: 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30',
    sim: 'bg-yellow-500/20 text-yellow-300 border-yellow-500/30',
    critical: 'bg-red-500/30 text-red-300 border-red-400/50',
  };
  return (
    <div className={cn('flex items-center gap-1.5 px-2.5 py-1 rounded-full border text-xs font-semibold', colors[status], pulse && 'animate-pulse')}>
      <Icon size={12} />
      {label}
    </div>
  );
};

const EquipmentRow: React.FC<{
  label: string; status: boolean; current?: number; level?: number; isDark: boolean
}> = ({ label, status, current, level, isDark }) => (
  <div className="flex items-center gap-3">
    <div className={cn('w-2 h-2 rounded-full flex-shrink-0', status ? 'bg-green-400 animate-pulse' : 'bg-slate-500')} />
    <span className={cn('text-xs flex-1 truncate', isDark ? 'text-slate-300' : 'text-slate-600')}>{label}</span>
    {current !== undefined && current > 0 && (
      <span className="text-xs text-yellow-400">{current.toFixed(1)}A</span>
    )}
    {level !== undefined && (
      <span className={cn('text-xs', level < 20 ? 'text-red-400' : isDark ? 'text-slate-400' : 'text-slate-500')}>{level.toFixed(0)}%</span>
    )}
    <span className={cn('text-xs font-medium', status ? 'text-green-400' : isDark ? 'text-slate-500' : 'text-slate-400')}>
      {status ? 'RUN' : 'STOP'}
    </span>
  </div>
);

const LevelBar: React.FC<{
  label: string; level: number; isDark: boolean; warning?: boolean; critical?: boolean
}> = ({ label, level, isDark, warning, critical }) => (
  <div>
    <div className="flex items-center justify-between mb-1">
      <span className={cn('text-xs truncate max-w-[70%]', isDark ? 'text-slate-300' : 'text-slate-600')}>{label}</span>
      <span className={cn(
        'text-xs font-bold',
        critical ? 'text-red-400' : warning ? 'text-yellow-400' : isDark ? 'text-slate-300' : 'text-slate-600'
      )}>{level.toFixed(0)}%</span>
    </div>
    <div className={cn('h-1.5 rounded-full', isDark ? 'bg-slate-700' : 'bg-slate-200')}>
      <div
        className={cn(
          'h-1.5 rounded-full transition-all duration-1000',
          critical ? 'bg-red-500' : warning ? 'bg-yellow-500' : 'bg-gradient-to-r from-blue-500 to-cyan-400'
        )}
        style={{ width: `${Math.min(100, level)}%` }}
      />
    </div>
  </div>
);

const ScaleCard: React.FC<{
  label: string; weight: number; setpoint: number; isDark: boolean
}> = ({ label, weight, setpoint, isDark }) => (
  <div className={cn('rounded-xl p-4 border', isDark ? 'bg-slate-800 border-slate-700' : 'bg-white border-slate-200')}>
    <div className={cn('text-xs font-medium mb-2', isDark ? 'text-slate-400' : 'text-slate-500')}>{label}</div>
    <div className="flex items-baseline gap-2">
      <span className={cn('text-2xl font-black tabular-nums', isDark ? 'text-white' : 'text-slate-900')}>{weight.toFixed(1)}</span>
      <span className={cn('text-sm', isDark ? 'text-slate-400' : 'text-slate-500')}>kg</span>
      {setpoint > 0 && (
        <span className={cn('text-xs ml-auto', isDark ? 'text-slate-400' : 'text-slate-500')}>/ {setpoint} kg</span>
      )}
    </div>
    {setpoint > 0 && (
      <div className={cn('h-1.5 rounded-full mt-2', isDark ? 'bg-slate-700' : 'bg-slate-200')}>
        <div
          className="h-1.5 rounded-full bg-gradient-to-r from-orange-500 to-red-500 transition-all duration-500"
          style={{ width: `${Math.min(100, (weight / setpoint) * 100)}%` }}
        />
      </div>
    )}
  </div>
);

export default DashboardPage;
