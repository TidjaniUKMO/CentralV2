/**
 * BétonPro SCADA - Page Configuration Développeur
 * ACCÈS RESTREINT - Admin uniquement
 * Configuration matérielle centrale à béton
 */
import React, { useState } from 'react';
import { useStore } from '../store';
import { Plus, Trash2, Save, AlertTriangle, Eye, EyeOff, Settings, Cpu } from 'lucide-react';
import { cn } from '../utils/cn';
import type { Hopper, Silo, DischargeMode, SkipType } from '../types';

export const DeveloperPage: React.FC = () => {
  const { theme, plantConfig, setPlantConfig, addHopper, updateHopper, removeHopper, addSilo, updateSilo, removeSilo, developerPageEnabled, setDeveloperPageEnabled, auth } = useStore();
  const isDark = theme === 'dark';
  const [tab, setTab] = useState<'hoppers' | 'silos' | 'tanks' | 'io' | 'settings'>('hoppers');
  const [saved, setSaved] = useState(false);

  // Only admin can access this page
  if (auth.user?.role !== 'admin') {
    return (
      <div className={cn('flex flex-col items-center justify-center h-full', isDark ? 'text-white' : 'text-slate-900')}>
        <AlertTriangle size={48} className="text-red-400 mb-4" />
        <h2 className="text-xl font-bold mb-2">Accès refusé</h2>
        <p className={isDark ? 'text-slate-400' : 'text-slate-500'}>Cette page est réservée aux administrateurs</p>
      </div>
    );
  }

  const handleSave = () => {
    setPlantConfig({ ...plantConfig, updatedAt: new Date() });
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  const addNewHopper = () => {
    const idx = plantConfig.hoppers.length;
    addHopper({
      id: `h-${Date.now()}`,
      name: `Trémie ${idx + 1}`,
      index: idx,
      dischargeMode: 'piston',
      hasVibrator: false,
      modbusCoilOpen: idx * 2,
      modbusCoilClose: idx * 2 + 1,
      modbusSensorFull: idx,
      modbusSensorEmpty: idx + 10,
      active: true,
    });
  };

  const addNewSilo = () => {
    const idx = plantConfig.silos.length;
    addSilo({
      id: `s-${Date.now()}`,
      name: `Silo ${idx + 1}`,
      index: idx,
      capacity: 60000,
      modbusLevelLow: 8 + idx * 2,
      modbusLevelHigh: 9 + idx * 2,
      modbusDischarge: 8 + idx,
      active: true,
    });
  };

  const cardClass = cn('rounded-xl border p-4', isDark ? 'bg-slate-800 border-slate-700' : 'bg-white border-slate-200');

  return (
    <div className={cn('h-full flex flex-col', isDark ? 'bg-slate-900 text-white' : 'bg-slate-50 text-slate-900')}>
      {/* Warning banner */}
      <div className="flex items-center gap-3 px-4 py-2 bg-red-500/10 border-b border-red-500/30">
        <AlertTriangle size={16} className="text-red-400 flex-shrink-0" />
        <span className="text-xs text-red-400 font-bold">ACCÈS RESTREINT DÉVELOPPEUR — Modifications matérielles — Impact direct sur l'automate</span>
        <div className="ml-auto flex items-center gap-2">
          <span className="text-xs text-slate-400">Visible opérateurs:</span>
          <button onClick={() => setDeveloperPageEnabled(!developerPageEnabled)}
            className={cn('flex items-center gap-1 px-2 py-1 rounded text-xs font-bold', developerPageEnabled ? 'bg-green-500/20 text-green-400 border border-green-500/30' : 'bg-red-500/20 text-red-400 border border-red-500/30')}>
            {developerPageEnabled ? <Eye size={11} /> : <EyeOff size={11} />}
            {developerPageEnabled ? 'Visible' : 'Masqué'}
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className={cn('flex items-center gap-1 px-4 py-2 border-b', isDark ? 'border-slate-700' : 'border-slate-200')}>
        {([
          ['hoppers', '⚙️ Trémies'],
          ['silos', '🏭 Silos'],
          ['tanks', '💧 Réservoirs'],
          ['io', '🔌 E/S Modbus'],
          ['settings', '⚙️ Config'],
        ] as const).map(([id, label]) => (
          <button key={id} onClick={() => setTab(id)}
            className={cn('px-3 py-1.5 rounded-lg text-xs font-medium transition-colors',
              tab === id ? 'bg-orange-500 text-white' : isDark ? 'text-slate-400 hover:text-white hover:bg-slate-800' : 'text-slate-500 hover:bg-slate-100'
            )}>
            {label}
          </button>
        ))}
      </div>

      <div className="flex-1 overflow-auto p-4">
        {saved && (
          <div className="flex items-center gap-2 px-4 py-2 mb-3 rounded-lg bg-green-500/20 border border-green-500/40 text-green-400 text-sm">
            Configuration sauvegardée
          </div>
        )}

        {/* HOPPERS */}
        {tab === 'hoppers' && (
          <div className="space-y-3 max-w-4xl">
            <div className="flex items-center justify-between">
              <h3 className={cn('font-bold', isDark ? 'text-white' : 'text-slate-900')}>Trémies agrégats ({plantConfig.hoppers.length}/8 max)</h3>
              <button onClick={addNewHopper} disabled={plantConfig.hoppers.length >= 8}
                className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-orange-500 hover:bg-orange-600 disabled:opacity-50 text-white font-bold text-xs">
                <Plus size={12} /> Ajouter trémie
              </button>
            </div>

            {plantConfig.hoppers.map((hopper, i) => (
              <div key={hopper.id} className={cardClass}>
                <div className="flex items-center gap-4 flex-wrap">
                  <div className={cn('w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0', isDark ? 'bg-slate-700 text-white' : 'bg-slate-100 text-slate-700')}>
                    {i + 1}
                  </div>
                  <div className="flex-1 grid grid-cols-2 md:grid-cols-4 gap-3">
                    <div>
                      <label className="block text-xs text-slate-400 mb-1">Nom</label>
                      <input value={hopper.name} onChange={e => updateHopper(hopper.id, { name: e.target.value })}
                        className={cn('w-full px-2 py-1.5 rounded border text-xs', isDark ? 'bg-slate-700 border-slate-600 text-white' : 'bg-slate-50 border-slate-200')} />
                    </div>
                    <div>
                      <label className="block text-xs text-slate-400 mb-1">Mode déchargement</label>
                      <select value={hopper.dischargeMode} onChange={e => updateHopper(hopper.id, { dischargeMode: e.target.value as DischargeMode })}
                        className={cn('w-full px-2 py-1.5 rounded border text-xs', isDark ? 'bg-slate-700 border-slate-600 text-white' : 'bg-slate-50 border-slate-200')}>
                        <option value="piston">🔧 Vérin pneumatique</option>
                        <option value="conveyor">⚡ Tapis motorisé</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-xs text-slate-400 mb-1">Coil Modbus Ouv.</label>
                      <input type="number" value={hopper.modbusCoilOpen} onChange={e => updateHopper(hopper.id, { modbusCoilOpen: parseInt(e.target.value) })}
                        className={cn('w-full px-2 py-1.5 rounded border text-xs font-mono', isDark ? 'bg-slate-700 border-slate-600 text-white' : 'bg-slate-50 border-slate-200')} />
                    </div>
                    <div>
                      <label className="block text-xs text-slate-400 mb-1">Coil Modbus Ferm.</label>
                      <input type="number" value={hopper.modbusCoilClose} onChange={e => updateHopper(hopper.id, { modbusCoilClose: parseInt(e.target.value) })}
                        className={cn('w-full px-2 py-1.5 rounded border text-xs font-mono', isDark ? 'bg-slate-700 border-slate-600 text-white' : 'bg-slate-50 border-slate-200')} />
                    </div>
                  </div>
                  <div className="flex items-center gap-3 flex-shrink-0">
                    <label className="flex items-center gap-1.5 cursor-pointer">
                      <input type="checkbox" checked={hopper.hasVibrator} onChange={e => updateHopper(hopper.id, { hasVibrator: e.target.checked })}
                        className="rounded" />
                      <span className="text-xs text-slate-400">Vibreur</span>
                    </label>
                    <label className="flex items-center gap-1.5 cursor-pointer">
                      <input type="checkbox" checked={hopper.active} onChange={e => updateHopper(hopper.id, { active: e.target.checked })}
                        className="rounded" />
                      <span className="text-xs text-slate-400">Actif</span>
                    </label>
                    <button onClick={() => removeHopper(hopper.id)} className="p-1.5 rounded text-red-400 hover:bg-red-500/20">
                      <Trash2 size={13} />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* SILOS */}
        {tab === 'silos' && (
          <div className="space-y-3 max-w-4xl">
            <div className="flex items-center justify-between">
              <h3 className={cn('font-bold', isDark ? 'text-white' : 'text-slate-900')}>Silos ciment ({plantConfig.silos.length}/4 max)</h3>
              <button onClick={addNewSilo} disabled={plantConfig.silos.length >= 4}
                className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-orange-500 hover:bg-orange-600 disabled:opacity-50 text-white font-bold text-xs">
                <Plus size={12} /> Ajouter silo
              </button>
            </div>
            {plantConfig.silos.map((silo, i) => (
              <div key={silo.id} className={cardClass}>
                <div className="flex items-center gap-4 flex-wrap">
                  <div className={cn('w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0', isDark ? 'bg-slate-700 text-white' : 'bg-slate-100 text-slate-700')}>{i + 1}</div>
                  <div className="flex-1 grid grid-cols-2 md:grid-cols-4 gap-3">
                    <div>
                      <label className="block text-xs text-slate-400 mb-1">Nom</label>
                      <input value={silo.name} onChange={e => updateSilo(silo.id, { name: e.target.value })}
                        className={cn('w-full px-2 py-1.5 rounded border text-xs', isDark ? 'bg-slate-700 border-slate-600 text-white' : 'bg-slate-50 border-slate-200')} />
                    </div>
                    <div>
                      <label className="block text-xs text-slate-400 mb-1">Capacité (kg)</label>
                      <input type="number" value={silo.capacity} onChange={e => updateSilo(silo.id, { capacity: parseInt(e.target.value) })}
                        className={cn('w-full px-2 py-1.5 rounded border text-xs font-mono', isDark ? 'bg-slate-700 border-slate-600 text-white' : 'bg-slate-50 border-slate-200')} />
                    </div>
                    <div>
                      <label className="block text-xs text-slate-400 mb-1">DI Niveau Bas</label>
                      <input type="number" value={silo.modbusLevelLow} onChange={e => updateSilo(silo.id, { modbusLevelLow: parseInt(e.target.value) })}
                        className={cn('w-full px-2 py-1.5 rounded border text-xs font-mono', isDark ? 'bg-slate-700 border-slate-600 text-white' : 'bg-slate-50 border-slate-200')} />
                    </div>
                    <div>
                      <label className="block text-xs text-slate-400 mb-1">DO Décharge</label>
                      <input type="number" value={silo.modbusDischarge} onChange={e => updateSilo(silo.id, { modbusDischarge: parseInt(e.target.value) })}
                        className={cn('w-full px-2 py-1.5 rounded border text-xs font-mono', isDark ? 'bg-slate-700 border-slate-600 text-white' : 'bg-slate-50 border-slate-200')} />
                    </div>
                  </div>
                  <div className="flex items-center gap-3 flex-shrink-0">
                    <label className="flex items-center gap-1.5 cursor-pointer">
                      <input type="checkbox" checked={silo.active} onChange={e => updateSilo(silo.id, { active: e.target.checked })} className="rounded" />
                      <span className="text-xs text-slate-400">Actif</span>
                    </label>
                    <button onClick={() => removeSilo(silo.id)} className="p-1.5 rounded text-red-400 hover:bg-red-500/20"><Trash2 size={13} /></button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* TANKS */}
        {tab === 'tanks' && (
          <div className="space-y-4 max-w-4xl">
            <div className={cardClass}>
              <h4 className={cn('font-bold mb-3 flex items-center gap-2', isDark ? 'text-white' : 'text-slate-900')}>
                💧 Réservoirs Eau (2 max)
              </h4>
              {plantConfig.waterTanks.map((tank, i) => (
                <div key={tank.id} className={cn('mb-3 p-3 rounded-lg grid grid-cols-2 md:grid-cols-4 gap-3', isDark ? 'bg-slate-700' : 'bg-slate-50')}>
                  <div>
                    <label className="block text-xs text-slate-400 mb-1">Nom</label>
                    <input value={tank.name} onChange={e => setPlantConfig({ ...plantConfig, waterTanks: plantConfig.waterTanks.map((t, j) => j === i ? { ...t, name: e.target.value } : t) })}
                      className={cn('w-full px-2 py-1.5 rounded border text-xs', isDark ? 'bg-slate-800 border-slate-600 text-white' : 'bg-white border-slate-200')} />
                  </div>
                  <div>
                    <label className="block text-xs text-slate-400 mb-1">Capacité (L)</label>
                    <input type="number" value={tank.capacity} onChange={e => setPlantConfig({ ...plantConfig, waterTanks: plantConfig.waterTanks.map((t, j) => j === i ? { ...t, capacity: parseInt(e.target.value) } : t) })}
                      className={cn('w-full px-2 py-1.5 rounded border text-xs font-mono', isDark ? 'bg-slate-800 border-slate-600 text-white' : 'bg-white border-slate-200')} />
                  </div>
                  <div>
                    <label className="block text-xs text-slate-400 mb-1">HR Niveau</label>
                    <input type="number" value={tank.modbusLevel} onChange={e => setPlantConfig({ ...plantConfig, waterTanks: plantConfig.waterTanks.map((t, j) => j === i ? { ...t, modbusLevel: parseInt(e.target.value) } : t) })}
                      className={cn('w-full px-2 py-1.5 rounded border text-xs font-mono', isDark ? 'bg-slate-800 border-slate-600 text-white' : 'bg-white border-slate-200')} />
                  </div>
                  <div className="flex items-end">
                    <label className="flex items-center gap-1.5 cursor-pointer">
                      <input type="checkbox" checked={tank.active} onChange={e => setPlantConfig({ ...plantConfig, waterTanks: plantConfig.waterTanks.map((t, j) => j === i ? { ...t, active: e.target.checked } : t) })} />
                      <span className="text-xs text-slate-400">Actif</span>
                    </label>
                  </div>
                </div>
              ))}
            </div>

            <div className={cardClass}>
              <h4 className={cn('font-bold mb-3 flex items-center gap-2', isDark ? 'text-white' : 'text-slate-900')}>
                🧪 Réservoirs Adjuvant (2 max)
              </h4>
              {plantConfig.adjuvantTanks.map((tank, i) => (
                <div key={tank.id} className={cn('mb-3 p-3 rounded-lg grid grid-cols-2 md:grid-cols-4 gap-3', isDark ? 'bg-slate-700' : 'bg-slate-50')}>
                  <div>
                    <label className="block text-xs text-slate-400 mb-1">Nom</label>
                    <input value={tank.name} onChange={e => setPlantConfig({ ...plantConfig, adjuvantTanks: plantConfig.adjuvantTanks.map((t, j) => j === i ? { ...t, name: e.target.value } : t) })}
                      className={cn('w-full px-2 py-1.5 rounded border text-xs', isDark ? 'bg-slate-800 border-slate-600 text-white' : 'bg-white border-slate-200')} />
                  </div>
                  <div>
                    <label className="block text-xs text-slate-400 mb-1">Capacité (L)</label>
                    <input type="number" value={tank.capacity}
                      onChange={e => setPlantConfig({ ...plantConfig, adjuvantTanks: plantConfig.adjuvantTanks.map((t, j) => j === i ? { ...t, capacity: parseInt(e.target.value) } : t) })}
                      className={cn('w-full px-2 py-1.5 rounded border text-xs font-mono', isDark ? 'bg-slate-800 border-slate-600 text-white' : 'bg-white border-slate-200')} />
                  </div>
                  <div className="flex items-end">
                    <label className="flex items-center gap-1.5 cursor-pointer">
                      <input type="checkbox" checked={tank.active} onChange={e => setPlantConfig({ ...plantConfig, adjuvantTanks: plantConfig.adjuvantTanks.map((t, j) => j === i ? { ...t, active: e.target.checked } : t) })} />
                      <span className="text-xs text-slate-400">Actif</span>
                    </label>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* I/O MAPPING */}
        {tab === 'io' && (
          <div className="max-w-4xl space-y-4">
            <div className={cn('p-4 rounded-xl', isDark ? 'bg-blue-500/10 border border-blue-500/30 text-blue-300' : 'bg-blue-50 border border-blue-200 text-blue-700')}>
              <div className="flex items-center gap-2 font-bold mb-2"><Cpu size={14} /> SCHNEIDER TM200CE24R — Mapping E/S physiques</div>
              <p className="text-xs">L'automate dispose de 14 entrées numériques (I0.0 à I1.5) et 10 sorties relais (Q0.0 à Q0.9).</p>
            </div>
            <div className={cardClass}>
              <h4 className={cn('font-bold mb-3', isDark ? 'text-white' : 'text-slate-900')}>Sorties numériques (DO) — Coils Modbus</h4>
              <div className="overflow-x-auto">
                <table className="w-full text-xs">
                  <thead className={cn('text-slate-400', isDark ? 'bg-slate-700' : 'bg-slate-50')}>
                    <tr>
                      <th className="px-3 py-2 text-left">Adresse Modbus</th>
                      <th className="px-3 py-2 text-left">Bornier PLC</th>
                      <th className="px-3 py-2 text-left">Signal</th>
                      <th className="px-3 py-2 text-left">Équipement</th>
                    </tr>
                  </thead>
                  <tbody>
                    {[
                      ['0', 'Q0.0', 'Vérin T1 Ouverture', 'Trémie Sable 0/4'],
                      ['1', 'Q0.1', 'Vérin T1 Fermeture', 'Trémie Sable 0/4'],
                      ['2', 'Q0.2', 'Vérin T2 Ouverture', 'Trémie Gravier 4/8'],
                      ['3', 'Q0.3', 'Vérin T2 Fermeture', 'Trémie Gravier 4/8'],
                      ['4', 'Q0.4', 'Vérin T3 Ouverture', 'Trémie Gravier 8/16'],
                      ['5', 'Q0.5', 'Vérin T3 Fermeture', 'Trémie Gravier 8/16'],
                      ['8', 'Q0.6', 'Vis doseuse silo 1', 'Silo CEM I 52.5'],
                      ['9', 'Q0.7', 'Vis doseuse silo 2', 'Silo CEM II 32.5'],
                      ['10', 'Q0.8', 'Pompe eau', 'Réservoir Eau 1'],
                      ['12', 'Q0.9', 'Pompe adjuvant', 'Réservoir Adjuvant 1'],
                      ['20', 'Ext.1', 'Moteur Skip', 'Skip benne montante'],
                      ['21', 'Ext.2', 'Moteur Malaxeur', 'Malaxeur principal'],
                      ['22', 'Ext.3', 'Trappe Malaxeur', 'Vidange malaxeur'],
                    ].map(([addr, bornier, signal, equip]) => (
                      <tr key={addr} className={cn('border-t', isDark ? 'border-slate-700' : 'border-slate-100')}>
                        <td className="px-3 py-2 font-mono font-bold text-orange-400">{addr}</td>
                        <td className="px-3 py-2 font-mono text-green-400">{bornier}</td>
                        <td className="px-3 py-2">{signal}</td>
                        <td className="px-3 py-2 text-slate-400">{equip}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* SETTINGS */}
        {tab === 'settings' && (
          <div className="max-w-2xl space-y-4">
            <div className={cardClass}>
              <h4 className={cn('font-bold mb-4', isDark ? 'text-white' : 'text-slate-900')}>Paramètres généraux centrale</h4>
              <div className="space-y-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-400 mb-1 uppercase">Nom de la centrale</label>
                  <input value={plantConfig.plantName} onChange={e => setPlantConfig({ ...plantConfig, plantName: e.target.value })}
                    className={cn('w-full px-3 py-2 rounded-lg border text-sm', isDark ? 'bg-slate-700 border-slate-600 text-white' : 'bg-slate-50 border-slate-200')} />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-400 mb-1 uppercase">Type déchargement balance</label>
                  <select value={plantConfig.skipType} onChange={e => setPlantConfig({ ...plantConfig, skipType: e.target.value as SkipType })}
                    className={cn('w-full px-3 py-2 rounded-lg border text-sm', isDark ? 'bg-slate-700 border-slate-600 text-white' : 'bg-slate-50 border-slate-200')}>
                    <option value="skip">⬆ Skip (benne montante)</option>
                    <option value="inclined_conveyor">→ Tapis incliné</option>
                  </select>
                </div>
                {plantConfig.skipType === 'skip' && (
                  <div className="space-y-2 pl-3 border-l-2 border-orange-500">
                    {[
                      ['hasSkipBottomSensor', 'Capteur position basse'],
                      ['hasSkipTopSensor', 'Capteur position haute'],
                      ['hasSkipCableSensor', 'Détecteur rupture câble'],
                    ].map(([key, label]) => (
                      <label key={key} className="flex items-center gap-2 cursor-pointer">
                        <input type="checkbox" checked={(plantConfig as any)[key]} onChange={e => setPlantConfig({ ...plantConfig, [key]: e.target.checked })} />
                        <span className={cn('text-sm', isDark ? 'text-slate-300' : 'text-slate-700')}>{label}</span>
                      </label>
                    ))}
                  </div>
                )}
                {plantConfig.skipType === 'inclined_conveyor' && (
                  <div>
                    <label className="block text-xs font-semibold text-slate-400 mb-1 uppercase">Confirmation fin vidange</label>
                    <select value={plantConfig.dischargeConfirmation} onChange={e => setPlantConfig({ ...plantConfig, dischargeConfirmation: e.target.value as 'timer' | 'weight' })}
                      className={cn('w-full px-3 py-2 rounded-lg border text-sm', isDark ? 'bg-slate-700 border-slate-600 text-white' : 'bg-slate-50 border-slate-200')}>
                      <option value="timer">⏱ Temporisation</option>
                      <option value="weight">⚖ Retour à zéro balance</option>
                    </select>
                  </div>
                )}

                {/* Developer page visibility */}
                <div className={cn('p-3 rounded-lg', isDark ? 'bg-slate-700' : 'bg-slate-50')}>
                  <div className="flex items-center justify-between">
                    <div>
                      <div className={cn('text-sm font-medium', isDark ? 'text-white' : 'text-slate-900')}>Page développeur visible</div>
                      <div className={cn('text-xs', isDark ? 'text-slate-400' : 'text-slate-500')}>Si désactivé, la page dev est invisible pour tous les profils</div>
                    </div>
                    <button onClick={() => setDeveloperPageEnabled(!developerPageEnabled)}
                      className={cn('relative w-12 h-6 rounded-full transition-all', developerPageEnabled ? 'bg-orange-500' : isDark ? 'bg-slate-600' : 'bg-slate-300')}>
                      <span className={cn('absolute top-1 w-4 h-4 bg-white rounded-full shadow transition-all', developerPageEnabled ? 'left-7' : 'left-1')} />
                    </button>
                  </div>
                </div>
              </div>
            </div>

            <button onClick={handleSave} className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-orange-500 hover:bg-orange-600 text-white font-bold text-sm">
              <Save size={14} /> Enregistrer configuration
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default DeveloperPage;
