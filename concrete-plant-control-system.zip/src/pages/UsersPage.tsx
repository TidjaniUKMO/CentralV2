/**
 * BétonPro SCADA - Gestion Utilisateurs
 * Admin only - CRUD complet avec rôles et permissions
 */
import React, { useState } from 'react';
import { useStore } from '../store';
import { Plus, Edit, Trash2, Save, X, Shield, Eye, EyeOff, CheckCircle } from 'lucide-react';
import { cn } from '../utils/cn';
import { format } from 'date-fns';
import type { User, UserRole } from '../types';

export const UsersPage: React.FC = () => {
  const { theme, users, addUser, updateUser, deleteUser, auth } = useStore();
  const isDark = theme === 'dark';
  const [showForm, setShowForm] = useState(false);
  const [editId, setEditId] = useState<string | null>(null);
  const [confirmDelete, setConfirmDelete] = useState<string | null>(null);
  const [showPwd, setShowPwd] = useState(false);
  const [saved, setSaved] = useState(false);

  const defaultPerms = (role: UserRole) => {
    if (role === 'admin') return [
      { module: 'production', read: true, write: true, execute: true },
      { module: 'recipes', read: true, write: true, execute: true },
      { module: 'clients', read: true, write: true, execute: true },
      { module: 'parameters', read: true, write: true, execute: true },
      { module: 'users', read: true, write: true, execute: true },
      { module: 'developer', read: true, write: true, execute: true },
    ];
    if (role === 'operator') return [
      { module: 'production', read: true, write: true, execute: true },
      { module: 'recipes', read: true, write: false, execute: false },
      { module: 'clients', read: true, write: false, execute: false },
      { module: 'parameters', read: true, write: false, execute: false },
      { module: 'users', read: false, write: false, execute: false },
      { module: 'developer', read: false, write: false, execute: false },
    ];
    return [
      { module: 'production', read: true, write: false, execute: false },
      { module: 'recipes', read: true, write: true, execute: false },
      { module: 'clients', read: true, write: false, execute: false },
      { module: 'parameters', read: true, write: true, execute: true },
      { module: 'users', read: false, write: false, execute: false },
      { module: 'developer', read: true, write: false, execute: false },
    ];
  };

  const [form, setForm] = useState<Partial<User> & { password?: string }>({
    username: '', role: 'operator', email: '', active: true, password: '',
    permissions: defaultPerms('operator'),
  });

  const roleConfig = {
    admin: { label: 'Administrateur', color: 'text-red-400 bg-red-500/20', icon: '👑' },
    operator: { label: 'Opérateur', color: 'text-blue-400 bg-blue-500/20', icon: '🔵' },
    maintenance: { label: 'Maintenance', color: 'text-yellow-400 bg-yellow-500/20', icon: '🔧' },
  };

  const handleSave = () => {
    if (!form.username?.trim()) return;
    if (editId) {
      updateUser(editId, { ...form, passwordHash: form.password || users.find(u => u.id === editId)?.passwordHash });
    } else {
      if (!form.password?.trim()) return;
      addUser({
        ...form as User,
        id: `u-${Date.now()}`,
        passwordHash: form.password || 'password',
        createdAt: new Date(),
        permissions: form.permissions || defaultPerms(form.role as UserRole || 'operator'),
      });
    }
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
    setShowForm(false);
    setEditId(null);
    setForm({ username: '', role: 'operator', email: '', active: true, password: '', permissions: defaultPerms('operator') });
  };

  const handleEdit = (user: User) => {
    setForm({ ...user, password: '' });
    setEditId(user.id);
    setShowForm(true);
  };

  const handleDelete = (id: string) => {
    if (id === auth.user?.id) return; // Cannot delete self
    if (confirmDelete === id) {
      deleteUser(id);
      setConfirmDelete(null);
    } else {
      setConfirmDelete(id);
      setTimeout(() => setConfirmDelete(null), 3000);
    }
  };

  const modules = ['production', 'recipes', 'clients', 'parameters', 'users', 'developer'];

  return (
    <div className={cn('h-full flex flex-col', isDark ? 'bg-slate-900 text-white' : 'bg-slate-50 text-slate-900')}>
      {/* Toolbar */}
      <div className={cn('flex items-center justify-between px-4 py-3 border-b', isDark ? 'border-slate-700' : 'border-slate-200')}>
        <div className="flex items-center gap-3">
          <Shield size={18} className="text-orange-400" />
          <span className={cn('font-bold', isDark ? 'text-white' : 'text-slate-900')}>Gestion Utilisateurs</span>
          <span className={cn('text-xs px-2 py-0.5 rounded-full', isDark ? 'bg-slate-700 text-slate-400' : 'bg-slate-100 text-slate-500')}>{users.length} utilisateurs</span>
        </div>
        <button
          onClick={() => { setShowForm(true); setEditId(null); setForm({ username: '', role: 'operator', email: '', active: true, password: '', permissions: defaultPerms('operator') }); }}
          className="flex items-center gap-2 px-3 py-2 rounded-lg bg-orange-500 hover:bg-orange-600 text-white font-bold text-sm"
        >
          <Plus size={13} /> Nouvel utilisateur
        </button>
      </div>

      <div className="flex-1 overflow-auto p-4 space-y-4">
        {saved && (
          <div className="flex items-center gap-2 px-4 py-2 rounded-lg bg-green-500/20 border border-green-500/40 text-green-400 text-sm">
            <CheckCircle size={14} /> Utilisateur enregistré
          </div>
        )}

        {/* FORM */}
        {showForm && (
          <div className={cn('rounded-xl border p-5', isDark ? 'bg-slate-800 border-slate-700' : 'bg-white border-slate-200')}>
            <div className="flex items-center justify-between mb-4">
              <h3 className={cn('font-bold', isDark ? 'text-white' : 'text-slate-900')}>
                {editId ? '✏️ Modifier' : '➕ Nouvel'} utilisateur
              </h3>
              <button onClick={() => { setShowForm(false); setEditId(null); }} className={cn('p-1 rounded', isDark ? 'text-slate-400 hover:text-white' : 'text-slate-500')}>
                <X size={16} />
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-3">
                <div>
                  <label className={cn('block text-xs font-semibold mb-1 uppercase', isDark ? 'text-slate-400' : 'text-slate-500')}>Nom d'utilisateur *</label>
                  <input value={form.username || ''} onChange={e => setForm(f => ({ ...f, username: e.target.value }))}
                    className={cn('w-full px-3 py-2 rounded-lg border text-sm', isDark ? 'bg-slate-700 border-slate-600 text-white' : 'bg-slate-50 border-slate-200')} />
                </div>
                <div>
                  <label className={cn('block text-xs font-semibold mb-1 uppercase', isDark ? 'text-slate-400' : 'text-slate-500')}>Email</label>
                  <input type="email" value={form.email || ''} onChange={e => setForm(f => ({ ...f, email: e.target.value }))}
                    className={cn('w-full px-3 py-2 rounded-lg border text-sm', isDark ? 'bg-slate-700 border-slate-600 text-white' : 'bg-slate-50 border-slate-200')} />
                </div>
                <div>
                  <label className={cn('block text-xs font-semibold mb-1 uppercase', isDark ? 'text-slate-400' : 'text-slate-500')}>Rôle *</label>
                  <select value={form.role || 'operator'} onChange={e => setForm(f => ({ ...f, role: e.target.value as UserRole, permissions: defaultPerms(e.target.value as UserRole) }))}
                    className={cn('w-full px-3 py-2 rounded-lg border text-sm', isDark ? 'bg-slate-700 border-slate-600 text-white' : 'bg-slate-50 border-slate-200')}>
                    <option value="admin">👑 Administrateur</option>
                    <option value="operator">🔵 Opérateur</option>
                    <option value="maintenance">🔧 Maintenance</option>
                  </select>
                </div>
                <div>
                  <label className={cn('block text-xs font-semibold mb-1 uppercase', isDark ? 'text-slate-400' : 'text-slate-500')}>
                    Mot de passe {editId ? '(laisser vide = inchangé)' : '*'}
                  </label>
                  <div className="relative">
                    <input
                      type={showPwd ? 'text' : 'password'}
                      value={form.password || ''}
                      onChange={e => setForm(f => ({ ...f, password: e.target.value }))}
                      className={cn('w-full px-3 py-2 pr-10 rounded-lg border text-sm', isDark ? 'bg-slate-700 border-slate-600 text-white' : 'bg-slate-50 border-slate-200')}
                    />
                    <button type="button" onClick={() => setShowPwd(s => !s)} className={cn('absolute right-2.5 top-1/2 -translate-y-1/2', isDark ? 'text-slate-400' : 'text-slate-500')}>
                      {showPwd ? <EyeOff size={14} /> : <Eye size={14} />}
                    </button>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <button onClick={() => setForm(f => ({ ...f, active: !f.active }))}
                    className={cn('relative w-10 h-5 rounded-full transition-all', form.active ? 'bg-green-500' : isDark ? 'bg-slate-600' : 'bg-slate-300')}>
                    <span className={cn('absolute top-0.5 w-4 h-4 bg-white rounded-full shadow transition-all', form.active ? 'left-5' : 'left-0.5')} />
                  </button>
                  <span className={cn('text-sm', isDark ? 'text-slate-300' : 'text-slate-700')}>Compte actif</span>
                </div>
              </div>

              {/* Permissions */}
              <div>
                <label className={cn('block text-xs font-semibold mb-2 uppercase', isDark ? 'text-slate-400' : 'text-slate-500')}>Permissions</label>
                <div className="space-y-1">
                  <div className={cn('grid grid-cols-4 gap-1 text-xs font-bold mb-1', isDark ? 'text-slate-400' : 'text-slate-500')}>
                    <span>Module</span><span className="text-center">Lecture</span><span className="text-center">Écriture</span><span className="text-center">Exécution</span>
                  </div>
                  {modules.map(mod => {
                    const perm = (form.permissions || []).find(p => p.module === mod) || { module: mod, read: false, write: false, execute: false };
                    const toggle = (key: 'read' | 'write' | 'execute') => {
                      const newPerms = [...(form.permissions || [])];
                      const idx = newPerms.findIndex(p => p.module === mod);
                      if (idx >= 0) newPerms[idx] = { ...newPerms[idx], [key]: !newPerms[idx][key] };
                      else newPerms.push({ ...perm, [key]: true });
                      setForm(f => ({ ...f, permissions: newPerms }));
                    };
                    return (
                      <div key={mod} className={cn('grid grid-cols-4 gap-1 items-center p-1.5 rounded-lg', isDark ? 'bg-slate-700' : 'bg-slate-50')}>
                        <span className={cn('text-xs capitalize', isDark ? 'text-slate-300' : 'text-slate-700')}>{mod}</span>
                        {(['read', 'write', 'execute'] as const).map(key => (
                          <div key={key} className="flex justify-center">
                            <button
                              onClick={() => toggle(key)}
                              className={cn('w-5 h-5 rounded flex items-center justify-center transition-all', perm[key] ? 'bg-green-500' : isDark ? 'bg-slate-600 hover:bg-slate-500' : 'bg-slate-200 hover:bg-slate-300')}
                            >
                              {perm[key] && <CheckCircle size={11} className="text-white" />}
                            </button>
                          </div>
                        ))}
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>

            <div className="flex items-center gap-3 mt-4 pt-4 border-t border-slate-700">
              <button onClick={handleSave} className="flex items-center gap-2 px-4 py-2 rounded-lg bg-green-500 hover:bg-green-600 text-white font-bold text-sm">
                <Save size={13} /> Enregistrer
              </button>
              <button onClick={() => { setShowForm(false); setEditId(null); }} className={cn('px-3 py-2 rounded-lg text-sm', isDark ? 'bg-slate-700 text-slate-300' : 'bg-slate-100 text-slate-600')}>
                Annuler
              </button>
            </div>
          </div>
        )}

        {/* Users list */}
        <div className={cn('rounded-xl border overflow-hidden', isDark ? 'bg-slate-800 border-slate-700' : 'bg-white border-slate-200')}>
          <table className="w-full text-sm">
            <thead className={cn('text-xs uppercase', isDark ? 'bg-slate-700 text-slate-400' : 'bg-slate-50 text-slate-500')}>
              <tr>
                <th className="px-4 py-3 text-left">Utilisateur</th>
                <th className="px-4 py-3 text-left">Rôle</th>
                <th className="px-4 py-3 text-left">Email</th>
                <th className="px-4 py-3 text-center">État</th>
                <th className="px-4 py-3 text-left">Dernière connexion</th>
                <th className="px-4 py-3 text-center">Actions</th>
              </tr>
            </thead>
            <tbody>
              {users.map(user => {
                const role = roleConfig[user.role];
                const isSelf = user.id === auth.user?.id;
                return (
                  <tr key={user.id} className={cn('border-t', isDark ? 'border-slate-700 hover:bg-slate-700/40' : 'border-slate-100 hover:bg-slate-50', isSelf && 'ring-1 ring-inset ring-orange-500/30')}>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2">
                        <div className="w-8 h-8 rounded-full bg-gradient-to-br from-slate-600 to-slate-700 flex items-center justify-center text-white text-xs font-bold flex-shrink-0">
                          {user.username[0].toUpperCase()}
                        </div>
                        <div>
                          <div className={cn('font-medium', isDark ? 'text-white' : 'text-slate-900')}>
                            {user.username} {isSelf && <span className="text-xs text-orange-400 ml-1">(vous)</span>}
                          </div>
                          <div className="text-xs font-mono text-slate-500">{user.id}</div>
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <span className={cn('px-2 py-0.5 rounded-full text-xs font-medium', role.color)}>
                        {role.icon} {role.label}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-slate-400 text-xs">{user.email || '—'}</td>
                    <td className="px-4 py-3 text-center">
                      <span className={cn('inline-flex w-2 h-2 rounded-full', user.active ? 'bg-green-400' : 'bg-red-400')} />
                    </td>
                    <td className="px-4 py-3 text-xs text-slate-400">
                      {user.lastLogin ? format(new Date(user.lastLogin), 'dd/MM HH:mm') : '—'}
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center justify-center gap-1">
                        <button onClick={() => handleEdit(user)} className="p-1.5 rounded text-blue-400 hover:bg-blue-500/20"><Edit size={13} /></button>
                        {!isSelf && (
                          <button onClick={() => handleDelete(user.id)} className={cn('p-1.5 rounded transition-colors', confirmDelete === user.id ? 'bg-red-500 text-white' : 'text-red-400 hover:bg-red-500/20')}>
                            <Trash2 size={13} />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default UsersPage;
