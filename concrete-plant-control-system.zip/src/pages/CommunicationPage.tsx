/**
 * BétonPro SCADA - Communication Modbus TCP
 * Monitoring connexion PLC, mapping E/S, journal erreurs
 */
import React, { useState, useEffect } from 'react';
import { useStore } from '../store';
import { Wifi, WifiOff, RefreshCw, AlertTriangle, CheckCircle, Activity, Server, Clock } from 'lucide-react';
import { cn } from '../utils/cn';
import { format } from 'date-fns';
import type { ModbusConfig } from '../types';

// Modbus tags par défaut pour centrale à béton
const defaultTags = [
  // COILS (Sorties numériques -> PLC)
  { id: 'c0', name: 'Trémie 1 Ouverture', address: 0, type: 'coil', description: 'Commande vérin T1 ouverture', unit: '', value: false, quality: 'bad' },
  { id: 'c1', name: 'Trémie 1 Fermeture', address: 1, type: 'coil', description: 'Commande vérin T1 fermeture', unit: '', value: false, quality: 'bad' },
  { id: 'c2', name: 'Trémie 2 Ouverture', address: 2, type: 'coil', description: 'Commande vérin T2 ouverture', unit: '', value: false, quality: 'bad' },
  { id: 'c3', name: 'Trémie 2 Fermeture', address: 3, type: 'coil', description: 'Commande vérin T2 fermeture', unit: '', value: false, quality: 'bad' },
  { id: 'c4', name: 'Trémie 3 Ouverture', address: 4, type: 'coil', description: 'Commande vérin T3 ouverture', unit: '', value: false, quality: 'bad' },
  { id: 'c5', name: 'Trémie 3 Fermeture', address: 5, type: 'coil', description: 'Commande vérin T3 fermeture', unit: '', value: false, quality: 'bad' },
  { id: 'c8', name: 'Silo 1 Décharge', address: 8, type: 'coil', description: 'Vis doseuse silo 1', unit: '', value: false, quality: 'bad' },
  { id: 'c9', name: 'Silo 2 Décharge', address: 9, type: 'coil', description: 'Vis doseuse silo 2', unit: '', value: false, quality: 'bad' },
  { id: 'c10', name: 'Pompe Eau 1', address: 10, type: 'coil', description: 'Commande pompe eau 1', unit: '', value: false, quality: 'bad' },
  { id: 'c12', name: 'Pompe Adjuvant 1', address: 12, type: 'coil', description: 'Commande pompe adjuvant 1', unit: '', value: false, quality: 'bad' },
  { id: 'c20', name: 'Moteur Skip', address: 20, type: 'coil', description: 'Démarrage moteur skip', unit: '', value: false, quality: 'bad' },
  { id: 'c21', name: 'Moteur Malaxeur', address: 21, type: 'coil', description: 'Démarrage moteur malaxeur', unit: '', value: false, quality: 'bad' },
  { id: 'c22', name: 'Trappe Malaxeur', address: 22, type: 'coil', description: 'Ouverture trappe vidange', unit: '', value: false, quality: 'bad' },
  { id: 'c30', name: 'Mode AUTO', address: 30, type: 'coil', description: 'Sélection mode automatique', unit: '', value: false, quality: 'bad' },
  // HOLDING REGISTERS (Mesures analogiques)
  { id: 'r100', name: 'Poids Balance Agrégats', address: 100, type: 'holding_register', description: 'Poids cumulatif balance agrégats', unit: 'kg', value: 0, scale: 0.1, quality: 'bad' },
  { id: 'r101', name: 'Consigne Balance Agrégats', address: 101, type: 'holding_register', description: 'Consigne poids agrégats', unit: 'kg', value: 0, scale: 0.1, quality: 'bad' },
  { id: 'r102', name: 'Courant Moteur Malaxeur', address: 102, type: 'holding_register', description: 'Mesure courant phase moteur malaxeur', unit: 'A', value: 0, scale: 0.1, quality: 'bad' },
  { id: 'r103', name: 'Niveau Réservoir Eau 1', address: 103, type: 'holding_register', description: 'Niveau % réservoir eau 1', unit: '%', value: 0, quality: 'bad' },
  { id: 'r104', name: 'Volume Eau Compteur', address: 104, type: 'holding_register', description: 'Volume eau dosé en cours', unit: 'L', value: 0, scale: 0.1, quality: 'bad' },
  { id: 'r110', name: 'Temps Cycle', address: 110, type: 'holding_register', description: 'Durée gâchée en cours', unit: 's', value: 0, quality: 'bad' },
  { id: 'r120', name: 'Etat Séquence', address: 120, type: 'holding_register', description: 'Etat machine d\'état automate (0-7)', unit: '', value: 0, quality: 'bad' },
  { id: 'r121', name: 'Code Alarme Active', address: 121, type: 'holding_register', description: 'Dernier code alarme actif', unit: '', value: 0, quality: 'bad' },
];

export const CommunicationPage: React.FC = () => {
  const { theme, modbusConfig, setModbusConfig, modbusStatus, addModbusError } = useStore();
  const isDark = theme === 'dark';

  const [config, setConfig] = useState<ModbusConfig>({ ...modbusConfig });
  const [tab, setTab] = useState<'status' | 'config' | 'mapping' | 'log'>('status');
  const [scanning, setScanning] = useState(false);
  const [tags] = useState(defaultTags);
  const [saved, setSaved] = useState(false);
  const [latencyHistory] = useState<number[]>(Array.from({ length: 20 }, () => Math.random() * 50 + 10));

  const handleSave = () => {
    setModbusConfig(config);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  const handleTestConnection = () => {
    setScanning(true);
    setTimeout(() => {
      setScanning(false);
      addModbusError({
        timestamp: new Date(),
        code: 'ECONNREFUSED',
        message: `Connexion refusée vers ${config.ip}:${config.port} — Mode simulateur actif`,
        address: undefined,
      });
    }, 2000);
  };

  const cardClass = cn('rounded-xl border', isDark ? 'bg-slate-800 border-slate-700' : 'bg-white border-slate-200');

  return (
    <div className={cn('h-full flex flex-col', isDark ? 'bg-slate-900 text-white' : 'bg-slate-50 text-slate-900')}>
      {/* Tabs */}
      <div className={cn('flex items-center gap-1 px-4 py-3 border-b', isDark ? 'border-slate-700' : 'border-slate-200')}>
        {([
          ['status', '🔌 État'],
          ['config', '⚙️ Configuration'],
          ['mapping', '🗺️ Mapping'],
          ['log', '📋 Journal'],
        ] as const).map(([id, label]) => (
          <button key={id} onClick={() => setTab(id)}
            className={cn('px-3 py-1.5 rounded-lg text-sm font-medium transition-colors',
              tab === id ? 'bg-orange-500 text-white' : isDark ? 'text-slate-400 hover:text-white hover:bg-slate-800' : 'text-slate-500 hover:bg-slate-100'
            )}>
            {label}
          </button>
        ))}
      </div>

      <div className="flex-1 overflow-auto p-4">
        {/* STATUS TAB */}
        {tab === 'status' && (
          <div className="max-w-4xl mx-auto space-y-4">
            {/* Connection status */}
            <div className={cn(cardClass, 'p-5')}>
              <div className="flex items-center gap-4">
                <div className={cn('w-16 h-16 rounded-xl flex items-center justify-center', modbusStatus.connected ? 'bg-green-500/20' : 'bg-red-500/20')}>
                  {modbusStatus.connected ? <Wifi size={32} className="text-green-400" /> : <WifiOff size={32} className="text-red-400" />}
                </div>
                <div>
                  <div className={cn('text-xl font-black', modbusStatus.connected ? 'text-green-400' : 'text-red-400')}>
                    {modbusStatus.connected ? 'CONNECTÉ' : 'DÉCONNECTÉ'}
                  </div>
                  <div className={cn('text-sm', isDark ? 'text-slate-400' : 'text-slate-500')}>
                    {config.ip}:{config.port} · Unit ID: {config.unitId} · Mode Simulateur
                  </div>
                  {modbusStatus.lastConnected && (
                    <div className="text-xs text-slate-500 mt-0.5">
                      Dernière connexion: {format(new Date(modbusStatus.lastConnected), 'dd/MM/yyyy HH:mm:ss')}
                    </div>
                  )}
                </div>
                <button
                  onClick={handleTestConnection}
                  disabled={scanning}
                  className={cn('ml-auto flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-bold transition-all',
                    scanning ? 'bg-slate-700 text-slate-400' : 'bg-orange-500 hover:bg-orange-600 text-white'
                  )}
                >
                  <RefreshCw size={14} className={scanning ? 'animate-spin' : ''} />
                  {scanning ? 'Test...' : 'Tester'}
                </button>
              </div>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              {[
                { label: 'Erreurs comm.', value: modbusStatus.errorCount, color: 'text-red-400', bg: 'bg-red-500/10 border-red-500/20' },
                { label: 'Paquets envoyés', value: modbusStatus.packetsSent, color: 'text-blue-400', bg: 'bg-blue-500/10 border-blue-500/20' },
                { label: 'Paquets reçus', value: modbusStatus.packetsReceived, color: 'text-green-400', bg: 'bg-green-500/10 border-green-500/20' },
                { label: 'Latence (ms)', value: modbusStatus.latency, color: 'text-yellow-400', bg: 'bg-yellow-500/10 border-yellow-500/20' },
              ].map((s, i) => (
                <div key={i} className={cn('p-4 rounded-xl border', s.bg)}>
                  <div className={cn('text-2xl font-black', s.color)}>{s.value}</div>
                  <div className={cn('text-xs mt-1', isDark ? 'text-slate-400' : 'text-slate-500')}>{s.label}</div>
                </div>
              ))}
            </div>

            {/* Watchdog */}
            <div className={cn(cardClass, 'p-4')}>
              <h3 className={cn('text-sm font-bold mb-3 flex items-center gap-2', isDark ? 'text-white' : 'text-slate-900')}>
                <Activity size={14} className="text-green-400" /> Watchdog Communication
              </h3>
              <div className="grid grid-cols-3 gap-3 text-xs">
                <div className={cn('p-3 rounded-lg', isDark ? 'bg-slate-700' : 'bg-slate-50')}>
                  <div className={isDark ? 'text-slate-400' : 'text-slate-500'}>Timeout</div>
                  <div className={cn('font-bold text-base', isDark ? 'text-white' : 'text-slate-900')}>{config.timeout} ms</div>
                </div>
                <div className={cn('p-3 rounded-lg', isDark ? 'bg-slate-700' : 'bg-slate-50')}>
                  <div className={isDark ? 'text-slate-400' : 'text-slate-500'}>Refresh rate</div>
                  <div className={cn('font-bold text-base', isDark ? 'text-white' : 'text-slate-900')}>{config.refreshRate} ms</div>
                </div>
                <div className={cn('p-3 rounded-lg', isDark ? 'bg-slate-700' : 'bg-slate-50')}>
                  <div className={isDark ? 'text-slate-400' : 'text-slate-500'}>Max retries</div>
                  <div className={cn('font-bold text-base', isDark ? 'text-white' : 'text-slate-900')}>{config.maxRetries}</div>
                </div>
              </div>
            </div>

            {/* PLC Info */}
            <div className={cn(cardClass, 'p-4')}>
              <h3 className={cn('text-sm font-bold mb-3 flex items-center gap-2', isDark ? 'text-white' : 'text-slate-900')}>
                <Server size={14} className="text-blue-400" /> Informations Automate
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-xs">
                {[
                  ['Modèle', 'SCHNEIDER TM200CE24R'],
                  ['Protocole', 'Modbus TCP/IP'],
                  ['Port standard', '502'],
                  ['Entrées numériques', '14 DI'],
                  ['Sorties numériques', '10 DO relais'],
                  ['Programme', 'Ladder Diagram (LD)'],
                  ['Version firmware', 'v4.0.0.8'],
                  ['Standard', 'IEC 61131-3'],
                ].map(([k, v]) => (
                  <div key={k} className={cn('flex justify-between p-2 rounded', isDark ? 'bg-slate-700' : 'bg-slate-50')}>
                    <span className={isDark ? 'text-slate-400' : 'text-slate-500'}>{k}</span>
                    <span className={cn('font-medium', isDark ? 'text-white' : 'text-slate-900')}>{v}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* CONFIG TAB */}
        {tab === 'config' && (
          <div className="max-w-lg mx-auto space-y-4">
            {saved && (
              <div className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-green-500/20 border border-green-500/40 text-green-400 text-sm">
                <CheckCircle size={14} /> Configuration sauvegardée
              </div>
            )}
            <div className={cn(cardClass, 'p-5')}>
              <h3 className={cn('text-base font-bold mb-4', isDark ? 'text-white' : 'text-slate-900')}>Configuration Modbus TCP</h3>
              <div className="space-y-3">
                {[
                  { label: 'Adresse IP automate', key: 'ip', type: 'text', placeholder: '192.168.1.100' },
                  { label: 'Port Modbus', key: 'port', type: 'number', min: 1, max: 65535, placeholder: '502' },
                  { label: 'Unit ID (esclave)', key: 'unitId', type: 'number', min: 1, max: 247, placeholder: '1' },
                  { label: 'Timeout connexion (ms)', key: 'timeout', type: 'number', min: 500, max: 30000, placeholder: '3000' },
                  { label: 'Taux rafraîchissement (ms)', key: 'refreshRate', type: 'number', min: 100, max: 10000, placeholder: '200' },
                  { label: 'Délai reconnexion (ms)', key: 'reconnectDelay', type: 'number', min: 1000, max: 60000, placeholder: '5000' },
                  { label: 'Tentatives max reconnexion', key: 'maxRetries', type: 'number', min: 1, max: 10, placeholder: '3' },
                ].map(field => (
                  <div key={field.key}>
                    <label className={cn('block text-xs font-semibold mb-1 uppercase', isDark ? 'text-slate-400' : 'text-slate-500')}>{field.label}</label>
                    <input
                      type={field.type}
                      value={(config as any)[field.key]}
                      onChange={e => setConfig(c => ({ ...c, [field.key]: field.type === 'number' ? parseInt(e.target.value) || 0 : e.target.value }))}
                      placeholder={field.placeholder}
                      className={cn('w-full px-3 py-2.5 rounded-lg border text-sm font-mono', isDark ? 'bg-slate-700 border-slate-600 text-white' : 'bg-slate-50 border-slate-200 text-slate-900')}
                    />
                  </div>
                ))}
                <button onClick={handleSave} className="w-full py-2.5 rounded-xl bg-orange-500 hover:bg-orange-600 text-white font-bold text-sm flex items-center justify-center gap-2 mt-2">
                  Enregistrer configuration
                </button>
                <button onClick={handleTestConnection} disabled={scanning}
                  className={cn('w-full py-2.5 rounded-xl text-sm font-medium flex items-center justify-center gap-2 transition-all',
                    scanning ? 'bg-slate-600 text-slate-400' : isDark ? 'bg-slate-700 text-slate-300 hover:bg-slate-600' : 'bg-slate-200 text-slate-600 hover:bg-slate-300'
                  )}>
                  <RefreshCw size={13} className={scanning ? 'animate-spin' : ''} /> {scanning ? 'Test connexion...' : 'Tester la connexion'}
                </button>
              </div>
            </div>
          </div>
        )}

        {/* MAPPING TAB */}
        {tab === 'mapping' && (
          <div className="max-w-5xl mx-auto">
            <div className={cn('mb-3 p-3 rounded-xl text-xs', isDark ? 'bg-blue-500/10 border border-blue-500/30 text-blue-300' : 'bg-blue-50 border border-blue-200 text-blue-700')}>
              Mapping Modbus pour SCHNEIDER TM200CE24R — {tags.length} tags configurés
            </div>
            <div className={cn('rounded-xl border overflow-hidden', isDark ? 'bg-slate-800 border-slate-700' : 'bg-white border-slate-200')}>
              <table className="w-full text-sm">
                <thead className={cn('text-xs uppercase', isDark ? 'bg-slate-700 text-slate-400' : 'bg-slate-50 text-slate-500')}>
                  <tr>
                    <th className="px-3 py-2.5 text-left">Adresse</th>
                    <th className="px-3 py-2.5 text-left">Type</th>
                    <th className="px-3 py-2.5 text-left">Nom</th>
                    <th className="px-3 py-2.5 text-left">Description</th>
                    <th className="px-3 py-2.5 text-right">Valeur</th>
                    <th className="px-3 py-2.5 text-left">Unité</th>
                    <th className="px-3 py-2.5 text-center">Qualité</th>
                  </tr>
                </thead>
                <tbody>
                  {tags.map(tag => (
                    <tr key={tag.id} className={cn('border-t', isDark ? 'border-slate-700 hover:bg-slate-700/40' : 'border-slate-100 hover:bg-slate-50')}>
                      <td className="px-3 py-2 font-mono text-xs font-bold text-orange-400">{tag.address}</td>
                      <td className="px-3 py-2">
                        <span className={cn('px-1.5 py-0.5 rounded text-xs font-mono', {
                          coil: 'bg-green-500/20 text-green-400',
                          discrete_input: 'bg-blue-500/20 text-blue-400',
                          holding_register: 'bg-purple-500/20 text-purple-400',
                          input_register: 'bg-cyan-500/20 text-cyan-400',
                        }[tag.type] || 'bg-slate-700 text-slate-400')}>
                          {tag.type === 'coil' ? 'COIL' : tag.type === 'holding_register' ? 'HR' : tag.type.toUpperCase()}
                        </span>
                      </td>
                      <td className="px-3 py-2 font-medium">{tag.name}</td>
                      <td className="px-3 py-2 text-xs text-slate-400 max-w-xs truncate">{tag.description}</td>
                      <td className="px-3 py-2 text-right font-mono font-bold">
                        <span className={cn(tag.quality === 'good' ? 'text-green-400' : isDark ? 'text-slate-500' : 'text-slate-400')}>
                          {tag.type === 'coil' ? (tag.value ? '1 (ON)' : '0 (OFF)') : `${tag.value}`}
                        </span>
                      </td>
                      <td className="px-3 py-2 text-xs text-slate-400">{tag.unit || '—'}</td>
                      <td className="px-3 py-2 text-center">
                        <span className={cn('w-2 h-2 rounded-full inline-block', {
                          good: 'bg-green-400',
                          bad: 'bg-red-400',
                          uncertain: 'bg-yellow-400',
                        }[tag.quality as string] || 'bg-slate-500')} />
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* LOG TAB */}
        {tab === 'log' && (
          <div className="max-w-4xl mx-auto">
            <div className="flex items-center justify-between mb-3">
              <h3 className={cn('font-bold', isDark ? 'text-white' : 'text-slate-900')}>Journal des erreurs communication</h3>
              <span className={cn('text-xs', isDark ? 'text-slate-400' : 'text-slate-500')}>{modbusStatus.errorLog.length} entrées</span>
            </div>
            <div className="space-y-2">
              {modbusStatus.errorLog.length === 0 ? (
                <div className={cn('text-center py-10 rounded-xl border', isDark ? 'bg-slate-800 border-slate-700 text-slate-500' : 'bg-white border-slate-200 text-slate-400')}>
                  <CheckCircle size={32} className="mx-auto mb-2 text-green-400 opacity-60" />
                  Aucune erreur enregistrée
                </div>
              ) : (
                modbusStatus.errorLog.map((err, i) => (
                  <div key={i} className={cn('flex items-start gap-3 p-3 rounded-xl border', isDark ? 'bg-slate-800 border-red-500/30 border-opacity-50' : 'bg-white border-red-200')}>
                    <AlertTriangle size={14} className="text-red-400 flex-shrink-0 mt-0.5" />
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-mono text-xs font-bold text-red-400">{err.code}</span>
                        <span className={cn('text-xs', isDark ? 'text-slate-500' : 'text-slate-400')}>
                          {format(new Date(err.timestamp), 'dd/MM/yyyy HH:mm:ss')}
                        </span>
                      </div>
                      <p className={cn('text-sm mt-0.5', isDark ? 'text-slate-300' : 'text-slate-700')}>{err.message}</p>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default CommunicationPage;
