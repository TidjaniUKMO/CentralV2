/**
 * BétonPro SCADA - Module Recettes
 * CRUD complet avec validation et historique
 */
import React, { useState } from 'react';
import { useStore } from '../store';
import {
  Plus, Search, Edit, Trash2, Copy, Save, X, ChevronDown, ChevronUp
} from 'lucide-react';
import { cn } from '../utils/cn';
import { format } from 'date-fns';
import type { Recipe, AggregateComponent, CementComponent } from '../types';

export const RecipesPage: React.FC = () => {
  const { theme, recipes, plantConfig, addRecipe, updateRecipe, deleteRecipe, duplicateRecipe, auth } = useStore();
  const isDark = theme === 'dark';

  const [search, setSearch] = useState('');
  const [editId, setEditId] = useState<string | null>(null);
  const [showForm, setShowForm] = useState(false);
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [confirmDelete, setConfirmDelete] = useState<string | null>(null);

  const activeHoppers = plantConfig.hoppers.filter(h => h.active);
  const activeSilos = plantConfig.silos.filter(s => s.active);

  const emptyForm = {
    code: '', name: '', description: '',
    aggregates: activeHoppers.map(h => ({ hopperId: h.id, hopperName: h.name, weight: 0 })),
    cement: activeSilos.map(s => ({ siloId: s.id, siloName: s.name, weight: 0 })),
    waterVolume: 0, adjuvantVolume: 0, mixingTime: 90,
  };

  const [form, setForm] = useState(emptyForm);
  const [formErrors, setFormErrors] = useState<Record<string, string>>({});

  const filteredRecipes = recipes.filter(r => {
    if (!search) return true;
    const s = search.toLowerCase();
    return r.name.toLowerCase().includes(s) ||
      r.code.toLowerCase().includes(s) ||
      r.description?.toLowerCase().includes(s);
  });

  const canWrite = auth.user?.permissions.find(p => p.module === 'recipes')?.write || auth.user?.role === 'admin';

  const validateForm = () => {
    const errs: Record<string, string> = {};
    if (!form.name.trim()) errs.name = 'Le nom est obligatoire';
    if (!form.code.trim()) errs.code = 'Le code est obligatoire';
    const totalAgg = form.aggregates.reduce((a, b) => a + (b.weight || 0), 0);
    const totalCem = form.cement.reduce((a, b) => a + (b.weight || 0), 0);
    if (totalAgg === 0) errs.aggregates = 'Au moins un agrégat requis';
    if (totalCem === 0) errs.cement = 'Au moins un ciment requis';
    if (form.waterVolume < 0) errs.water = 'Volume eau invalide';
    // Check duplicate code
    const existing = recipes.find(r => r.code === form.code && r.id !== editId);
    if (existing) errs.code = 'Ce code existe déjà';
    setFormErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSave = () => {
    if (!validateForm()) return;
    const totalWeight = form.aggregates.reduce((a, b) => a + b.weight, 0) +
      form.cement.reduce((a, b) => a + b.weight, 0) + form.waterVolume + form.adjuvantVolume;

    if (editId) {
      updateRecipe(editId, { ...form, totalWeight, updatedAt: new Date() });
    } else {
      addRecipe({
        ...form,
        id: `r-${Date.now()}`,
        totalWeight,
        volumeM3: 1,
        createdAt: new Date(),
        updatedAt: new Date(),
        createdBy: auth.user?.username || 'admin',
        usageCount: 0,
        active: true,
      });
    }
    setShowForm(false);
    setEditId(null);
    setForm(emptyForm);
  };

  const handleEdit = (recipe: Recipe) => {
    setForm({
      code: recipe.code, name: recipe.name, description: recipe.description || '',
      aggregates: activeHoppers.map(h => {
        const existing = recipe.aggregates.find(a => a.hopperId === h.id);
        return existing || { hopperId: h.id, hopperName: h.name, weight: 0 };
      }),
      cement: activeSilos.map(s => {
        const existing = recipe.cement.find(c => c.siloId === s.id);
        return existing || { siloId: s.id, siloName: s.name, weight: 0 };
      }),
      waterVolume: recipe.waterVolume, adjuvantVolume: recipe.adjuvantVolume, mixingTime: recipe.mixingTime,
    });
    setEditId(recipe.id);
    setShowForm(true);
  };

  const handleDelete = (id: string) => {
    if (confirmDelete === id) {
      deleteRecipe(id);
      setConfirmDelete(null);
    } else {
      setConfirmDelete(id);
      setTimeout(() => setConfirmDelete(null), 3000);
    }
  };

  return (
    <div className={cn('h-full flex flex-col', isDark ? 'bg-slate-900 text-white' : 'bg-slate-50 text-slate-900')}>
      {/* Toolbar */}
      <div className={cn('flex items-center gap-3 px-4 py-3 border-b', isDark ? 'border-slate-700 bg-slate-900' : 'border-slate-200 bg-slate-50')}>
        <div className="relative flex-1 max-w-md">
          <Search size={14} className={cn('absolute left-3 top-1/2 -translate-y-1/2', isDark ? 'text-slate-500' : 'text-slate-400')} />
          <input
            type="text" value={search} onChange={e => setSearch(e.target.value)}
            placeholder="Rechercher recette..."
            className={cn('w-full pl-9 pr-4 py-2 rounded-lg border text-sm', isDark ? 'bg-slate-800 border-slate-700 text-white placeholder-slate-500' : 'bg-white border-slate-200 text-slate-900')}
          />
        </div>
        <span className={cn('text-xs', isDark ? 'text-slate-400' : 'text-slate-500')}>{filteredRecipes.length} recettes</span>
        {canWrite && (
          <button
            onClick={() => { setShowForm(true); setEditId(null); setForm(emptyForm); }}
            className="flex items-center gap-2 px-4 py-2 rounded-lg bg-orange-500 hover:bg-orange-600 text-white font-bold text-sm transition-all shadow-lg shadow-orange-500/30"
          >
            <Plus size={14} /> Nouvelle recette
          </button>
        )}
      </div>

      <div className="flex-1 overflow-auto p-4">
        {/* Form Panel */}
        {showForm && (
          <div className={cn('rounded-xl border p-5 mb-4', isDark ? 'bg-slate-800 border-slate-700' : 'bg-white border-slate-200')}>
            <div className="flex items-center justify-between mb-4">
              <h3 className={cn('font-bold', isDark ? 'text-white' : 'text-slate-900')}>
                {editId ? '✏️ Modifier la recette' : '➕ Nouvelle recette'}
              </h3>
              <button onClick={() => { setShowForm(false); setEditId(null); }} className={cn('p-1.5 rounded-lg hover:bg-slate-700', isDark ? 'text-slate-400 hover:text-white' : 'text-slate-500')}>
                <X size={16} />
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Left: basic info */}
              <div className="space-y-3">
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className={cn('block text-xs font-semibold mb-1 uppercase', isDark ? 'text-slate-400' : 'text-slate-500')}>Code *</label>
                    <input value={form.code} onChange={e => setForm(f => ({ ...f, code: e.target.value }))}
                      className={cn('w-full px-3 py-2 rounded-lg border text-sm', isDark ? 'bg-slate-700 border-slate-600 text-white' : 'bg-slate-50 border-slate-200', formErrors.code && 'border-red-500')}
                      placeholder="B25"
                    />
                    {formErrors.code && <p className="text-xs text-red-400 mt-0.5">{formErrors.code}</p>}
                  </div>
                  <div>
                    <label className={cn('block text-xs font-semibold mb-1 uppercase', isDark ? 'text-slate-400' : 'text-slate-500')}>Nom *</label>
                    <input value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))}
                      className={cn('w-full px-3 py-2 rounded-lg border text-sm', isDark ? 'bg-slate-700 border-slate-600 text-white' : 'bg-slate-50 border-slate-200', formErrors.name && 'border-red-500')}
                      placeholder="Béton B25"
                    />
                    {formErrors.name && <p className="text-xs text-red-400 mt-0.5">{formErrors.name}</p>}
                  </div>
                </div>
                <div>
                  <label className={cn('block text-xs font-semibold mb-1 uppercase', isDark ? 'text-slate-400' : 'text-slate-500')}>Description</label>
                  <textarea value={form.description} onChange={e => setForm(f => ({ ...f, description: e.target.value }))}
                    rows={2}
                    className={cn('w-full px-3 py-2 rounded-lg border text-sm resize-none', isDark ? 'bg-slate-700 border-slate-600 text-white' : 'bg-slate-50 border-slate-200')}
                    placeholder="Description optionnelle..."
                  />
                </div>

                {/* Aggregates */}
                <div>
                  <label className={cn('block text-xs font-semibold mb-2 uppercase', isDark ? 'text-slate-400' : 'text-slate-500')}>
                    Agrégats (kg) {formErrors.aggregates && <span className="text-red-400 normal-case">— {formErrors.aggregates}</span>}
                  </label>
                  {form.aggregates.map((agg, i) => (
                    <div key={agg.hopperId} className="flex items-center gap-2 mb-2">
                      <label className={cn('text-xs flex-1 truncate', isDark ? 'text-slate-300' : 'text-slate-600')}>{agg.hopperName}</label>
                      <input
                        type="number" min="0" step="10"
                        value={agg.weight || ''}
                        onChange={e => {
                          const newAgg = [...form.aggregates];
                          newAgg[i] = { ...newAgg[i], weight: parseFloat(e.target.value) || 0 };
                          setForm(f => ({ ...f, aggregates: newAgg }));
                        }}
                        className={cn('w-28 px-2 py-1.5 rounded-lg border text-sm text-right', isDark ? 'bg-slate-700 border-slate-600 text-white' : 'bg-slate-50 border-slate-200')}
                        placeholder="0"
                      />
                    </div>
                  ))}
                </div>

                {/* Cement */}
                <div>
                  <label className={cn('block text-xs font-semibold mb-2 uppercase', isDark ? 'text-slate-400' : 'text-slate-500')}>
                    Ciment (kg) {formErrors.cement && <span className="text-red-400 normal-case">— {formErrors.cement}</span>}
                  </label>
                  {form.cement.map((cem, i) => (
                    <div key={cem.siloId} className="flex items-center gap-2 mb-2">
                      <label className={cn('text-xs flex-1 truncate', isDark ? 'text-slate-300' : 'text-slate-600')}>{cem.siloName}</label>
                      <input
                        type="number" min="0" step="10"
                        value={cem.weight || ''}
                        onChange={e => {
                          const newCem = [...form.cement];
                          newCem[i] = { ...newCem[i], weight: parseFloat(e.target.value) || 0 };
                          setForm(f => ({ ...f, cement: newCem }));
                        }}
                        className={cn('w-28 px-2 py-1.5 rounded-lg border text-sm text-right', isDark ? 'bg-slate-700 border-slate-600 text-white' : 'bg-slate-50 border-slate-200')}
                        placeholder="0"
                      />
                    </div>
                  ))}
                </div>
              </div>

              {/* Right: water, adjuvant, mixing */}
              <div className="space-y-3">
                <div>
                  <label className={cn('block text-xs font-semibold mb-1 uppercase', isDark ? 'text-slate-400' : 'text-slate-500')}>Eau (litres)</label>
                  <input type="number" min="0" step="5" value={form.waterVolume || ''}
                    onChange={e => setForm(f => ({ ...f, waterVolume: parseFloat(e.target.value) || 0 }))}
                    className={cn('w-full px-3 py-2 rounded-lg border text-sm', isDark ? 'bg-slate-700 border-slate-600 text-white' : 'bg-slate-50 border-slate-200')}
                  />
                </div>
                <div>
                  <label className={cn('block text-xs font-semibold mb-1 uppercase', isDark ? 'text-slate-400' : 'text-slate-500')}>Adjuvant (litres)</label>
                  <input type="number" min="0" step="0.1" value={form.adjuvantVolume || ''}
                    onChange={e => setForm(f => ({ ...f, adjuvantVolume: parseFloat(e.target.value) || 0 }))}
                    className={cn('w-full px-3 py-2 rounded-lg border text-sm', isDark ? 'bg-slate-700 border-slate-600 text-white' : 'bg-slate-50 border-slate-200')}
                  />
                </div>
                <div>
                  <label className={cn('block text-xs font-semibold mb-1 uppercase', isDark ? 'text-slate-400' : 'text-slate-500')}>Temps malaxage (s)</label>
                  <input type="number" min="30" max="300" step="10" value={form.mixingTime}
                    onChange={e => setForm(f => ({ ...f, mixingTime: parseInt(e.target.value) || 90 }))}
                    className={cn('w-full px-3 py-2 rounded-lg border text-sm', isDark ? 'bg-slate-700 border-slate-600 text-white' : 'bg-slate-50 border-slate-200')}
                  />
                </div>

                {/* Summary */}
                <div className={cn('p-3 rounded-lg', isDark ? 'bg-slate-700' : 'bg-slate-50')}>
                  <div className="text-xs font-bold mb-2 text-orange-400">Récapitulatif</div>
                  <div className="space-y-1 text-xs">
                    <div className="flex justify-between">
                      <span className={isDark ? 'text-slate-400' : 'text-slate-500'}>Total agrégats</span>
                      <span className="font-bold">{form.aggregates.reduce((a, b) => a + (b.weight || 0), 0)} kg</span>
                    </div>
                    <div className="flex justify-between">
                      <span className={isDark ? 'text-slate-400' : 'text-slate-500'}>Total ciment</span>
                      <span className="font-bold">{form.cement.reduce((a, b) => a + (b.weight || 0), 0)} kg</span>
                    </div>
                    <div className="flex justify-between">
                      <span className={isDark ? 'text-slate-400' : 'text-slate-500'}>Eau</span>
                      <span className="font-bold">{form.waterVolume} L</span>
                    </div>
                    <div className="flex justify-between">
                      <span className={isDark ? 'text-slate-400' : 'text-slate-500'}>Adjuvant</span>
                      <span className="font-bold">{form.adjuvantVolume} L</span>
                    </div>
                    <div className={cn('flex justify-between pt-1 border-t font-black text-sm text-orange-400', isDark ? 'border-slate-600' : 'border-slate-200')}>
                      <span>TOTAL</span>
                      <span>{(form.aggregates.reduce((a, b) => a + (b.weight || 0), 0) + form.cement.reduce((a, b) => a + (b.weight || 0), 0) + form.waterVolume + form.adjuvantVolume).toFixed(0)} kg</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-3 mt-4 pt-4 border-t border-slate-700">
              <button onClick={handleSave} className="flex items-center gap-2 px-5 py-2 rounded-lg bg-green-500 hover:bg-green-600 text-white font-bold text-sm">
                <Save size={14} /> Enregistrer
              </button>
              <button onClick={() => { setShowForm(false); setEditId(null); }} className={cn('px-4 py-2 rounded-lg text-sm font-medium', isDark ? 'bg-slate-700 text-slate-300 hover:bg-slate-600' : 'bg-slate-100 text-slate-600 hover:bg-slate-200')}>
                Annuler
              </button>
            </div>
          </div>
        )}

        {/* Recipes Table */}
        <div className={cn('rounded-xl border overflow-hidden', isDark ? 'bg-slate-800 border-slate-700' : 'bg-white border-slate-200')}>
          <table className="w-full">
            <thead className={cn('text-xs uppercase', isDark ? 'bg-slate-700 text-slate-400' : 'bg-slate-50 text-slate-500')}>
              <tr>
                <th className="px-4 py-3 text-left w-8"></th>
                <th className="px-4 py-3 text-left">Code</th>
                <th className="px-4 py-3 text-left">Nom</th>
                <th className="px-4 py-3 text-right">Agrégats</th>
                <th className="px-4 py-3 text-right">Ciment</th>
                <th className="px-4 py-3 text-right">Eau</th>
                <th className="px-4 py-3 text-right">Adjuvant</th>
                <th className="px-4 py-3 text-right">Total</th>
                <th className="px-4 py-3 text-center">Utilisations</th>
                <th className="px-4 py-3 text-left">Créée le</th>
                {canWrite && <th className="px-4 py-3 text-center">Actions</th>}
              </tr>
            </thead>
            <tbody>
              {filteredRecipes.map(recipe => (
                <React.Fragment key={recipe.id}>
                  <tr className={cn(
                    'border-t cursor-pointer',
                    isDark ? 'border-slate-700 hover:bg-slate-700/50' : 'border-slate-100 hover:bg-slate-50'
                  )} onClick={() => setExpandedId(expandedId === recipe.id ? null : recipe.id)}>
                    <td className="px-4 py-3">
                      {expandedId === recipe.id ? <ChevronUp size={14} className="text-slate-400" /> : <ChevronDown size={14} className="text-slate-400" />}
                    </td>
                    <td className="px-4 py-3">
                      <span className="font-mono font-bold text-orange-400 text-sm">{recipe.code}</span>
                    </td>
                    <td className="px-4 py-3">
                      <div className={cn('font-medium', isDark ? 'text-white' : 'text-slate-900')}>{recipe.name}</div>
                      {recipe.description && <div className={cn('text-xs', isDark ? 'text-slate-500' : 'text-slate-400')}>{recipe.description}</div>}
                    </td>
                    <td className="px-4 py-3 text-right text-sm">{recipe.aggregates.reduce((a, b) => a + b.weight, 0)} kg</td>
                    <td className="px-4 py-3 text-right text-sm">{recipe.cement.reduce((a, b) => a + b.weight, 0)} kg</td>
                    <td className="px-4 py-3 text-right text-sm text-blue-400">{recipe.waterVolume} L</td>
                    <td className="px-4 py-3 text-right text-sm text-purple-400">{recipe.adjuvantVolume} L</td>
                    <td className="px-4 py-3 text-right font-bold text-orange-400">{recipe.totalWeight.toFixed(0)} kg</td>
                    <td className="px-4 py-3 text-center">
                      <span className={cn('px-2 py-0.5 rounded-full text-xs font-bold', isDark ? 'bg-slate-700 text-slate-300' : 'bg-slate-100 text-slate-600')}>
                        {recipe.usageCount}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-xs text-slate-400">
                      {format(new Date(recipe.createdAt), 'dd/MM/yyyy')}
                    </td>
                    {canWrite && (
                      <td className="px-4 py-3">
                        <div className="flex items-center justify-center gap-1" onClick={e => e.stopPropagation()}>
                          <button onClick={() => handleEdit(recipe)}
                            className="p-1.5 rounded-lg text-blue-400 hover:bg-blue-500/20 transition-colors">
                            <Edit size={14} />
                          </button>
                          <button onClick={() => duplicateRecipe(recipe.id)}
                            className="p-1.5 rounded-lg text-green-400 hover:bg-green-500/20 transition-colors">
                            <Copy size={14} />
                          </button>
                          <button onClick={() => handleDelete(recipe.id)}
                            className={cn('p-1.5 rounded-lg transition-colors', confirmDelete === recipe.id ? 'bg-red-500 text-white' : 'text-red-400 hover:bg-red-500/20')}>
                            <Trash2 size={14} />
                          </button>
                        </div>
                      </td>
                    )}
                  </tr>
                  {expandedId === recipe.id && (
                    <tr className={isDark ? 'bg-slate-700/30' : 'bg-slate-50'}>
                      <td colSpan={canWrite ? 11 : 10} className="px-6 py-3">
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-xs">
                          <div>
                            <div className="font-bold mb-1 text-slate-400 uppercase">Agrégats</div>
                            {recipe.aggregates.map(a => (
                              <div key={a.hopperId} className="flex justify-between">
                                <span className={isDark ? 'text-slate-300' : 'text-slate-600'}>{a.hopperName}</span>
                                <span className="font-bold ml-2">{a.weight} kg</span>
                              </div>
                            ))}
                          </div>
                          <div>
                            <div className="font-bold mb-1 text-slate-400 uppercase">Ciment</div>
                            {recipe.cement.map(c => (
                              <div key={c.siloId} className="flex justify-between">
                                <span className={isDark ? 'text-slate-300' : 'text-slate-600'}>{c.siloName}</span>
                                <span className="font-bold ml-2">{c.weight} kg</span>
                              </div>
                            ))}
                          </div>
                          <div>
                            <div className="font-bold mb-1 text-slate-400 uppercase">Liquides</div>
                            <div className="flex justify-between"><span className={isDark ? 'text-slate-300' : 'text-slate-600'}>Eau</span><span className="font-bold">{recipe.waterVolume} L</span></div>
                            <div className="flex justify-between"><span className={isDark ? 'text-slate-300' : 'text-slate-600'}>Adjuvant</span><span className="font-bold">{recipe.adjuvantVolume} L</span></div>
                          </div>
                          <div>
                            <div className="font-bold mb-1 text-slate-400 uppercase">Paramètres</div>
                            <div className="flex justify-between"><span className={isDark ? 'text-slate-300' : 'text-slate-600'}>Malaxage</span><span className="font-bold">{recipe.mixingTime} s</span></div>
                            <div className="flex justify-between"><span className={isDark ? 'text-slate-300' : 'text-slate-600'}>Par</span><span className="font-bold">{recipe.createdBy}</span></div>
                          </div>
                        </div>
                      </td>
                    </tr>
                  )}
                </React.Fragment>
              ))}
            </tbody>
          </table>
          {filteredRecipes.length === 0 && (
            <div className={cn('text-center py-12', isDark ? 'text-slate-500' : 'text-slate-400')}>
              Aucune recette trouvée
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default RecipesPage;
