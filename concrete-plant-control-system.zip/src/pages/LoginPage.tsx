/**
 * BétonPro SCADA - Page de connexion
 * Authentification industrielle sécurisée
 */
import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useStore } from '../store';
import { Factory, Lock, User, Eye, EyeOff, AlertTriangle, Globe } from 'lucide-react';
import { cn } from '../utils/cn';

interface LoginPageProps {
  onLogin: () => void;
}

export const LoginPage: React.FC<LoginPageProps> = ({ onLogin }) => {
  const { t, i18n } = useTranslation();
  const { login, theme, language, setLanguage } = useStore();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPwd, setShowPwd] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const isDark = theme === 'dark';

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    await new Promise(r => setTimeout(r, 500)); // Simulation délai auth
    const ok = login(username, password);
    setLoading(false);
    if (ok) {
      onLogin();
    } else {
      setError(t('auth.error'));
    }
  };

  const handleLang = (lang: 'fr' | 'en' | 'ar') => {
    setLanguage(lang);
    i18n.changeLanguage(lang);
  };

  return (
    <div className={cn(
      'min-h-screen flex items-center justify-center relative overflow-hidden',
      isDark ? 'bg-slate-950' : 'bg-slate-100'
    )}>
      {/* Background industrial grid */}
      <div className="absolute inset-0 opacity-5" style={{
        backgroundImage: `linear-gradient(rgba(255,165,0,0.5) 1px, transparent 1px), linear-gradient(90deg, rgba(255,165,0,0.5) 1px, transparent 1px)`,
        backgroundSize: '40px 40px'
      }} />

      {/* Animated background orbs */}
      <div className="absolute top-1/4 -left-20 w-80 h-80 rounded-full bg-orange-500/10 blur-3xl animate-pulse" />
      <div className="absolute bottom-1/4 -right-20 w-80 h-80 rounded-full bg-blue-500/10 blur-3xl animate-pulse" style={{ animationDelay: '1s' }} />

      <div className="relative z-10 w-full max-w-md px-4">
        {/* Lang selector */}
        <div className="flex justify-end mb-4 gap-2">
          {(['fr', 'en', 'ar'] as const).map(lang => (
            <button
              key={lang}
              onClick={() => handleLang(lang)}
              className={cn(
                'px-3 py-1 rounded-lg text-xs font-bold uppercase transition-all',
                language === lang
                  ? 'bg-orange-500 text-white'
                  : isDark ? 'bg-slate-800 text-slate-400 hover:text-white' : 'bg-white text-slate-500 hover:text-slate-900 shadow'
              )}
            >
              {lang}
            </button>
          ))}
        </div>

        {/* Card */}
        <div className={cn(
          'rounded-2xl p-8 shadow-2xl border',
          isDark ? 'bg-slate-900 border-slate-700' : 'bg-white border-slate-200'
        )}>
          {/* Logo + Titre */}
          <div className="text-center mb-8">
            <div className="inline-flex w-20 h-20 rounded-2xl bg-gradient-to-br from-orange-500 to-red-600 items-center justify-center mb-4 shadow-lg shadow-orange-500/30">
              <Factory size={40} className="text-white" />
            </div>
            <h1 className={cn('text-3xl font-black tracking-tight', isDark ? 'text-white' : 'text-slate-900')}>
              {t('auth.title')}
            </h1>
            <p className={cn('text-sm mt-1', isDark ? 'text-slate-400' : 'text-slate-500')}>
              {t('auth.subtitle')}
            </p>
            <div className={cn('mt-2 text-xs px-3 py-1 rounded-full inline-block', isDark ? 'bg-slate-800 text-slate-400' : 'bg-slate-100 text-slate-500')}>
              SCHNEIDER TM200CE24R · Modbus TCP
            </div>
          </div>

          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Username */}
            <div>
              <label className={cn('block text-xs font-semibold mb-1.5 uppercase tracking-wider', isDark ? 'text-slate-400' : 'text-slate-500')}>
                {t('auth.username')}
              </label>
              <div className="relative">
                <User size={16} className={cn('absolute left-3 top-1/2 -translate-y-1/2', isDark ? 'text-slate-500' : 'text-slate-400')} />
                <input
                  type="text"
                  value={username}
                  onChange={e => setUsername(e.target.value)}
                  required
                  autoComplete="username"
                  placeholder="admin / operateur / maintenance"
                  className={cn(
                    'w-full pl-10 pr-4 py-3 rounded-xl border text-sm transition-all outline-none',
                    isDark
                      ? 'bg-slate-800 border-slate-600 text-white placeholder-slate-500 focus:border-orange-500 focus:ring-1 focus:ring-orange-500'
                      : 'bg-slate-50 border-slate-200 text-slate-900 placeholder-slate-400 focus:border-orange-500 focus:ring-1 focus:ring-orange-500'
                  )}
                />
              </div>
            </div>

            {/* Password */}
            <div>
              <label className={cn('block text-xs font-semibold mb-1.5 uppercase tracking-wider', isDark ? 'text-slate-400' : 'text-slate-500')}>
                {t('auth.password')}
              </label>
              <div className="relative">
                <Lock size={16} className={cn('absolute left-3 top-1/2 -translate-y-1/2', isDark ? 'text-slate-500' : 'text-slate-400')} />
                <input
                  type={showPwd ? 'text' : 'password'}
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  required
                  autoComplete="current-password"
                  placeholder="••••••••"
                  className={cn(
                    'w-full pl-10 pr-12 py-3 rounded-xl border text-sm transition-all outline-none',
                    isDark
                      ? 'bg-slate-800 border-slate-600 text-white placeholder-slate-500 focus:border-orange-500 focus:ring-1 focus:ring-orange-500'
                      : 'bg-slate-50 border-slate-200 text-slate-900 placeholder-slate-400 focus:border-orange-500 focus:ring-1 focus:ring-orange-500'
                  )}
                />
                <button
                  type="button"
                  onClick={() => setShowPwd(s => !s)}
                  className={cn('absolute right-3 top-1/2 -translate-y-1/2', isDark ? 'text-slate-500 hover:text-white' : 'text-slate-400 hover:text-slate-700')}
                >
                  {showPwd ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
            </div>

            {/* Error */}
            {error && (
              <div className="flex items-center gap-2 px-3 py-2 rounded-lg bg-red-500/10 border border-red-500/30 text-red-400 text-sm">
                <AlertTriangle size={14} />
                {error}
              </div>
            )}

            {/* Submit */}
            <button
              type="submit"
              disabled={loading}
              className={cn(
                'w-full py-3 rounded-xl font-bold text-sm transition-all duration-200',
                loading
                  ? 'bg-slate-600 text-slate-400 cursor-not-allowed'
                  : 'bg-gradient-to-r from-orange-500 to-red-600 text-white hover:from-orange-600 hover:to-red-700 shadow-lg shadow-orange-500/30 hover:shadow-orange-500/50 hover:-translate-y-0.5'
              )}
            >
              {loading ? (
                <span className="flex items-center justify-center gap-2">
                  <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  {t('common.loading')}
                </span>
              ) : t('auth.loginBtn')}
            </button>
          </form>

          {/* Credentials hint */}
          <div className={cn('mt-6 p-3 rounded-lg text-xs space-y-1', isDark ? 'bg-slate-800 text-slate-400' : 'bg-slate-50 text-slate-500')}>
            <div className="font-semibold mb-1 text-orange-400">Comptes de démonstration :</div>
            <div>👤 <strong>admin</strong> / admin123 — Administrateur</div>
            <div>👤 <strong>operateur</strong> / oper123 — Opérateur</div>
            <div>👤 <strong>maintenance</strong> / maint123 — Maintenance</div>
          </div>
        </div>

        {/* Version */}
        <p className={cn('text-center text-xs mt-4', isDark ? 'text-slate-600' : 'text-slate-400')}>
          BétonPro SCADA v2.0 · Schneider TM200CE24R · PostgreSQL 18.3
        </p>
      </div>
    </div>
  );
};

export default LoginPage;
