/**
 * BétonPro SCADA - Store Zustand Global
 * Gestion d'état centralisé - Architecture industrielle
 */
import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type {
  User, AuthState, PlantConfig, Hopper, Silo, WaterTank, AdjuvantTank,
  ModbusConfig, ModbusTag, ModbusStatus, ModbusError,
  Timers, ImpulseConfig, Recipe, Client, Truck, Driver,
  ProductionBatch, Alarm, PlantRealTimeState, Theme, Language,
  SimulatorState, MotorState, ValveState, ScaleState,
  ProductionStep, AlarmType, AlarmPriority
} from '../types';

// =============================================
// DONNÉES PAR DÉFAUT
// =============================================
const defaultTimers: Timers = {
  valveOpenTime: 3000,
  valveCloseTime: 2000,
  conveyorStartTime: 5000,
  skipTime: 30000,
  mixingTime: 60000,
  safetyTimeout: 10000,
  alarmTimeout: 5000,
  dischargeTimeout: 120000,
  cementFlowTimeout: 30000,
  waterFlowTimeout: 20000,
};

const defaultImpulse: ImpulseConfig = {
  enabled: true,
  triggerPercent: 90,
  impulseOnTime: 500,
  impulseOffTime: 300,
};

const defaultModbusConfig: ModbusConfig = {
  ip: '192.168.1.100',
  port: 502,
  timeout: 3000,
  refreshRate: 200,
  unitId: 1,
  reconnectDelay: 5000,
  maxRetries: 3,
};

const defaultPlantConfig: PlantConfig = {
  id: 'plant-001',
  plantName: 'Centrale à Béton N°1',
  hoppers: [
    { id: 'h1', name: 'Trémie Sable 0/4', index: 0, dischargeMode: 'piston', hasVibrator: true, modbusCoilOpen: 0, modbusCoilClose: 1, modbusSensorFull: 0, modbusSensorEmpty: 1, active: true },
    { id: 'h2', name: 'Trémie Gravier 4/8', index: 1, dischargeMode: 'piston', hasVibrator: false, modbusCoilOpen: 2, modbusCoilClose: 3, modbusSensorFull: 2, modbusSensorEmpty: 3, active: true },
    { id: 'h3', name: 'Trémie Gravier 8/16', index: 2, dischargeMode: 'piston', hasVibrator: false, modbusCoilOpen: 4, modbusCoilClose: 5, modbusSensorFull: 4, modbusSensorEmpty: 5, active: true },
    { id: 'h4', name: 'Trémie Gravier 16/25', index: 3, dischargeMode: 'conveyor', hasVibrator: false, modbusCoilOpen: 6, modbusCoilClose: 7, modbusSensorFull: 6, modbusSensorEmpty: 7, active: false },
  ],
  silos: [
    { id: 's1', name: 'Silo Ciment CEM I 52.5', index: 0, capacity: 60000, modbusLevelLow: 8, modbusLevelHigh: 9, modbusDischarge: 8, active: true },
    { id: 's2', name: 'Silo Ciment CEM II 32.5', index: 1, capacity: 60000, modbusLevelLow: 10, modbusLevelHigh: 11, modbusDischarge: 9, active: true },
  ],
  waterTanks: [
    { id: 'w1', name: 'Réservoir Eau 1', index: 0, capacity: 5000, modbusLevel: 100, modbusPump: 10, active: true },
    { id: 'w2', name: 'Réservoir Eau 2', index: 1, capacity: 5000, modbusLevel: 101, modbusPump: 11, active: false },
  ],
  adjuvantTanks: [
    { id: 'a1', name: 'Réservoir Adjuvant 1', index: 0, capacity: 1000, modbusLevel: 102, modbusPump: 12, active: true },
    { id: 'a2', name: 'Réservoir Adjuvant 2', index: 1, capacity: 1000, modbusLevel: 103, modbusPump: 13, active: false },
  ],
  skipType: 'skip',
  hasSkipCableSensor: true,
  hasSkipBottomSensor: true,
  hasSkipTopSensor: true,
  dischargeConfirmation: 'timer',
  updatedAt: new Date(),
};

const defaultUsers: User[] = [
  {
    id: 'u1', username: 'admin', passwordHash: 'admin123',
    role: 'admin', email: 'admin@betonpro.local', active: true,
    createdAt: new Date(), lastLogin: new Date(),
    permissions: [
      { module: 'production', read: true, write: true, execute: true },
      { module: 'recipes', read: true, write: true, execute: true },
      { module: 'clients', read: true, write: true, execute: true },
      { module: 'parameters', read: true, write: true, execute: true },
      { module: 'users', read: true, write: true, execute: true },
      { module: 'developer', read: true, write: true, execute: true },
    ],
  },
  {
    id: 'u2', username: 'operateur', passwordHash: 'oper123',
    role: 'operator', email: 'operateur@betonpro.local', active: true,
    createdAt: new Date(), lastLogin: new Date(),
    permissions: [
      { module: 'production', read: true, write: true, execute: true },
      { module: 'recipes', read: true, write: false, execute: false },
      { module: 'clients', read: true, write: false, execute: false },
      { module: 'parameters', read: true, write: false, execute: false },
      { module: 'users', read: false, write: false, execute: false },
      { module: 'developer', read: false, write: false, execute: false },
    ],
  },
  {
    id: 'u3', username: 'maintenance', passwordHash: 'maint123',
    role: 'maintenance', email: 'maintenance@betonpro.local', active: true,
    createdAt: new Date(), lastLogin: new Date(),
    permissions: [
      { module: 'production', read: true, write: false, execute: false },
      { module: 'recipes', read: true, write: true, execute: false },
      { module: 'clients', read: true, write: false, execute: false },
      { module: 'parameters', read: true, write: true, execute: true },
      { module: 'users', read: false, write: false, execute: false },
      { module: 'developer', read: true, write: false, execute: false },
    ],
  },
];

const defaultRecipes: Recipe[] = [
  {
    id: 'r1', code: 'B25', name: 'Béton B25', description: 'Béton de structure standard',
    aggregates: [
      { hopperId: 'h1', hopperName: 'Sable 0/4', weight: 700 },
      { hopperId: 'h2', hopperName: 'Gravier 4/8', weight: 300 },
      { hopperId: 'h3', hopperName: 'Gravier 8/16', weight: 600 },
    ],
    cement: [{ siloId: 's1', siloName: 'CEM I 52.5', weight: 350 }],
    waterVolume: 175, adjuvantVolume: 3.5, mixingTime: 90,
    totalWeight: 2128.5, volumeM3: 1.0,
    createdAt: new Date('2024-01-15'), updatedAt: new Date('2024-01-15'),
    createdBy: 'admin', usageCount: 47, active: true,
  },
  {
    id: 'r2', code: 'B30', name: 'Béton B30', description: 'Béton haute performance',
    aggregates: [
      { hopperId: 'h1', hopperName: 'Sable 0/4', weight: 650 },
      { hopperId: 'h2', hopperName: 'Gravier 4/8', weight: 350 },
      { hopperId: 'h3', hopperName: 'Gravier 8/16', weight: 650 },
    ],
    cement: [{ siloId: 's1', siloName: 'CEM I 52.5', weight: 400 }],
    waterVolume: 160, adjuvantVolume: 4.0, mixingTime: 120,
    totalWeight: 2214.0, volumeM3: 1.0,
    createdAt: new Date('2024-01-20'), updatedAt: new Date('2024-02-10'),
    createdBy: 'admin', usageCount: 23, active: true,
  },
  {
    id: 'r3', code: 'BC15', name: 'Béton de Propreté', description: 'Béton courant C15',
    aggregates: [
      { hopperId: 'h1', hopperName: 'Sable 0/4', weight: 800 },
      { hopperId: 'h3', hopperName: 'Gravier 8/16', weight: 900 },
    ],
    cement: [{ siloId: 's2', siloName: 'CEM II 32.5', weight: 250 }],
    waterVolume: 175, adjuvantVolume: 0, mixingTime: 60,
    totalWeight: 2125.0, volumeM3: 1.0,
    createdAt: new Date('2024-02-01'), updatedAt: new Date('2024-02-01'),
    createdBy: 'admin', usageCount: 15, active: true,
  },
];

const defaultClients: Client[] = [
  { id: 'c1', name: 'BTP Construction SARL', type: 'company', phone: '+33 1 23 45 67 89', email: 'contact@btpconstruct.fr', address: '15 Rue de la Construction, 75001 Paris', createdAt: new Date('2024-01-01'), active: true },
  { id: 'c2', name: 'Maçonnerie Dupont', type: 'company', phone: '+33 6 12 34 56 78', email: 'dupont@maconnerie.fr', address: '8 Avenue du Bâtiment, 69002 Lyon', createdAt: new Date('2024-01-15'), active: true },
  { id: 'c3', name: 'Martin Jean-Pierre', type: 'individual', phone: '+33 6 98 76 54 32', address: '25 Rue des Lilas, 13001 Marseille', createdAt: new Date('2024-02-10'), active: true },
];

const defaultTrucks: Truck[] = [
  { id: 't1', clientId: 'c1', plate: 'AB-123-CD', model: 'Mercedes Actros 8m³', capacity: 8, active: true },
  { id: 't2', clientId: 'c1', plate: 'EF-456-GH', model: 'Volvo FMX 10m³', capacity: 10, active: true },
  { id: 't3', clientId: 'c2', plate: 'IJ-789-KL', model: 'Renault K 7m³', capacity: 7, active: true },
];

const defaultDrivers: Driver[] = [
  { id: 'd1', clientId: 'c1', name: 'Thomas Bernard', phone: '+33 6 11 22 33 44', license: 'C+CE', active: true },
  { id: 'd2', clientId: 'c1', name: 'Pierre Martin', phone: '+33 6 55 66 77 88', license: 'C', active: true },
  { id: 'd3', clientId: 'c2', name: 'Marc Dubois', phone: '+33 6 99 88 77 66', license: 'C+CE', active: true },
];

// =============================================
// ÉTAT TEMPS RÉEL PAR DÉFAUT
// =============================================
const createDefaultRealTimeState = (config: PlantConfig): PlantRealTimeState => ({
  modeAuto: false,
  emergencyStop: false,
  plcConnected: false,
  simulatorMode: true,
  hoppers: config.hoppers.filter(h => h.active).map(h => ({
    id: h.id, name: h.name, open: false, vibratorOn: false, level: Math.random() * 60 + 40,
    conveyorRunning: false,
  })),
  silos: config.silos.filter(s => s.active).map(s => ({
    id: s.id, name: s.name, level: Math.random() * 40 + 50, discharging: false,
    levelLow: false, levelHigh: false,
  })),
  aggregateScale: { id: 'scale-agg', name: 'Balance Agrégats', weight: 0, setpoint: 0, tare: 0, stable: true, inTolerance: false, registerWeight: 100, registerSetpoint: 101 },
  conveyor: { running: false, fault: false, speed: 0 },
  mixer: { running: false, fault: false, current: 0, speed: 0, doorOpen: false },
  skip: { positionBottom: true, positionTop: false, safetyTop: false, cableSafety: false, moving: false, motorRunning: false },
  waterTanks: config.waterTanks.filter(w => w.active).map(w => ({ id: w.id, name: w.name, level: 75, pumpRunning: false })),
  adjuvantTanks: config.adjuvantTanks.filter(a => a.active).map(a => ({ id: a.id, name: a.name, level: 60, pumpRunning: false })),
  activeAlarms: [],
});

// =============================================
// PRODUCTION HISTORY PAR DÉFAUT
// =============================================
const generateHistory = (): ProductionBatch[] => {
  const batches: ProductionBatch[] = [];
  const recipes = [
    { id: 'r1', name: 'Béton B25' },
    { id: 'r2', name: 'Béton B30' },
    { id: 'r3', name: 'Béton de Propreté' },
  ];
  const clients = [
    { id: 'c1', name: 'BTP Construction SARL', truckPlate: 'AB-123-CD', driverName: 'Thomas Bernard' },
    { id: 'c2', name: 'Maçonnerie Dupont', truckPlate: 'IJ-789-KL', driverName: 'Marc Dubois' },
  ];

  for (let i = 0; i < 20; i++) {
    const recipe = recipes[i % 3];
    const client = clients[i % 2];
    const startTime = new Date(Date.now() - (i + 1) * 2 * 3600000);
    const endTime = new Date(startTime.getTime() + 8 * 60000);
    batches.push({
      id: `batch-${i + 1}`,
      batchNumber: `G${String(i + 1).padStart(4, '0')}`,
      recipeId: recipe.id, recipeName: recipe.name,
      clientId: client.id, clientName: client.name,
      truckId: `t${(i % 2) + 1}`, truckPlate: client.truckPlate,
      driverId: `d${(i % 2) + 1}`, driverName: client.driverName,
      operatorId: 'u2', operatorName: 'operateur',
      quantityOrdered: 7, quantityProduced: 7,
      status: 'completed', currentStep: 'done', stepProgress: 100,
      startTime, endTime, duration: 8 * 60,
      weightsActual: { aggregates: 1600, cement: 350, water: 175, adjuvant: 3.5 },
      weightsTarget: { aggregates: 1600, cement: 350, water: 175, adjuvant: 3.5 },
    });
  }
  return batches;
};

// =============================================
// ALARMES PAR DÉFAUT
// =============================================
const defaultAlarms: Alarm[] = [
  {
    id: 'alm1', type: 'comm_error', priority: 'warning',
    message: 'Perte communication PLC - Mode simulateur actif',
    detail: 'Connexion Modbus TCP échouée vers 192.168.1.100:502',
    timestamp: new Date(), acknowledged: false, active: true, source: 'Modbus',
  },
];

// =============================================
// STORE PRINCIPAL
// =============================================
interface AppStore {
  // Auth
  auth: AuthState;
  login: (username: string, password: string) => boolean;
  logout: () => void;

  // Theme
  theme: Theme;
  setTheme: (theme: Theme) => void;
  toggleTheme: () => void;

  // Language
  language: Language;
  setLanguage: (lang: Language) => void;

  // Plant Config
  plantConfig: PlantConfig;
  setPlantConfig: (config: PlantConfig) => void;
  addHopper: (hopper: Hopper) => void;
  updateHopper: (id: string, hopper: Partial<Hopper>) => void;
  removeHopper: (id: string) => void;
  addSilo: (silo: Silo) => void;
  updateSilo: (id: string, silo: Partial<Silo>) => void;
  removeSilo: (id: string) => void;

  // Modbus
  modbusConfig: ModbusConfig;
  setModbusConfig: (config: ModbusConfig) => void;
  modbusTags: ModbusTag[];
  setModbusTags: (tags: ModbusTag[]) => void;
  modbusStatus: ModbusStatus;
  setModbusStatus: (status: Partial<ModbusStatus>) => void;
  addModbusError: (error: ModbusError) => void;

  // Timers
  timers: Timers;
  setTimers: (timers: Timers) => void;

  // Impulse
  impulseConfig: ImpulseConfig;
  setImpulseConfig: (config: ImpulseConfig) => void;

  // Recipes
  recipes: Recipe[];
  addRecipe: (recipe: Recipe) => void;
  updateRecipe: (id: string, recipe: Partial<Recipe>) => void;
  deleteRecipe: (id: string) => void;
  duplicateRecipe: (id: string) => void;

  // Clients
  clients: Client[];
  addClient: (client: Client) => void;
  updateClient: (id: string, client: Partial<Client>) => void;
  deleteClient: (id: string) => void;

  // Trucks
  trucks: Truck[];
  addTruck: (truck: Truck) => void;
  updateTruck: (id: string, truck: Partial<Truck>) => void;
  deleteTruck: (id: string) => void;

  // Drivers
  drivers: Driver[];
  addDriver: (driver: Driver) => void;
  updateDriver: (id: string, driver: Partial<Driver>) => void;
  deleteDriver: (id: string) => void;

  // Users
  users: User[];
  addUser: (user: User) => void;
  updateUser: (id: string, user: Partial<User>) => void;
  deleteUser: (id: string) => void;

  // Production
  productionBatches: ProductionBatch[];
  currentBatch: ProductionBatch | null;
  startProduction: (batch: Omit<ProductionBatch, 'id' | 'batchNumber' | 'startTime' | 'status' | 'currentStep' | 'stepProgress' | 'quantityProduced' | 'weightsActual'>) => void;
  updateCurrentBatch: (batch: Partial<ProductionBatch>) => void;
  stopProduction: (reason?: string) => void;
  completeProduction: () => void;

  // Real-Time State
  realTimeState: PlantRealTimeState;
  updateRealTimeState: (state: Partial<PlantRealTimeState>) => void;
  updateHopperState: (id: string, state: Partial<PlantRealTimeState['hoppers'][0]>) => void;
  updateSiloState: (id: string, state: Partial<PlantRealTimeState['silos'][0]>) => void;

  // Alarms
  alarms: Alarm[];
  addAlarm: (alarm: Omit<Alarm, 'id' | 'timestamp'>) => void;
  acknowledgeAlarm: (id: string, userId: string) => void;
  acknowledgeAllAlarms: (userId: string) => void;
  clearInactiveAlarms: () => void;

  // Simulator
  simulatorState: SimulatorState;
  setSimulatorState: (state: Partial<SimulatorState>) => void;

  // Developer page visibility
  developerPageEnabled: boolean;
  setDeveloperPageEnabled: (enabled: boolean) => void;
}

export const useStore = create<AppStore>()(
  persist(
    (set, get) => ({
      // ---- AUTH ----
      auth: { user: null, token: null, isAuthenticated: false },
      login: (username, password) => {
        const users = get().users;
        const user = users.find(u => u.username === username && u.passwordHash === password && u.active);
        if (user) {
          const token = btoa(`${user.id}:${Date.now()}`);
          set({ auth: { user, token, isAuthenticated: true } });
          // Update last login
          get().updateUser(user.id, { lastLogin: new Date() });
          return true;
        }
        return false;
      },
      logout: () => set({ auth: { user: null, token: null, isAuthenticated: false } }),

      // ---- THEME ----
      theme: 'dark',
      setTheme: (theme) => set({ theme }),
      toggleTheme: () => set(s => ({ theme: s.theme === 'dark' ? 'light' : 'dark' })),

      // ---- LANGUAGE ----
      language: 'fr',
      setLanguage: (language) => {
        localStorage.setItem('betonpro_lang', language);
        set({ language });
      },

      // ---- PLANT CONFIG ----
      plantConfig: defaultPlantConfig,
      setPlantConfig: (config) => set({ plantConfig: config }),
      addHopper: (hopper) => set(s => ({ plantConfig: { ...s.plantConfig, hoppers: [...s.plantConfig.hoppers, hopper] } })),
      updateHopper: (id, hopper) => set(s => ({ plantConfig: { ...s.plantConfig, hoppers: s.plantConfig.hoppers.map(h => h.id === id ? { ...h, ...hopper } : h) } })),
      removeHopper: (id) => set(s => ({ plantConfig: { ...s.plantConfig, hoppers: s.plantConfig.hoppers.filter(h => h.id !== id) } })),
      addSilo: (silo) => set(s => ({ plantConfig: { ...s.plantConfig, silos: [...s.plantConfig.silos, silo] } })),
      updateSilo: (id, silo) => set(s => ({ plantConfig: { ...s.plantConfig, silos: s.plantConfig.silos.map(s2 => s2.id === id ? { ...s2, ...silo } : s2) } })),
      removeSilo: (id) => set(s => ({ plantConfig: { ...s.plantConfig, silos: s.plantConfig.silos.filter(s2 => s2.id !== id) } })),

      // ---- MODBUS ----
      modbusConfig: defaultModbusConfig,
      setModbusConfig: (config) => set({ modbusConfig: config }),
      modbusTags: [],
      setModbusTags: (tags) => set({ modbusTags: tags }),
      modbusStatus: { connected: false, errorCount: 0, packetsSent: 0, packetsReceived: 0, latency: 0, errorLog: [] },
      setModbusStatus: (status) => set(s => ({ modbusStatus: { ...s.modbusStatus, ...status } })),
      addModbusError: (error) => set(s => ({
        modbusStatus: {
          ...s.modbusStatus,
          errorCount: s.modbusStatus.errorCount + 1,
          errorLog: [error, ...s.modbusStatus.errorLog.slice(0, 99)],
        }
      })),

      // ---- TIMERS ----
      timers: defaultTimers,
      setTimers: (timers) => set({ timers }),

      // ---- IMPULSE ----
      impulseConfig: defaultImpulse,
      setImpulseConfig: (config) => set({ impulseConfig: config }),

      // ---- RECIPES ----
      recipes: defaultRecipes,
      addRecipe: (recipe) => set(s => ({ recipes: [...s.recipes, recipe] })),
      updateRecipe: (id, recipe) => set(s => ({ recipes: s.recipes.map(r => r.id === id ? { ...r, ...recipe, updatedAt: new Date() } : r) })),
      deleteRecipe: (id) => set(s => ({ recipes: s.recipes.filter(r => r.id !== id) })),
      duplicateRecipe: (id) => {
        const recipe = get().recipes.find(r => r.id === id);
        if (recipe) {
          const newRecipe: Recipe = { ...recipe, id: `r-${Date.now()}`, name: `${recipe.name} (copie)`, code: `${recipe.code}-COPY`, createdAt: new Date(), updatedAt: new Date(), usageCount: 0 };
          set(s => ({ recipes: [...s.recipes, newRecipe] }));
        }
      },

      // ---- CLIENTS ----
      clients: defaultClients,
      addClient: (client) => set(s => ({ clients: [...s.clients, client] })),
      updateClient: (id, client) => set(s => ({ clients: s.clients.map(c => c.id === id ? { ...c, ...client } : c) })),
      deleteClient: (id) => set(s => ({ clients: s.clients.filter(c => c.id !== id) })),

      // ---- TRUCKS ----
      trucks: defaultTrucks,
      addTruck: (truck) => set(s => ({ trucks: [...s.trucks, truck] })),
      updateTruck: (id, truck) => set(s => ({ trucks: s.trucks.map(t => t.id === id ? { ...t, ...truck } : t) })),
      deleteTruck: (id) => set(s => ({ trucks: s.trucks.filter(t => t.id !== id) })),

      // ---- DRIVERS ----
      drivers: defaultDrivers,
      addDriver: (driver) => set(s => ({ drivers: [...s.drivers, driver] })),
      updateDriver: (id, driver) => set(s => ({ drivers: s.drivers.map(d => d.id === id ? { ...d, ...driver } : d) })),
      deleteDriver: (id) => set(s => ({ drivers: s.drivers.filter(d => d.id !== id) })),

      // ---- USERS ----
      users: defaultUsers,
      addUser: (user) => set(s => ({ users: [...s.users, user] })),
      updateUser: (id, user) => set(s => ({ users: s.users.map(u => u.id === id ? { ...u, ...user } : u) })),
      deleteUser: (id) => set(s => ({ users: s.users.filter(u => u.id !== id) })),

      // ---- PRODUCTION ----
      productionBatches: generateHistory(),
      currentBatch: null,
      startProduction: (batch) => {
        const batchNumber = `G${String(get().productionBatches.length + 1).padStart(4, '0')}`;
        const newBatch: ProductionBatch = {
          ...batch, id: `batch-${Date.now()}`, batchNumber,
          startTime: new Date(), status: 'running', currentStep: 'aggregate_weighing',
          stepProgress: 0, quantityProduced: 0,
          weightsActual: { aggregates: 0, cement: 0, water: 0, adjuvant: 0 },
        };
        set({ currentBatch: newBatch });
      },
      updateCurrentBatch: (batch) => set(s => ({ currentBatch: s.currentBatch ? { ...s.currentBatch, ...batch } : null })),
      stopProduction: (reason) => {
        const batch = get().currentBatch;
        if (batch) {
          const completed: ProductionBatch = { ...batch, status: 'aborted', endTime: new Date(), duration: Math.round((Date.now() - (batch.startTime?.getTime() || Date.now())) / 1000) };
          set(s => ({ currentBatch: null, productionBatches: [completed, ...s.productionBatches] }));
        }
      },
      completeProduction: () => {
        const batch = get().currentBatch;
        if (batch) {
          const completed: ProductionBatch = { ...batch, status: 'completed', currentStep: 'done', stepProgress: 100, endTime: new Date(), duration: Math.round((Date.now() - (batch.startTime?.getTime() || Date.now())) / 1000), quantityProduced: batch.quantityOrdered };
          set(s => ({ currentBatch: null, productionBatches: [completed, ...s.productionBatches] }));
          // Increment recipe usage count
          get().updateRecipe(batch.recipeId, { usageCount: (get().recipes.find(r => r.id === batch.recipeId)?.usageCount || 0) + 1 });
        }
      },

      // ---- REAL-TIME STATE ----
      realTimeState: createDefaultRealTimeState(defaultPlantConfig),
      updateRealTimeState: (state) => set(s => ({ realTimeState: { ...s.realTimeState, ...state } })),
      updateHopperState: (id, hopperState) => set(s => ({
        realTimeState: {
          ...s.realTimeState,
          hoppers: s.realTimeState.hoppers.map(h => h.id === id ? { ...h, ...hopperState } : h),
        }
      })),
      updateSiloState: (id, siloState) => set(s => ({
        realTimeState: {
          ...s.realTimeState,
          silos: s.realTimeState.silos.map(sv => sv.id === id ? { ...sv, ...siloState } : sv),
        }
      })),

      // ---- ALARMS ----
      alarms: defaultAlarms,
      addAlarm: (alarm) => {
        const newAlarm: Alarm = { ...alarm, id: `alm-${Date.now()}`, timestamp: new Date() };
        set(s => ({ alarms: [newAlarm, ...s.alarms] }));
      },
      acknowledgeAlarm: (id, userId) => set(s => ({
        alarms: s.alarms.map(a => a.id === id ? { ...a, acknowledged: true, acknowledgedBy: userId, acknowledgedAt: new Date() } : a)
      })),
      acknowledgeAllAlarms: (userId) => set(s => ({
        alarms: s.alarms.map(a => ({ ...a, acknowledged: true, acknowledgedBy: userId, acknowledgedAt: new Date() }))
      })),
      clearInactiveAlarms: () => set(s => ({ alarms: s.alarms.filter(a => a.active) })),

      // ---- SIMULATOR ----
      simulatorState: { enabled: true, speed: 1, autoScenario: false, scenarioStep: 'idle', noiseLevel: 0.02 },
      setSimulatorState: (state) => set(s => ({ simulatorState: { ...s.simulatorState, ...state } })),

      // ---- DEVELOPER ----
      developerPageEnabled: true,
      setDeveloperPageEnabled: (enabled) => set({ developerPageEnabled: enabled }),
    }),
    {
      name: 'betonpro-storage',
      partialize: (state) => ({
        theme: state.theme,
        language: state.language,
        plantConfig: state.plantConfig,
        modbusConfig: state.modbusConfig,
        modbusTags: state.modbusTags,
        timers: state.timers,
        impulseConfig: state.impulseConfig,
        recipes: state.recipes,
        clients: state.clients,
        trucks: state.trucks,
        drivers: state.drivers,
        users: state.users,
        productionBatches: state.productionBatches,
        simulatorState: state.simulatorState,
        developerPageEnabled: state.developerPageEnabled,
      }),
    }
  )
);
