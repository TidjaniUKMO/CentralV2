/**
 * BétonPro SCADA - Types TypeScript industriels
 * Architecture professionnelle - Centrale à béton
 */

// =============================================
// AUTHENTIFICATION & UTILISATEURS
// =============================================
export type UserRole = 'admin' | 'operator' | 'maintenance';

export interface User {
  id: string;
  username: string;
  passwordHash: string;
  role: UserRole;
  email: string;
  active: boolean;
  lastLogin?: Date;
  createdAt: Date;
  permissions: Permission[];
}

export interface Permission {
  module: string;
  read: boolean;
  write: boolean;
  execute: boolean;
}

export interface AuthState {
  user: User | null;
  token: string | null;
  isAuthenticated: boolean;
}

// =============================================
// CONFIGURATION CENTRALE
// =============================================
export type DischargeMode = 'piston' | 'conveyor';
export type SkipType = 'skip' | 'inclined_conveyor';

export interface Hopper {
  id: string;
  name: string;
  index: number;
  dischargeMode: DischargeMode;
  hasVibrator: boolean;
  modbusCoilOpen: number;
  modbusCoilClose: number;
  modbusSensorFull: number;
  modbusSensorEmpty: number;
  active: boolean;
}

export interface Silo {
  id: string;
  name: string;
  index: number;
  capacity: number; // kg
  modbusLevelLow: number;
  modbusLevelHigh: number;
  modbusDischarge: number;
  active: boolean;
}

export interface WaterTank {
  id: string;
  name: string;
  index: number;
  capacity: number; // litres
  modbusLevel: number;
  modbusPump: number;
  active: boolean;
}

export interface AdjuvantTank {
  id: string;
  name: string;
  index: number;
  capacity: number; // litres
  modbusLevel: number;
  modbusPump: number;
  active: boolean;
}

export interface PlantConfig {
  id: string;
  plantName: string;
  hoppers: Hopper[];
  silos: Silo[];
  waterTanks: WaterTank[];
  adjuvantTanks: AdjuvantTank[];
  skipType: SkipType;
  hasSkipCableSensor: boolean;
  hasSkipBottomSensor: boolean;
  hasSkipTopSensor: boolean;
  dischargeConfirmation: 'timer' | 'weight';
  updatedAt: Date;
}

// =============================================
// MODBUS TCP
// =============================================
export type ModbusDataType = 'coil' | 'discrete_input' | 'holding_register' | 'input_register';

export interface ModbusConfig {
  ip: string;
  port: number;
  timeout: number;
  refreshRate: number;
  unitId: number;
  reconnectDelay: number;
  maxRetries: number;
}

export interface ModbusTag {
  id: string;
  name: string;
  address: number;
  type: ModbusDataType;
  description: string;
  unit?: string;
  scale?: number;
  offset?: number;
  min?: number;
  max?: number;
  value?: number | boolean;
  lastUpdate?: Date;
  quality: 'good' | 'bad' | 'uncertain';
}

export interface ModbusStatus {
  connected: boolean;
  lastConnected?: Date;
  errorCount: number;
  packetsSent: number;
  packetsReceived: number;
  latency: number;
  errorLog: ModbusError[];
}

export interface ModbusError {
  timestamp: Date;
  code: string;
  message: string;
  address?: number;
}

// =============================================
// E/S INDUSTRIELLES
// =============================================
export interface MotorState {
  id: string;
  name: string;
  running: boolean;
  fault: boolean;
  current: number; // Ampères
  speed?: number;
  coilRun: number;
  coilFault: number;
  registerCurrent: number;
}

export interface ValveState {
  id: string;
  name: string;
  open: boolean;
  fault: boolean;
  sensorOpen?: boolean;
  sensorClose?: boolean;
  coilOpen: number;
  coilClose: number;
}

export interface ScaleState {
  id: string;
  name: string;
  weight: number; // kg
  setpoint: number;
  tare: number;
  stable: boolean;
  inTolerance: boolean;
  registerWeight: number;
  registerSetpoint: number;
}

export interface LevelSensor {
  id: string;
  name: string;
  level: number; // %
  levelLow: boolean;
  levelHigh: boolean;
  registerLevel: number;
}

// =============================================
// TEMPORISATIONS
// =============================================
export interface TimerConfig {
  id: string;
  name: string;
  description: string;
  value: number; // ms
  min: number;
  max: number;
  unit: 'ms' | 's';
}

export interface Timers {
  valveOpenTime: number;
  valveCloseTime: number;
  conveyorStartTime: number;
  skipTime: number;
  mixingTime: number;
  safetyTimeout: number;
  alarmTimeout: number;
  dischargeTimeout: number;
  cementFlowTimeout: number;
  waterFlowTimeout: number;
}

// =============================================
// GESTION IMPULSIONS
// =============================================
export interface ImpulseConfig {
  enabled: boolean;
  triggerPercent: number; // % du poids consigne
  impulseOnTime: number;  // ms
  impulseOffTime: number; // ms
}

// =============================================
// RECETTES
// =============================================
export interface AggregateComponent {
  hopperId: string;
  hopperName: string;
  weight: number; // kg
}

export interface CementComponent {
  siloId: string;
  siloName: string;
  weight: number; // kg
}

export interface Recipe {
  id: string;
  code: string;
  name: string;
  description?: string;
  aggregates: AggregateComponent[];
  cement: CementComponent[];
  waterVolume: number;       // litres
  adjuvantVolume: number;    // litres
  mixingTime: number;        // secondes
  totalWeight: number;       // kg calculé
  volumeM3: number;          // m³
  createdAt: Date;
  updatedAt: Date;
  createdBy: string;
  usageCount: number;
  active: boolean;
}

// =============================================
// CLIENTS / CAMIONS / CHAUFFEURS
// =============================================
export type ClientType = 'company' | 'individual';

export interface Client {
  id: string;
  name: string;
  type: ClientType;
  phone?: string;
  email?: string;
  address?: string;
  createdAt: Date;
  active: boolean;
}

export interface Truck {
  id: string;
  clientId: string;
  plate: string;
  model?: string;
  capacity: number; // m³
  active: boolean;
}

export interface Driver {
  id: string;
  clientId: string;
  name: string;
  phone?: string;
  license?: string;
  active: boolean;
}

// =============================================
// PRODUCTION
// =============================================
export type ProductionStatus = 'idle' | 'running' | 'paused' | 'completed' | 'aborted' | 'error';
export type ProductionStep =
  | 'idle'
  | 'aggregate_weighing'
  | 'cement_weighing'
  | 'water_weighing'
  | 'adjuvant_weighing'
  | 'mixing'
  | 'discharge'
  | 'done';

export interface ProductionBatch {
  id: string;
  batchNumber: string;
  recipeId: string;
  recipeName: string;
  clientId?: string;
  clientName?: string;
  truckId?: string;
  truckPlate?: string;
  driverId?: string;
  driverName?: string;
  operatorId: string;
  operatorName: string;
  quantityOrdered: number; // m³
  quantityProduced: number;
  status: ProductionStatus;
  currentStep: ProductionStep;
  stepProgress: number; // 0-100%
  startTime?: Date;
  endTime?: Date;
  duration?: number; // secondes
  weightsActual: {
    aggregates: number;
    cement: number;
    water: number;
    adjuvant: number;
  };
  weightsTarget: {
    aggregates: number;
    cement: number;
    water: number;
    adjuvant: number;
  };
  notes?: string;
  alarms?: string[];
}

// =============================================
// ALARMES
// =============================================
export type AlarmPriority = 'critical' | 'warning' | 'info';
export type AlarmType =
  | 'comm_error'
  | 'motor_overload'
  | 'valve_timeout'
  | 'skip_safety'
  | 'emergency_stop'
  | 'weight_error'
  | 'level_low'
  | 'level_high'
  | 'recipe_error'
  | 'sensor_fault'
  | 'watchdog'
  | 'plc_disconnect';

export interface Alarm {
  id: string;
  type: AlarmType;
  priority: AlarmPriority;
  message: string;
  detail?: string;
  timestamp: Date;
  acknowledged: boolean;
  acknowledgedBy?: string;
  acknowledgedAt?: Date;
  active: boolean;
  source: string;
}

// =============================================
// ETAT SYNOPTIQUE TEMPS REEL
// =============================================
export interface PlantRealTimeState {
  // Mode
  modeAuto: boolean;
  emergencyStop: boolean;
  plcConnected: boolean;
  simulatorMode: boolean;

  // Hoppers
  hoppers: {
    id: string;
    name: string;
    open: boolean;
    vibratorOn: boolean;
    level: number;
    conveyorRunning?: boolean;
  }[];

  // Silos
  silos: {
    id: string;
    name: string;
    level: number;
    discharging: boolean;
    levelLow: boolean;
    levelHigh: boolean;
  }[];

  // Scales
  aggregateScale: ScaleState;
  cementScale?: ScaleState;

  // Skip
  skip: {
    positionBottom: boolean;
    positionTop: boolean;
    safetyTop: boolean;
    cableSafety: boolean;
    moving: boolean;
    motorRunning: boolean;
  };

  // Conveyor / Skip
  conveyor: {
    running: boolean;
    fault: boolean;
    speed?: number;
  };

  // Mixer
  mixer: {
    running: boolean;
    fault: boolean;
    current: number;
    speed?: number;
    doorOpen: boolean;
  };

  // Water
  waterTanks: {
    id: string;
    name: string;
    level: number;
    pumpRunning: boolean;
  }[];

  // Adjuvant
  adjuvantTanks: {
    id: string;
    name: string;
    level: number;
    pumpRunning: boolean;
  }[];

  // Production
  currentBatch?: ProductionBatch;
  activeAlarms: Alarm[];
}

// =============================================
// THEME
// =============================================
export type Theme = 'dark' | 'light';
export type Language = 'fr' | 'en' | 'ar';

// =============================================
// SIMULATEUR
// =============================================
export interface SimulatorState {
  enabled: boolean;
  speed: number; // multiplicateur vitesse 1-10
  autoScenario: boolean;
  scenarioStep: ProductionStep;
  noiseLevel: number; // 0-1
}
